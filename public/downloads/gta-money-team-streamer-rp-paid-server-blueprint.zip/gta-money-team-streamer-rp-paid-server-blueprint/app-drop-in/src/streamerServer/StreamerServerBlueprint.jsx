import React, { useMemo, useState } from 'react';
import './streamer-server-blueprint.css';

const products = [
  ['Founder Pass', '$25-$75', 'Early access, private announcements, founder status.'],
  ['Priority Review', '$10-$25', 'Fast application review, never guaranteed acceptance.'],
  ['Priority Queue', '$15-$50/mo', 'Convenience access and supporter status.'],
  ['Creator Partner', '$25-$99/mo', 'Media kit, event access, clip calendar.'],
  ['Cosmetic Supporter Pack', '$9-$49', 'Original cosmetic/status ideas only.'],
  ['Full Launch Vault', '$199-$499', 'Configs, Discord, Tebex, marketing, security.'],
];

const safetyRules = [
  'No Adin Ross branding or copied private server assets.',
  'No official Rockstar or Take-Two affiliation claims.',
  'No crypto cash-out, play-to-earn promises, or paid in-game currency.',
  'Use Tebex-style authorized monetization flow for FiveM server commerce.',
  'Sell access, community, cosmetics, events, templates, and support.',
];

export default function StreamerServerBlueprint() {
  const [members, setMembers] = useState(500);
  const [price, setPrice] = useState(25);
  const [addons, setAddons] = useState(1000);

  const mrr = useMemo(() => members * price + Number(addons || 0), [members, price, addons]);
  const annual = mrr * 12;

  return (
    <main className="ssb-page">
      <section className="ssb-hero">
        <p className="ssb-kicker">GTA Money Team • Creator Server System</p>
        <h1>Streamer-Style Paid RP Server Blueprint</h1>
        <p>
          Build an original paid FiveM RP community around access, Discord, cosmetics, creator events,
          staff systems, security, and legal monetization — without cloning a celebrity server.
        </p>
        <div className="ssb-actions">
          <a href="/downloads/creator-empire-rp-blueprint.zip">Download Blueprint</a>
          <a href="#calculator" className="ghost">Run Revenue Math</a>
        </div>
      </section>

      <section className="ssb-grid">
        {products.map(([name, priceLabel, desc]) => (
          <article className="ssb-card" key={name}>
            <span>{priceLabel}</span>
            <h3>{name}</h3>
            <p>{desc}</p>
          </article>
        ))}
      </section>

      <section id="calculator" className="ssb-panel">
        <h2>Paid Server Revenue Estimator</h2>
        <div className="ssb-calc">
          <label>Members<input type="number" value={members} onChange={e => setMembers(Number(e.target.value))} /></label>
          <label>Monthly Price<input type="number" value={price} onChange={e => setPrice(Number(e.target.value))} /></label>
          <label>Add-ons / Month<input type="number" value={addons} onChange={e => setAddons(Number(e.target.value))} /></label>
        </div>
        <div className="ssb-result">
          <strong>${mrr.toLocaleString()}</strong><span>estimated monthly gross</span>
          <strong>${annual.toLocaleString()}</strong><span>estimated annual gross</span>
        </div>
        <p className="ssb-note">Estimate only. Keep server commerce compliant, fair, and separate from in-game cash-out claims.</p>
      </section>

      <section className="ssb-panel ssb-rules">
        <h2>Safety Rules</h2>
        <ul>{safetyRules.map(rule => <li key={rule}>{rule}</li>)}</ul>
      </section>
    </main>
  );
}
