# Source Notes To Re-Check Before Publishing

These notes summarize public research themes. Re-check live rules before selling or launching any live server.

- Cfx.re docs: Tebex is the authorized/exclusive monetization partner for FiveM/RedM server monetization.
- Cfx.re Creator Platform License Agreement: Creator Services are governed by Rockstar/Cfx terms; users do not receive Rockstar trademark rights.
- Public reporting: Adin Ross has discussed a paid GTA 6 RP/server concept; some reports say the concept involves real-money or crypto-related player payouts, but the feasibility and compliance are uncertain.
- Public reporting: Take-Two/Rockstar have consolidated GTA V multiplayer modding around FiveM and moved against other platforms such as Rage:MP.
- Market pattern: top RP servers monetize through access, queues, roles, cosmetics/status, events, applications, and community identity.

Use these notes as a research checklist, not legal advice.
