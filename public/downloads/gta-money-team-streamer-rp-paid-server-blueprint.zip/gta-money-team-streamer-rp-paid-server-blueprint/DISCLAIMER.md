# Legal / Brand Disclaimer

This template is an original GTA Money Team / Lux Automaton educational and server-planning product.

It is **not** affiliated with, endorsed by, or sponsored by Adin Ross, FaZe, Tee Grizzley, GrizzleyWorld, NoPixel, Rockstar Games, Take-Two Interactive, Cfx.re, FiveM, RedM, or any third-party server.

Do not market this as an Adin Ross server, GTA 6 server, Rockstar server, official server, or clone of any private server.

Use this as:

- Streamer-style RP server blueprint
- Creator city template
- Paid FiveM RP community starter
- Tebex monetization planning guide
- Discord and community ops pack

Do not use it for:

- Crypto cash-out gameplay
- Play-to-earn claims
- Selling in-game currency
- Paid loot boxes/chance mechanics
- Real-world gambling
- Mod menus or cheats
- Ripped Rockstar assets
- Real police insignia or real gang branding
- Impersonating influencers or copying private servers
