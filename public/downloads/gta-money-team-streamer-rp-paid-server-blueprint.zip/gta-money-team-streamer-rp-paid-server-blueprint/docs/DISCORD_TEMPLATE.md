# Discord Template — Streamer RP City

## Categories and channels

### Start Here
- #welcome
- #rules
- #how-to-join
- #announcements
- #server-status

### Applications
- #whitelist-info
- #apply-here
- #application-faq
- #priority-review-info

### Community
- #general
- #clips-and-streams
- #events
- #city-suggestions
- #bug-reports

### RP Departments
- #police-applications
- #ems-applications
- #business-applications
- #creator-program
- #faction-applications

### Support
- #open-ticket
- #ban-appeals
- #billing-help
- #staff-report

### Staff Only
- #staff-announcements
- #mod-log
- #ban-log
- #dev-log
- #event-planning

## Roles

- Owner
- Project Lead
- Head Admin
- Moderator
- Developer
- Support
- Founder
- Priority
- Creator Partner
- Verified Citizen
- Applicant
- Muted

## Paid role warning

Paid roles should not guarantee whitelist acceptance, gameplay power, or in-game wealth. Use them for access, status, queue, announcements, event reminders, cosmetic perks, and support channels.
