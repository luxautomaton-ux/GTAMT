# Internal GitHub Stack Ideas

Use public GitHub projects as inspiration or dependencies only after checking licenses.

## Server frameworks

- QBCore / Qbox for RP server bases
- ESX Legacy for alternate economy framework
- Overextended resources for modern utility/inventory/mysql patterns

## Admin/security

- vMenu for permissions menu concepts
- EasyAdmin for moderation/admin workflow inspiration
- Discord ACE permission patterns for role-gated access

## Delivery / server template

- txAdmin recipes for one-click setup patterns
- Tebex headless examples for store UI concepts

## Creator automation

- Remotion for automated video templates
- OBS websocket for stream control ideas

## Rule

Do not resell third-party code unless the license clearly allows it. Sell your docs, configs, workflow, brand system, and setup service.
