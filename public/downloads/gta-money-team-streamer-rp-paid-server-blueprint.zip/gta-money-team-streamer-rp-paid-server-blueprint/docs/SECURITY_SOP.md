# Security + Anti-Abuse SOP

## Staff structure

- Owner: billing, legal, final decisions
- Project Lead: launch timeline, content, team coordination
- Head Admin: staff rules, appeals, bans
- Moderators: tickets, reports, chat/server issues
- Developers: code/resources only; no billing secrets
- Community Managers: events, announcements, onboarding

## Secret handling

Never post these in Discord screenshots, videos, GitHub, or tickets:

- Cfx license key
- database credentials
- Tebex secrets
- Discord bot token
- webhooks with write access
- RCON/passwords
- admin license identifiers

## Resource audit checklist

Before installing a script:

- Check license and source.
- Search for suspicious HTTP requests.
- Search for obfuscated code.
- Confirm no hidden admin/backdoor commands.
- Test on staging before production.
- Keep backups.

## Player economy controls

- Log large money transfers.
- Add staff approval for high-value asset ownership.
- Keep admin powers separated from normal player accounts.
- Review exploits weekly.
- Publish rules clearly.
