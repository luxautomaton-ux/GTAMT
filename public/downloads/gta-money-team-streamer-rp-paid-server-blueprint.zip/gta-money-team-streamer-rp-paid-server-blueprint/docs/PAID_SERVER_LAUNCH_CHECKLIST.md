# Paid Server Launch Checklist

## Phase 1 — Foundation

- [ ] Pick original server name
- [ ] Buy domain
- [ ] Create Discord
- [ ] Set staff structure
- [ ] Create rules
- [ ] Prepare Cfx/txAdmin server
- [ ] Test resource pack

## Phase 2 — Monetization

- [ ] Create Tebex store
- [ ] Add Founder Pass
- [ ] Add Priority Review disclaimer
- [ ] Add cosmetic/status perks
- [ ] Add support channels
- [ ] Add terms/refund page
- [ ] Test delivery commands/roles

## Phase 3 — Content

- [ ] Launch trailer
- [ ] 10 short-form clips
- [ ] Creator application post
- [ ] Countdown posts
- [ ] City teaser images
- [ ] First event schedule

## Phase 4 — Security

- [ ] Lock admin permissions
- [ ] Audit resources
- [ ] Add logs
- [ ] Backup database
- [ ] Create ban appeal process
- [ ] Create staff conduct policy

## Phase 5 — Launch

- [ ] Soft open with staff only
- [ ] Creator preview night
- [ ] Founder access window
- [ ] Public whitelist window
- [ ] First city showcase event
