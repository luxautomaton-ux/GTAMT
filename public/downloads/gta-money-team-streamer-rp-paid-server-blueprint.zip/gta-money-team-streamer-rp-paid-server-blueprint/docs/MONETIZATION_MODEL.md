# Monetization Model — Safe Streamer-Style Server

## The wrong way

- “Quit your job and earn real money in our GTA server.”
- “Cash out game money for crypto.”
- “Buy in-game money.”
- “Buy loot boxes.”
- “Pay for weapons, power, or guaranteed wins.”

## The better way

Sell value that does not break gameplay balance:

1. Founder access and Discord status.
2. Priority application review, not guaranteed approval.
3. Priority queue, where allowed.
4. Cosmetic-only supporter items.
5. Creator partner roles and event access.
6. Server-branded clothing/livery templates using licensed/original assets.
7. Staff training and server owner education.
8. Setup, security, and monthly ops support.
9. Content calendars and media kits.
10. Private workshop downloads.

## Suggested store tiers

| Tier | Monthly price | Includes |
|---|---:|---|
| Citizen | Free | public application + rules |
| Founder | $25/mo | founder role, private announcements, events |
| Priority | $50/mo | queue tier, support channel, event reminders |
| Creator Partner | $99/mo | media kit, clip schedule, event access |
| Owner Ops | $299/mo | private server owner docs + office hours |

## Server owner revenue plan

Example allocation:

- 15% hosting
- 20% staff/support
- 25% development/assets
- 20% marketing/creators
- 10% reserve
- 10% owner profit

Keep the in-game economy separate from real-world payments.
