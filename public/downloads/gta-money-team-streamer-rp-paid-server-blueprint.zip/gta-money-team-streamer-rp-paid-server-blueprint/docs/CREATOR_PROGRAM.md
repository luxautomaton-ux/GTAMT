# Creator Partner Program

## Goal

Use streamers and short-form creators to drive server demand without promising real-world income from gameplay.

## Creator benefits

- Creator Discord role
- event schedule access
- media kit
- approved logo pack
- weekly clip prompts
- creator night access
- shoutout opportunities

## Creator responsibilities

- Follow server rules
- Do not promote cheats, exploits, fake coins, crypto cash-out, or mod menus
- Use legal-safe disclaimers
- Do not claim official Rockstar affiliation
- Respect other players and staff

## Weekly content calendar

- Monday: “How to join the city” short
- Tuesday: “Best RP job this week” short
- Wednesday: Creator Clip Night stream
- Thursday: faction/business spotlight
- Friday: Founder event promo
- Saturday: city showcase
- Sunday: recap and next-week teaser
