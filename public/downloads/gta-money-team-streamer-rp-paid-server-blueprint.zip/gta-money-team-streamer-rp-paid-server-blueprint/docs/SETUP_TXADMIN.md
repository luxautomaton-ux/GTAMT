# Setup Guide — txAdmin / FXServer

## 1. Create server

Use txAdmin or FXServer to create a fresh FiveM server.

## 2. Copy resources

Copy:

```text
server-core/resources/[gmt]/gmt_streamer_city
```

into your server:

```text
resources/[gmt]/gmt_streamer_city
```

## 3. Configure server.cfg

Copy `server-core/server.cfg.sample` into your server data folder as `server.cfg`.

Replace:

- `CHANGE_ME_CFX_LICENSE_KEY`
- Discord invite
- Tebex store URL
- staff license identifiers
- hostname/project description

## 4. Start resource

Make sure this line exists:

```cfg
ensure gmt_streamer_city
```

## 5. Test commands

In server chat:

```text
/serverbrand
/moneyrules
/creatorjobs
/streamerpass
/payoutmodel
/eventplan
/securityrules
```

## 6. Customize

Edit:

```text
server-core/resources/[gmt]/gmt_streamer_city/config.lua
```

Add your real city name, public Discord, Tebex URL, RP jobs, weekly events, and compliance rules.
