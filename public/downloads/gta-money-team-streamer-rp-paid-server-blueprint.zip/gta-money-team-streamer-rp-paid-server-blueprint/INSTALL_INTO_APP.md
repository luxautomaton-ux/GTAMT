# Install Into GTA Money Team App

Copy the app drop-in files:

```bash
cp -R app-drop-in/src/streamerServer YOUR_APP/src/
```

Then render the page:

```jsx
import StreamerServerBlueprint from './streamerServer/StreamerServerBlueprint.jsx';

export default function App() {
  return <StreamerServerBlueprint />;
}
```

Optional: copy the final product ZIP into your public downloads folder:

```bash
mkdir -p YOUR_APP/public/downloads
cp gta-money-team-streamer-rp-paid-server-blueprint.zip YOUR_APP/public/downloads/creator-empire-rp-blueprint.zip
```
