--[[
  Active city configuration for Creator Empire RP.
  This file is read by the gmt_streamer_city resource.
  Customize names, districts, jobs, and money rules to fit your brand.
]]

GMT_ACTIVE_CITY = {
  serverName = "Creator Empire RP",
  tagline = "Play smart. Build legacy. Stay legal.",
  discord = "discord.gg/CHANGE-ME",
  tebex = "https://CHANGE-ME.tebex.io",

  -- Districts are RP neighborhoods. Use fictional names to avoid copying real top servers.
  districts = {
    { name = "Marina Row", style = "luxury waterfront", bestFor = "creator events, imports, yacht meets" },
    { name = "Downtown Grid", style = "business core", bestFor = "taxi, courier, legal offices" },
    { name = "South Yard", style = "industrial", bestFor = "mechanic, trucking, security" },
    { name = "Studio Hill", style = "creator district", bestFor = "streamer offices, media crews" },
    { name = "Night Market", style = "nightlife", bestFor = "clubs, music events, food vendors" },
  },

  -- Starter spawn points. Replace with actual vector coords after testing in-game.
  spawns = {
    { label = "Airport Arrival", coords = { x = -1037.76, y = -2737.83, z = 20.17, h = 330.0 } },
    { label = "Downtown Welcome Center", coords = { x = 215.76, y = -810.12, z = 30.73, h = 160.0 } },
    { label = "Marina Row", coords = { x = -802.31, y = -1342.94, z = 5.15, h = 90.0 } },
  },

  -- RP jobs are for in-game roleplay only. Do not promise real money cash-outs.
  rpJobs = {
    { name = "Courier", legalLoop = "delivery routes", rpPayRange = "$450-$1,250 RP/hr", notes = "Good beginner loop; route planner friendly." },
    { name = "Mechanic", legalLoop = "repair + customization RP", rpPayRange = "$600-$1,800 RP/hr", notes = "Pairs well with cosmetic supporter events." },
    { name = "Media Runner", legalLoop = "clip capture + event coverage", rpPayRange = "$500-$2,000 RP/hr", notes = "Feeds content machine for streamers." },
    { name = "Event Security", legalLoop = "event staffing", rpPayRange = "$700-$2,200 RP/hr", notes = "Useful for creator nights and VIP events." },
    { name = "Business Host", legalLoop = "club/storefront RP", rpPayRange = "$800-$2,500 RP/hr", notes = "Good for social monetization and RP ownership." },
  },

  accessTiers = {
    { name = "Free Citizen", perks = { "public application", "basic city access" } },
    { name = "Founder", perks = { "founder Discord role", "private announcements", "cosmetic badge" } },
    { name = "Priority", perks = { "queue priority", "event reminders", "support channel" } },
    { name = "Creator Partner", perks = { "creator role", "clip calendar", "media event invites" } },
  },

  moneyRules = {
    "No selling in-game currency.",
    "No crypto cash-out or play-to-earn promises.",
    "No paid loot boxes or chance rewards.",
    "Keep supporter perks cosmetic, access-based, or community-based.",
    "All real-money FiveM server commerce should go through authorized monetization flow such as Tebex.",
  },

  payoutModel = {
    -- These splits are for server business planning / staff compensation discussion, not in-game cash-out.
    description = "Example owner-side operating budget split for paid server revenue.",
    splits = {
      hosting = 15,
      staff_and_support = 20,
      development = 25,
      marketing = 20,
      reserve = 10,
      owner_profit = 10,
    }
  }
}
