--[[
  gmt_streamer_city config
  Copy ../../config/active_city.lua into this resource or adapt this file directly.
  This default configuration is intentionally safe and simple.
]]

Config = Config or {}

Config.Brand = {
  serverName = "Creator Empire RP",
  tagline = "Play smart. Build legacy. Stay legal.",
  discord = "discord.gg/CHANGE-ME",
  tebex = "https://CHANGE-ME.tebex.io"
}

Config.Rules = {
  "No cheats, mod menus, exploit abuse, account theft, or malware.",
  "No selling in-game currency or cash-out gameplay.",
  "No crypto, NFT, token, loot-box, or gambling-style server monetization.",
  "Supporter perks must stay cosmetic, access-based, educational, or community-based.",
  "Respect staff, keep RP immersive, and protect the community."
}

Config.Commands = {
  brand = "serverbrand",
  moneyRules = "moneyrules",
  jobs = "creatorjobs",
  payout = "payoutmodel",
  event = "eventplan",
  security = "securityrules"
}

Config.RPJobs = {
  { name = "Courier", loop = "Clean delivery routes", rpPay = "$450-$1,250 RP/hr" },
  { name = "Mechanic", loop = "Repair/customization RP", rpPay = "$600-$1,800 RP/hr" },
  { name = "Media Runner", loop = "Event clips and creator coverage", rpPay = "$500-$2,000 RP/hr" },
  { name = "Event Security", loop = "VIP event support", rpPay = "$700-$2,200 RP/hr" },
  { name = "Business Host", loop = "Nightlife/storefront RP", rpPay = "$800-$2,500 RP/hr" }
}

Config.Events = {
  { day = "Monday", name = "New Citizen Orientation", purpose = "teach rules, scams, and roleplay basics" },
  { day = "Wednesday", name = "Creator Clip Night", purpose = "give streamers safe storylines and highlights" },
  { day = "Friday", name = "Founder Night", purpose = "reward early supporters with social access" },
  { day = "Saturday", name = "City Showcase", purpose = "public-facing hype event for recruitment" }
}

Config.BusinessBudgetSplit = {
  hosting = 15,
  staff_and_support = 20,
  development = 25,
  marketing = 20,
  reserve = 10,
  owner_profit = 10
}
