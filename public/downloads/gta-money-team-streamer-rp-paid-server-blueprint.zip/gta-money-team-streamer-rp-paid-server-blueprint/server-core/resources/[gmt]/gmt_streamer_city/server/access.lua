-- Access and tier messaging.
-- This starter does not integrate with Tebex automatically.
-- Real delivery should be done through Tebex commands, Discord roles, or your framework.

RegisterCommand('streamerpass', function(source)
  local msg = "Access tiers: Free Citizen, Founder, Priority, Creator Partner. " ..
    "Use Tebex/Discord to deliver roles and keep perks cosmetic or access-based."
  GMT.Chat(source, msg)
end, false)
