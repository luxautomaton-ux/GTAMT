-- Security reminder commands.
-- Extend with logging, anticheat, Discord webhooks, and permission checks in production.

RegisterCommand(Config.Commands.security, function(source)
  local tips = {
    "Lock staff permissions with ACE groups and least-privilege roles.",
    "Never share license keys, bot tokens, database passwords, or Tebex secrets.",
    "Review every new resource for obfuscated code, suspicious HTTP requests, and backdoors.",
    "Use server logs and Discord staff logs for ban evidence.",
    "Separate owner, admin, moderator, developer, and support roles."
  }
  GMT.Chat(source, "Security baseline:" .. GMT.Bullets(tips))
end, false)
