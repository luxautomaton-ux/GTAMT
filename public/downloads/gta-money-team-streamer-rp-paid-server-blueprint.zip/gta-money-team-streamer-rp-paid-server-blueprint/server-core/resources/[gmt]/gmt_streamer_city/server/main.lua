-- Main server commands for the GTA Money Team streamer-city starter.

AddEventHandler('onResourceStart', function(resourceName)
  if resourceName ~= GetCurrentResourceName() then return end
  print('[GTA Money Team] gmt_streamer_city loaded. Commands: /serverbrand /moneyrules /creatorjobs /payoutmodel /eventplan /securityrules')
end)

RegisterCommand(Config.Commands.brand, function(source)
  local brand = Config.Brand.serverName .. " — " .. Config.Brand.tagline ..
    "\nDiscord: " .. Config.Brand.discord ..
    "\nStore: " .. Config.Brand.tebex
  GMT.Chat(source, brand)
end, false)

RegisterCommand(Config.Commands.moneyRules, function(source)
  GMT.Chat(source, "Legal money rules:" .. GMT.Bullets(Config.Rules))
end, false)

RegisterCommand(Config.Commands.event, function(source)
  local lines = { "Weekly creator event plan:" }
  for _, e in ipairs(Config.Events) do
    table.insert(lines, e.day .. " — " .. e.name .. ": " .. e.purpose)
  end
  GMT.Chat(source, table.concat(lines, "\n"))
end, false)
