GMT = GMT or {}

-- Prefix every chat message so players know it comes from the city system.
function GMT.Prefix()
  return "^3[GTA Money Team]^7 "
end

-- Sends a simple chat message to one player or everyone.
function GMT.Chat(target, message)
  TriggerClientEvent('chat:addMessage', target or -1, {
    color = { 0, 255, 255 },
    multiline = true,
    args = { "GTA Money Team", message }
  })
end

-- Converts a table of strings into a readable bullet list.
function GMT.Bullets(items)
  local out = ""
  for _, item in ipairs(items) do
    out = out .. "\n- " .. tostring(item)
  end
  return out
end
