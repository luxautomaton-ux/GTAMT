-- Owner-side business budget model.
-- This is NOT a player cash-out system. It is a business planning guide for the server owner.

RegisterCommand(Config.Commands.payout, function(source)
  local lines = { "Example server revenue operating budget:" }
  for key, pct in pairs(Config.BusinessBudgetSplit) do
    table.insert(lines, key .. ": " .. pct .. "%")
  end
  table.insert(lines, "Keep in-game money separate from real-world revenue.")
  GMT.Chat(source, table.concat(lines, "\n"))
end, false)
