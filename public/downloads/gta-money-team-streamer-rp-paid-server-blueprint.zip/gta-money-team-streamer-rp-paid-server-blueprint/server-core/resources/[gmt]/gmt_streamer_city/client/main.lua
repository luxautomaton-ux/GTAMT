-- Client helper script.
-- Keep client logic lightweight. Sensitive checks belong server-side.

CreateThread(function()
  Wait(5000)
  TriggerEvent('chat:addMessage', {
    color = { 255, 0, 255 },
    args = { 'GTA Money Team', 'Welcome to Creator Empire RP. Use /moneyrules to learn the safe monetization rules.' }
  })
end)
