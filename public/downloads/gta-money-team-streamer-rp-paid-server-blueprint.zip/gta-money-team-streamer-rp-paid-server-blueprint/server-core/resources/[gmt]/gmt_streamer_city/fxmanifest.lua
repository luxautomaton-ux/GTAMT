fx_version 'cerulean'
game 'gta5'

name 'gmt_streamer_city'
author 'Lux Automaton / GTA Money Team'
description 'Streamer-style RP city starter resource with legal money rules, jobs, events, and security commands.'
version '1.0.0'

lua54 'yes'

shared_scripts {
  'config.lua',
  'shared/utils.lua'
}

server_scripts {
  'server/access.lua',
  'server/jobs.lua',
  'server/payouts.lua',
  'server/security.lua',
  'server/main.lua'
}

client_scripts {
  'client/main.lua'
}
