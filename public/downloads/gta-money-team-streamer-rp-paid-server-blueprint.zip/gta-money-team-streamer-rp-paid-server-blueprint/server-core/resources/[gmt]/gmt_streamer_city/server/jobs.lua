-- In-game RP job education.
-- IMPORTANT: These are roleplay loops and in-game salaries only.
-- Do not promise real-world payouts for game labor.

RegisterCommand(Config.Commands.jobs, function(source)
  local lines = { "Creator City RP Jobs:" }
  for _, job in ipairs(Config.RPJobs) do
    table.insert(lines, job.name .. " — " .. job.loop .. " — " .. job.rpPay)
  end
  GMT.Chat(source, table.concat(lines, "\n"))
end, false)
