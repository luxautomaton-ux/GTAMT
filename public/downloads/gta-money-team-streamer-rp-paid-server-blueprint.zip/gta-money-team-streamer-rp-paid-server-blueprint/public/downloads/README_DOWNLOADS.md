# Downloads Folder

Place the final customer ZIP here when installing into your app:

```text
public/downloads/creator-empire-rp-blueprint.zip
```

Then the App drop-in download button will point to it.
