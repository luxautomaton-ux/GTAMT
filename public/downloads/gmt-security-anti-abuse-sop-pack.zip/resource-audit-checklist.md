# Resource Audit Checklist

- Unknown obfuscated code?
- Suspicious HTTP requests?
- Hardcoded tokens?
- Excessive permissions?
- Client-side trust issues?
- Unlicensed paid asset?
