# Discord Token Safety

Never paste bot tokens into screenshots, public repos, public docs, or customer files. Rotate exposed tokens immediately.
