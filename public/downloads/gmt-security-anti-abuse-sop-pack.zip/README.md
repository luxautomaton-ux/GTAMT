# Security + Anti-Abuse SOP Pack

## Server security

- Use least privilege for ACE permissions.
- Never publish database passwords.
- Keep Discord bot tokens secret.
- Keep paid resources private.
- Version every resource update.
- Test new scripts in staging.

## Store security

- Use verified payment providers.
- Avoid manual DMs for file delivery.
- Track version and buyer access.
- Use watermarked docs where useful.
