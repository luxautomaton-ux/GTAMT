# Offer Ladder

## Low ticket: $29–$99

- Discord server template
- Tebex product copy pack
- RP rules template
- YouTube Shorts prompt pack
- Launch checklist

## Core templates: $99–$399

- Priority Queue Engine Pack
- Whitelist + Application Machine
- Discord Commerce Roles Kit
- Tebex Store Blueprint Pack
- Creator Server Launch Pack

## High ticket: $399–$1,500

- Premium City Identity Pack
- Original Street Faction Identity Pack
- Business Economy Pack
- Security Audit Pack
- DFY install

## Retainers: $299–$1,500/mo

- Store optimization
- weekly economy tuning
- security checks
- staff training
- content calendar
- launch events

## Bundle names

- GTA Money Team Starter Store Kit — $199
- GTA Money Team Queue + Discord Machine — $299
- GTA Money Team City Founder Kit — $799
- GTA Money Team Premium Server Commerce Vault — $1,499
- GTA Money Team Monthly Ops Desk — $499/mo+
