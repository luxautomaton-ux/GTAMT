# Sellable Template Stack

## Starter products

### 1. Priority Queue Engine Pack
Price: $149–$299

Deliverables:
- Queue tier ladder
- Discord role map
- Priority points matrix
- Tebex package copy
- Support FAQ
- Install checklist

### 2. Whitelist + Application Machine
Price: $99–$249

Deliverables:
- RP application form
- Scoring rubric
- Interview SOP
- Premium processing disclaimer
- Discord ticket flow
- Staff macros

### 3. Tebex Store Blueprint Pack
Price: $149–$399

Deliverables:
- Store category layout
- Product descriptions
- Checkout rules
- Refund/support language
- Compliance disclaimer
- Upsell ladder

## Mid-ticket products

### 4. Discord Commerce Roles Kit
Price: $149–$399

Deliverables:
- Role hierarchy
- Private channels
- Bot action checklist
- Purchase welcome messages
- Support ticket templates
- Moderator escalation flow

### 5. Original Street Faction Identity Pack
Price: $199–$499

Deliverables:
- Original faction names
- Territory map concept
- Rank structure
- Rules
- Clothing specs
- Payout splits
- Event ideas

### 6. City Business Economy Pack
Price: $249–$599

Deliverables:
- Business catalog
- Job/pay progression
- Tax/sink model
- Price control sheet
- Owner application template
- Balance review SOP

## High-ticket products

### 7. Premium City Identity Pack
Price: $399–$1,500

Deliverables:
- City lore
- District map
- Landmark list
- weather rotation
- police fleet placeholders
- faction set
- legal money loops
- launch trailer prompt

### 8. Security + Anti-Abuse Audit Pack
Price: $299–$999

Deliverables:
- Permissions audit
- resource risk checklist
- event validation review
- staff access policy
- backup plan
- incident response log

### 9. Monthly RP Server Ops Retainer
Price: $299–$1,500/mo

Deliverables:
- Weekly tuning report
- Tebex conversion review
- Discord activity review
- economy balancing
- security check
- launch/event planning
