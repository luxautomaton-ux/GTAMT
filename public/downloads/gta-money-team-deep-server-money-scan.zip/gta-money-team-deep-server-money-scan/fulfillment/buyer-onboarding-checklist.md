# Buyer Onboarding Checklist

Send this to every buyer.

## Required details

- Server name
- Discord invite
- Framework: QBCore / ESX / Qbox / standalone
- Hosting provider
- txAdmin access status
- Tebex store status
- Current player count
- Current monthly revenue estimate
- Biggest problem: access, Discord, store, security, economy, marketing, or scripts

## Buyer warnings

- Keep Cfx.re license key private.
- Keep Tebex secret private.
- Keep Discord bot token private.
- Do not upload purchased/private scripts publicly.
- Do not use real police logos, real gang branding, or copied server assets.
- All monetization must respect Cfx.re/Tebex rules.
