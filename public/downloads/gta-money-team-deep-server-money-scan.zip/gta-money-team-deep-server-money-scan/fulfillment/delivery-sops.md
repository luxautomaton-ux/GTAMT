# Delivery SOPs

## For every product order

1. Confirm buyer email, Discord tag, and server status.
2. Confirm framework: standalone, QBCore, ESX, Qbox, or undecided.
3. Confirm whether buyer needs docs only, files only, or DFY install.
4. Check compliance: no official Rockstar claims, no real gang branding, no stolen assets, no cheats.
5. Deliver ZIP + setup README.
6. Offer 30-minute setup call as upsell.
7. Add buyer to support channel if premium.
8. Log order, delivery date, and support status.

## Priority Queue Engine delivery

- Deliver role map.
- Deliver Tebex package copy.
- Deliver queue point matrix.
- Deliver Discord role setup guide.
- Optional: install or configure queue resource.

## City Identity Pack delivery

- Deliver city lore.
- Deliver districts and landmarks.
- Deliver factions.
- Deliver money loops.
- Deliver weather plan.
- Deliver launch trailer prompt.
- Deliver police/EMS placeholders.

## Security Audit delivery

- Ask for resource list.
- Review server.cfg secrets and permissions.
- Review risky client-to-server event patterns.
- Review admin roles.
- Review backup routine.
- Deliver risk report and fix list.
