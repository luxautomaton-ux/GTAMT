# Install Into Your App

Your app is running at localhost:5173, so install this locally in the project folder.

```bash
# from inside this extracted pack
cp -R app-drop-in/src/commerce/deepMoney /path/to/YOUR_APP/src/commerce/
cp app-drop-in/src/styles/deep-server-money-scan.css /path/to/YOUR_APP/src/styles/
```

Then add a route/page:

```jsx
import TopServerBlueprint from './commerce/deepMoney/TopServerBlueprint.jsx';
import './styles/deep-server-money-scan.css';

export default function MoneyIntelPage() {
  return <TopServerBlueprint />;
}
```

Suggested navigation label:

- Money Intel
- Template Vault Intel
- Server Money Scan

Suggested member gate:

- Free users can see the market overview.
- Premium users can use calculators and request products.
- Ops users can export leads and fulfillment tasks.
