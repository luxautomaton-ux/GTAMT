# Market Patterns to Turn Into Sellable Templates

## 1. Priority ladder
Sell a queue and access template, not in-game power. Include tier names, price suggestions, Discord roles, queue points, support FAQ, and cancellation copy.

## 2. Whitelist/application machine
Sell application forms, interview scripts, staff scoring rubrics, non-guarantee acceptance language, and premium processing SLA templates.

## 3. Discord commerce roles
Sell a role/channel matrix for Tebex fulfillment: buyer role, supporter role, priority role, faction role, business owner role, support ticket roles, staff escalation roles.

## 4. Faction identity pack
Sell fictional org docs: name, ranks, turf proposal, conduct rules, payout splits, recruitment script, Discord structure, event storylines.

## 5. Business ownership pack
Sell RP business docs: owner agreement, payroll, menu template, pricing table, employee roles, events, tax/sink logic, staff approval checklist.

## 6. Department pack
Sell fictional police/EMS/DOJ/Sheriff/Mechanic department SOPs, academy, training roster, vehicle placeholder list, radio codes, and audit rules.

## 7. Security audit
Sell defensive review: ACE permissions, resource order, database backup, bot token hygiene, webhook privacy, staff abuse prevention, banned resource scan.

## 8. Tebex store blueprint
Sell product categories, page copy, terms, support FAQ, fulfillment notes, safe disclaimers, upgrade ladder, and bundle plans.

## 9. Creator promo pack
Sell YouTube/Shorts scripts, Argil prompts, trailer storyboards, thumbnails, Discord announcement copy, streamer application docs.

## 10. Monthly ops retainer
Sell recurring economy tune-ups, security checks, event calendars, staff training, store optimization, community reporting.
