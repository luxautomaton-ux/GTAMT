# Discord Server Template — GTA Money Team RP

Use this as the included bonus product for your paid pack.

## Category: START HERE
- #welcome
- #rules
- #announcements
- #server-status
- #how-to-join

## Category: WHITELIST
- #applications
- #application-status
- #interview-waiting-room
- #approved-citizens

## Category: COMMUNITY
- #general
- #clips-and-screenshots
- #crew-recruitment
- #marketplace-rp
- #events

## Category: SUPPORT
- #open-a-ticket
- #bug-reports
- #player-reports
- #ban-appeals

## Category: STAFF ONLY
- #staff-chat
- #staff-announcements
- #mod-logs
- #incident-reports
- #economy-balance

## Roles
- Owner
- Admin
- Moderator
- Trial Staff
- Developer
- Whitelisted
- VIP
- Citizen
- Muted

## txAdmin Integration Notes
1. Create a bot in the Discord Developer Portal.
2. Copy the bot token once and store it securely.
3. Invite the bot with only the permissions you need.
4. Add Guild ID and token in txAdmin settings if you use txAdmin Discord features.
5. Never place bot tokens inside public templates or client-side files.
