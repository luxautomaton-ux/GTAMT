# Customization Guide

## Change Server Branding
Edit these files:
- `server.cfg` for public server name, tags, and project description.
- `resources/[lux]/lux_core/config.lua` for in-game messages.
- `docs/DISCORD_TEMPLATE.md` for community channels and roles.

## Add Spawn Points
1. Join your test server with a coordinate tool.
2. Copy x, y, z, and heading.
3. Add a new object to `Config.SpawnPoints` in `lux_core/config.lua`.
4. Restart `lux_core` or restart the server.

Example:
```lua
{
    id = 'airport',
    label = 'Los Santos Airport',
    x = -1037.74,
    y = -2737.75,
    z = 20.16,
    heading = 330.0
}
```

## Add a New Resource
1. Create a folder inside `resources/[lux]/your_resource_name`.
2. Add `fxmanifest.lua`.
3. Add client/server scripts.
4. Add `ensure your_resource_name` to `server.cfg` below dependencies.

## Turn This Into a QBCore/ESX Pack
This starter is framework-free. To extend it:
- Install QBCore or ESX using txAdmin recipes.
- Keep `lux_core` as a teaching/admin helper resource.
- Move persistent player data into the framework database.
- Replace temporary role labels with framework groups/jobs.

## Security Checklist
- Replace all placeholders.
- Do not include real license keys or bot tokens in sold ZIPs.
- Test paid resources on a staging server.
- Restrict staff permissions with ACE groups.
- Keep logs of staff actions.
