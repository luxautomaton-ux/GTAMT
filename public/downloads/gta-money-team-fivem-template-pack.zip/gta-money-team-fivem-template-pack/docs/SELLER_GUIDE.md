# Seller Guide — How to Package This as a Paid Template

## Product Name Ideas
- GTA Money Team RP Starter City
- Legal RP Server Launch Kit
- FiveM Founder Starter Pack
- Streamer RP Server Blueprint

## Suggested Pricing
- Basic Template ZIP: $49-$99
- Template + Discord Setup: $149-$249
- DFY Install + 7 Day Support: $299-$499
- Custom Economy / Jobs / Maps: $799+

## What Buyers Get
- Commented `server.cfg`
- Clean resource structure
- Core Lua scripts for players, permissions, and spawns
- Discord channel/role blueprint
- Setup and customization guide
- Legal RP positioning: no cheats, no exploit scripts, no stolen assets

## Upsells
- Staff training call
- Discord buildout
- Server logo/banner design
- QBCore or ESX conversion
- Tebex store setup
- Streamer launch package

## Delivery Checklist
1. Remove your private license keys and secrets.
2. Zip the pack.
3. Include buyer instructions.
4. Add a support boundary: install support is included, custom development is extra.
5. Keep version numbers so buyers know what changed.
