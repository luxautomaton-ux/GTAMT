--[[
    GTA Money Team RP Core Config
    Edit this file first when customizing your city.
    Keep secrets out of this file. Do not store Discord bot tokens here.
]]

Config = Config or {}

-- Basic server branding used by welcome messages and logs.
Config.ServerName = 'GTA Money Team RP'
Config.Brand = 'Lux Automaton'
Config.DefaultRole = 'player'

-- Feature flags let you turn starter systems on/off without deleting code.
Config.EnableWelcomeMessage = true
Config.EnableAutoSpawn = true
Config.EnablePlayerListCommand = true
Config.EnableRoleCommands = true
Config.Debug = false

-- Starter spawn points. Add more as your city grows.
-- Coordinates can be copied from a trusted admin coordinate tool.
Config.SpawnPoints = {
    {
        id = 'legion',
        label = 'Legion Square',
        x = 195.17,
        y = -933.77,
        z = 30.69,
        heading = 144.0
    },
    {
        id = 'sandy',
        label = 'Sandy Shores',
        x = 1853.35,
        y = 3689.78,
        z = 34.27,
        heading = 210.0
    },
    {
        id = 'paleto',
        label = 'Paleto Bay',
        x = -104.40,
        y = 6469.19,
        z = 31.63,
        heading = 45.0
    }
}

-- Role definitions for in-memory staff assignment.
-- ACE permissions still control real security. These labels are for UX/logging.
Config.Roles = {
    player = {
        label = 'Player',
        priority = 1
    },
    helper = {
        label = 'Helper',
        priority = 5
    },
    moderator = {
        label = 'Moderator',
        priority = 10,
        ace = 'lux.moderator'
    },
    admin = {
        label = 'Admin',
        priority = 20,
        ace = 'lux.admin'
    }
}

-- Chat/welcome messaging.
Config.WelcomeLines = {
    'Welcome to GTA Money Team RP.',
    'Play smart, respect the rules, and build your story the legal way.',
    'Use /whoami to view your server profile and /spawns to see spawn options.'
}
