--[[
    Client Spawn Manager
    Handles first spawn and manual starter spawn selection.
    This resource keeps spawn behavior simple and transparent.
]]

GMTClient = GMTClient or {}
GMTClient.Spawns = GMTClient.Spawns or {}
GMTClient.HasSpawned = false

--- Find a spawn by id, or return the first configured spawn.
--- @param spawnId string|nil
--- @return table|nil
function GMTClient.findSpawn(spawnId)
    if not GMTClient.Spawns or #GMTClient.Spawns == 0 then
        return nil
    end

    if spawnId and spawnId ~= '' then
        for _, spawn in ipairs(GMTClient.Spawns) do
            if spawn.id == spawnId then
                return spawn
            end
        end
    end

    return GMTClient.Spawns[1]
end

--- Moves the local player to a spawn point safely.
--- @param spawn table
function GMTClient.spawnAt(spawn)
    if not spawn then
        print('[GMT] No spawn point available.')
        return
    end

    local ped = PlayerPedId()

    -- Fade out to make the transition cleaner.
    DoScreenFadeOut(500)
    Wait(600)

    RequestCollisionAtCoord(spawn.x, spawn.y, spawn.z)
    SetEntityCoordsNoOffset(ped, spawn.x, spawn.y, spawn.z, false, false, false)
    SetEntityHeading(ped, spawn.heading or 0.0)
    NetworkResurrectLocalPlayer(spawn.x, spawn.y, spawn.z, spawn.heading or 0.0, true, false)
    ClearPedTasksImmediately(ped)
    FreezeEntityPosition(ped, false)

    Wait(500)
    DoScreenFadeIn(500)

    TriggerEvent('chat:addMessage', {
        color = { 0, 220, 255 },
        args = { 'Spawn', ('Loaded at %s.'):format(spawn.label or spawn.id or 'spawn') }
    })
end

RegisterNetEvent('lux_core:client:receiveSpawns', function(spawns)
    GMTClient.Spawns = spawns or {}

    if Config.EnableAutoSpawn and not GMTClient.HasSpawned then
        GMTClient.HasSpawned = true
        GMTClient.spawnAt(GMTClient.findSpawn())
    end
end)

RegisterNetEvent('lux_core:client:goToSpawn', function(spawnId)
    local spawn = GMTClient.findSpawn(spawnId)
    GMTClient.spawnAt(spawn)
end)

-- Request spawn points shortly after session start.
CreateThread(function()
    Wait(2000)
    TriggerServerEvent('lux_core:server:requestSpawns')
end)
