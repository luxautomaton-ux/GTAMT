--[[
    Client Main
    Receives profile data and offers player-friendly starter commands.
]]

GMTClient.Profile = nil

RegisterNetEvent('lux_core:client:receiveProfile', function(profile)
    GMTClient.Profile = profile
    print(('[GMT] Profile received: %s (%s)'):format(profile.name or 'Unknown', profile.roleLabel or 'Player'))
end)

-- Ask the server for profile information after loading.
CreateThread(function()
    Wait(3000)
    TriggerServerEvent('lux_core:server:requestProfile')
end)

-- /spawns lists available spawn IDs in chat.
RegisterCommand('spawns', function()
    if not GMTClient.Spawns or #GMTClient.Spawns == 0 then
        TriggerEvent('chat:addMessage', {
            color = { 255, 200, 80 },
            args = { 'Spawns', 'No spawns loaded yet. Try again in a few seconds.' }
        })
        return
    end

    local lines = {}
    for _, spawn in ipairs(GMTClient.Spawns) do
        lines[#lines + 1] = ('%s - %s'):format(spawn.id, spawn.label)
    end

    TriggerEvent('chat:addMessage', {
        color = { 0, 220, 255 },
        multiline = true,
        args = { 'Spawns', table.concat(lines, '\n') .. '\nUse /gotoSpawn [id] to move during testing.' }
    })
end, false)
