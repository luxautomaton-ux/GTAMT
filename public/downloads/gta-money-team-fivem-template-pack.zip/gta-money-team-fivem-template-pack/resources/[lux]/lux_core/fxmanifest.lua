-- GTA Money Team Core Resource Manifest
-- Every FiveM resource needs an fxmanifest.lua file so FXServer knows
-- which client, server, shared, and config files to load.

fx_version 'cerulean'
game 'gta5'

author 'Lux Automaton'
description 'GTA Money Team RP starter core: player management, permissions, spawns, and utility commands.'
version '1.0.0'

lua54 'yes'

shared_scripts {
    'shared/utils.lua',
    'config.lua'
}

server_scripts {
    'server/permissions.lua',
    'server/player_manager.lua',
    'server/main.lua'
}

client_scripts {
    'client/spawn_manager.lua',
    'client/main.lua'
}
