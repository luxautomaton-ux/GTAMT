--[[
    Shared Utility Functions
    These helpers are loaded on both client and server.
    Keep them dependency-free so the pack remains easy to sell and extend.
]]

GMT = GMT or {}

--- Safely returns a fallback when a value is nil.
--- @param value any
--- @param fallback any
function GMT.default(value, fallback)
    if value == nil then
        return fallback
    end
    return value
end

--- Trims whitespace from a string.
--- @param input string
--- @return string
function GMT.trim(input)
    if type(input) ~= 'string' then
        return ''
    end
    return (input:gsub('^%s*(.-)%s*$', '%1'))
end

--- Sends a consistent debug message when Config.Debug is enabled.
--- Works on server and client because print is available in both contexts.
--- @param message string
function GMT.debug(message)
    if Config and Config.Debug then
        print(('[GMT DEBUG] %s'):format(tostring(message)))
    end
end

--- Creates a readable display name from a player source.
--- On the server, GetPlayerName exists. On client, this fallback remains safe.
--- @param source any
--- @return string
function GMT.safeName(source)
    if GetPlayerName then
        local name = GetPlayerName(source)
        if name and name ~= '' then
            return name
        end
    end
    return ('Player %s'):format(tostring(source or '?'))
end
