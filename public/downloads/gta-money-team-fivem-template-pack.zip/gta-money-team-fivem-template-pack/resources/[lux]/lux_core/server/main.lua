--[[
    GTA Money Team Core Commands & Events
    These commands are safe starter examples. They teach buyers how to build
    their own admin and player utilities without using harmful tools.
]]

-- Tell the console the resource started successfully.
CreateThread(function()
    print(('^2[%s]^7 lux_core started. Legal RP starter systems online.'):format(Config.ServerName))
end)

-- Client requests a profile after joining.
RegisterNetEvent('lux_core:server:requestProfile', function()
    local src = source
    GMTPlayers.register(src)
    TriggerClientEvent('lux_core:client:receiveProfile', src, GMTPermissions.getProfile(src))
end)

-- Client requests spawn list.
RegisterNetEvent('lux_core:server:requestSpawns', function()
    TriggerClientEvent('lux_core:client:receiveSpawns', source, Config.SpawnPoints)
end)

-- /whoami shows the player's current starter profile.
RegisterCommand('whoami', function(source)
    if source == 0 then
        print('This command is for in-game players.')
        return
    end

    local profile = GMTPermissions.getProfile(source)
    local msg = ('Name: %s | ID: %s | Role: %s | Admin: %s | Moderator: %s'):format(
        profile.name,
        profile.source,
        profile.roleLabel,
        tostring(profile.isAdmin),
        tostring(profile.isModerator)
    )

    GMTPlayers.message(source, 'Profile', msg)
end, false)

-- /players lists connected players. Moderators/admins only.
RegisterCommand('players', function(source)
    if source ~= 0 and not GMTPermissions.isModerator(source) then
        GMTPlayers.message(source, 'Access Denied', 'You need moderator permission to use /players.', { 255, 80, 80 })
        return
    end

    local rows = GMTPlayers.list()
    local lines = {}

    for _, row in ipairs(rows) do
        lines[#lines + 1] = ('[%s] %s - %s - online %ss'):format(row.source, row.name, row.role, row.onlineSeconds)
    end

    local output = #lines > 0 and table.concat(lines, '\n') or 'No players tracked yet.'

    if source == 0 then
        print(output)
    else
        GMTPlayers.message(source, 'Online Players', output)
    end
end, false)

-- /setrole [id] [role] gives a temporary role label. Admin only.
RegisterCommand('setrole', function(source, args)
    if source ~= 0 and not GMTPermissions.isAdmin(source) then
        GMTPlayers.message(source, 'Access Denied', 'You need admin permission to use /setrole.', { 255, 80, 80 })
        return
    end

    local target = tonumber(args[1] or '')
    local role = tostring(args[2] or '')

    if not target or not GetPlayerName(target) then
        local msg = 'Usage: /setrole [playerId] [player|helper|moderator|admin]'
        if source == 0 then print(msg) else GMTPlayers.message(source, 'Usage', msg) end
        return
    end

    local ok, result = GMTPermissions.setRole(target, role)
    GMTPlayers.register(target)

    if ok then
        GMTPlayers.message(target, 'Role Updated', result)
        if source ~= 0 then
            GMTPlayers.message(source, 'Role Updated', ('%s: %s'):format(GMT.safeName(target), result))
        else
            print(('Role updated for %s: %s'):format(GMT.safeName(target), result))
        end
    else
        if source == 0 then print(result) else GMTPlayers.message(source, 'Role Error', result, { 255, 80, 80 }) end
    end
end, false)

-- /gotoSpawn [spawnId] lets players move to starter spawn points for testing.
-- You can disable this on live RP servers or restrict it to staff.
RegisterCommand('gotoSpawn', function(source, args)
    if source == 0 then
        print('This command is for in-game players.')
        return
    end

    local spawnId = GMT.trim(args[1] or '')
    TriggerClientEvent('lux_core:client:goToSpawn', source, spawnId)
end, false)
