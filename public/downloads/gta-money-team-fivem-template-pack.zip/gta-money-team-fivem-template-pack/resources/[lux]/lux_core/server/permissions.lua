--[[
    Server Permissions Module
    This combines real ACE checks with simple in-memory role labels.
    ACE permissions are the actual security layer; role labels are just a
    lightweight starter system for commands and UI feedback.
]]

GMTPermissions = GMTPermissions or {}
GMTPermissions.PlayerRoles = GMTPermissions.PlayerRoles or {}

--- Get the currently assigned role for a player.
--- @param source number
--- @return string
function GMTPermissions.getRole(source)
    return GMTPermissions.PlayerRoles[source] or Config.DefaultRole or 'player'
end

--- Set a temporary role for a connected player.
--- For a production server, persist roles in a database or framework.
--- @param source number
--- @param role string
--- @return boolean, string
function GMTPermissions.setRole(source, role)
    role = GMT.trim(role)

    if not Config.Roles[role] then
        return false, ('Unknown role: %s'):format(role)
    end

    GMTPermissions.PlayerRoles[source] = role
    return true, ('Role updated to %s'):format(Config.Roles[role].label)
end

--- Check if a player has a named ACE permission.
--- @param source number
--- @param ace string
--- @return boolean
function GMTPermissions.hasAce(source, ace)
    if not ace or ace == '' then
        return false
    end

    return IsPlayerAceAllowed(source, ace) == true
end

--- Check whether a player can use admin actions.
--- @param source number
--- @return boolean
function GMTPermissions.isAdmin(source)
    return GMTPermissions.hasAce(source, 'lux.admin')
end

--- Check whether a player can use moderator actions.
--- Admins inherit moderator ability.
--- @param source number
--- @return boolean
function GMTPermissions.isModerator(source)
    return GMTPermissions.isAdmin(source) or GMTPermissions.hasAce(source, 'lux.moderator')
end

--- Builds a safe profile object for commands/UI.
--- @param source number
--- @return table
function GMTPermissions.getProfile(source)
    local role = GMTPermissions.getRole(source)
    local roleInfo = Config.Roles[role] or Config.Roles.player

    return {
        source = source,
        name = GMT.safeName(source),
        role = role,
        roleLabel = roleInfo.label or role,
        isAdmin = GMTPermissions.isAdmin(source),
        isModerator = GMTPermissions.isModerator(source)
    }
end

-- Clean up memory when a player leaves.
AddEventHandler('playerDropped', function()
    GMTPermissions.PlayerRoles[source] = nil
end)
