--[[
    Server Player Manager
    Tracks connected players, sends welcome messages, and exposes admin-safe
    player utilities. This is intentionally simple so buyers can learn from it.
]]

GMTPlayers = GMTPlayers or {}
GMTPlayers.Active = GMTPlayers.Active or {}

--- Register/refresh a player in the active session table.
--- @param source number
function GMTPlayers.register(source)
    local profile = GMTPermissions.getProfile(source)

    GMTPlayers.Active[source] = {
        source = source,
        name = profile.name,
        role = profile.role,
        joinedAt = os.time()
    }

    GMT.debug(('Registered player %s (%s)'):format(profile.name, source))
end

--- Remove a player from the active table.
--- @param source number
function GMTPlayers.unregister(source)
    GMTPlayers.Active[source] = nil
end

--- Return a list of connected player summary rows.
--- @return table
function GMTPlayers.list()
    local rows = {}

    for source, data in pairs(GMTPlayers.Active) do
        rows[#rows + 1] = {
            source = source,
            name = data.name,
            role = data.role,
            onlineSeconds = os.time() - (data.joinedAt or os.time())
        }
    end

    table.sort(rows, function(a, b)
        return a.source < b.source
    end)

    return rows
end

--- Sends a chat message to one player.
--- @param target number
--- @param title string
--- @param message string
--- @param color table|nil
function GMTPlayers.message(target, title, message, color)
    TriggerClientEvent('chat:addMessage', target, {
        color = color or { 0, 220, 255 },
        multiline = true,
        args = { title or Config.ServerName, message }
    })
end

--- Sends configured welcome lines to a player.
--- @param target number
function GMTPlayers.sendWelcome(target)
    if not Config.EnableWelcomeMessage then
        return
    end

    for _, line in ipairs(Config.WelcomeLines or {}) do
        GMTPlayers.message(target, Config.ServerName, line)
    end
end

-- playerJoining fires when the player is entering the server session.
AddEventHandler('playerJoining', function()
    local src = source
    GMTPlayers.register(src)

    -- Delay lets chat load before the message arrives.
    SetTimeout(2500, function()
        if GetPlayerName(src) then
            GMTPlayers.sendWelcome(src)
        end
    end)
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local name = GMT.safeName(src)
    GMT.debug(('%s left server: %s'):format(name, tostring(reason)))
    GMTPlayers.unregister(src)
end)
