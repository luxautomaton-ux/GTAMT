--[[
    Chat Helper Client
    Displays a quick command hint after a player joins.
]]

CreateThread(function()
    Wait(6000)
    TriggerEvent('chat:addMessage', {
        color = { 0, 220, 255 },
        multiline = true,
        args = {
            'GTA Money Team',
            'Type /helpme for starter commands. Play smart, stay legal, and build your RP story.'
        }
    })
end)
