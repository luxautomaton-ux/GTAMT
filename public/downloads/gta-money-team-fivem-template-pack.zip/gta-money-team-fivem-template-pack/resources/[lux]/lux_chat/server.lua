--[[
    Chat Helper Server Commands
    Adds simple RP onboarding commands without depending on a framework.
]]

local function sendMessage(target, title, message, color)
    TriggerClientEvent('chat:addMessage', target, {
        color = color or { 0, 220, 255 },
        multiline = true,
        args = { title, message }
    })
end

RegisterCommand('rules', function(source)
    if source == 0 then
        print('Rules command is for players in-game.')
        return
    end

    sendMessage(source, 'Server Rules', table.concat({
        '1. Respect players and staff.',
        '2. No cheating, exploiting, griefing, or harassment.',
        '3. Keep RP stories realistic and fair.',
        '4. Do not sell in-game power outside approved rules.',
        '5. Report bugs privately instead of abusing them.'
    }, '\n'))
end, false)

RegisterCommand('discord', function(source)
    if source == 0 then
        print('Discord command is for players in-game.')
        return
    end

    -- Replace the invite before selling or launching the server.
    sendMessage(source, 'Discord', 'Join the community: https://discord.gg/REPLACE_ME')
end, false)

RegisterCommand('helpme', function(source)
    if source == 0 then
        print('Help command is for players in-game.')
        return
    end

    sendMessage(source, 'Help', table.concat({
        '/rules - View server rules',
        '/discord - Get Discord invite',
        '/whoami - View your profile',
        '/spawns - List spawn points',
        '/gotoSpawn [id] - Test starter spawn routing'
    }, '\n'))
end, false)
