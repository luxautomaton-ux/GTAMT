-- GTA Money Team Chat Helper Resource
-- Keeps onboarding/chat commands separate from core so buyers can expand it.

fx_version 'cerulean'
game 'gta5'

author 'Lux Automaton'
description 'GTA Money Team RP chat helper commands and legal RP reminders.'
version '1.0.0'

lua54 'yes'

server_script 'server.lua'
client_script 'client.lua'
