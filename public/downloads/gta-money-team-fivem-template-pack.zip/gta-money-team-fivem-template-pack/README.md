# GTA Money Team RP Starter Server Template

Premium FiveM / GTA V roleplay starter pack created by Lux Automaton.

This is an original, clean, legal server template you can sell as a starter product or use as the foundation for a custom client build. It includes sensible defaults, commented configuration files, framework-free Lua starter scripts, spawn handling, permissions, player tracking, and Discord/community setup notes.

## What This Pack Is

A teaching-first FiveM starter template for people with basic server knowledge who want a clean foundation they can understand and expand.

## What This Pack Is Not

This is not a cheat pack, mod menu, stolen script bundle, account exploit tool, or replica of another creator's private server. Keep your commercial product clean, legal, and original.

## Folder Overview

```text
server.cfg
config/
  permissions.cfg
  lux_settings.lua
  spawns.lua
resources/
  [lux]/
    lux_core/
      fxmanifest.lua
      config.lua
      shared/utils.lua
      server/permissions.lua
      server/player_manager.lua
      server/main.lua
      client/spawn_manager.lua
      client/main.lua
    lux_chat/
      fxmanifest.lua
      server.lua
      client.lua
docs/
  DISCORD_TEMPLATE.md
  CUSTOMIZATION_GUIDE.md
  SELLER_GUIDE.md
```

## Quick Setup With txAdmin

1. Install or open FXServer.
2. Let txAdmin open in your browser on first run.
3. Link your Cfx.re account and create your server profile.
4. Create or select your server data folder.
5. Copy this pack's `server.cfg`, `config`, `resources`, and `docs` folders into your server data folder.
6. Open `server.cfg` and replace `CHANGE_ME_CFX_RE_LICENSE_KEY` with your real Cfx.re license key.
7. Add your real staff identifiers under the ACE permission section.
8. Make sure TCP and UDP port `30120` are open.
9. Start the server.
10. Join and test `/helpme`, `/rules`, `/whoami`, `/spawns`, and `/gotoSpawn legion`.

## Manual Startup Example

From your FXServer folder, launch with your server config:

```bash
./FXServer +exec server.cfg
```

On Windows, use the FXServer executable or txAdmin panel.

## Core Files

### `server.cfg`
Controls network port, public server name, license key placeholder, default resources, Lux resources, and ACE permissions.

### `resources/[lux]/lux_core/config.lua`
Controls server branding, feature flags, roles, welcome messages, and spawn points.

### `resources/[lux]/lux_core/server/permissions.lua`
Shows a simple permissions layer using ACE checks for `lux.admin` and `lux.moderator`.

### `resources/[lux]/lux_core/server/player_manager.lua`
Tracks connected players in memory and sends welcome messages.

### `resources/[lux]/lux_core/client/spawn_manager.lua`
Spawns players at configured locations and supports `/gotoSpawn [id]`.

### `resources/[lux]/lux_chat`
Adds beginner-friendly commands: `/rules`, `/discord`, and `/helpme`.

## Customization Tips

- Change branding in `server.cfg` and `lux_core/config.lua`.
- Add more spawns in `Config.SpawnPoints`.
- Disable `/gotoSpawn` on a live RP server or restrict it to moderators.
- Add QBCore/ESX later if you want jobs, inventory, housing, and persistence.
- Store permanent roles and character data in a database for production.

## Recommended Launch Flow

1. Test locally.
2. Test on a private VPS.
3. Add Discord template.
4. Recruit 5-10 testers.
5. Fix bugs and balance rules.
6. Add jobs/economy/inventory.
7. Add Tebex/approved monetization only after the server is stable.

## Support Boundary For Paid Buyers

Suggested sales language:

> This template includes setup instructions and starter support. Custom scripts, framework conversion, database setup, Discord buildout, branding, maps, and economy balancing are available as paid upgrades.

## Version

- Version: 1.0.0
- Created: 2026-07-06
- Creator: Lux Automaton
```
