--[[
    Spawn reference file.
    The active spawn list is inside resources/[lux]/lux_core/config.lua.
    Use this file as a safe scratchpad when planning new spawn points.
]]

GMTSpawns = {
    { label = "Legion Square", x = 195.17, y = -933.77, z = 30.69, heading = 144.0 },
    { label = "Sandy Shores", x = 1853.35, y = 3689.78, z = 34.27, heading = 210.0 },
    { label = "Paleto Bay", x = -104.40, y = 6469.19, z = 31.63, heading = 45.0 }
}
