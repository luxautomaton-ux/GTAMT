--[[
    GTA Money Team RP Starter Settings
    This file is a human-readable reference copy.
    The active resource config lives at:
    resources/[lux]/lux_core/config.lua
]]

GMT = GMT or {}
GMT.ServerName = "GTA Money Team RP"
GMT.DefaultRole = "player"
GMT.EnableWelcomeMessage = true
GMT.EnableAutoSpawn = true
GMT.Debug = false
