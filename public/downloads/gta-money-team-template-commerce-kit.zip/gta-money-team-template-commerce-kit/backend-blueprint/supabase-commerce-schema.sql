-- GTA Money Team Commerce Schema
-- Use this as a starting point for Supabase/Postgres.
-- Do not trust client-side payment status. Verify Stripe/Tebex/PayPal webhooks server-side.

create table if not exists gmt_products (
  id text primary key,
  name text not null,
  category text not null,
  price_label text not null,
  anchor_price integer,
  active boolean default true,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);

create table if not exists gmt_leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  discord text,
  product_id text references gmt_products(id),
  budget text,
  timeline text,
  message text,
  status text default 'new',
  created_at timestamptz default now()
);

create table if not exists gmt_orders (
  id uuid primary key default gen_random_uuid(),
  product_id text references gmt_products(id),
  customer_email text not null,
  platform text check (platform in ('tebex','stripe','paypal','manual')),
  platform_order_id text,
  amount_cents integer,
  currency text default 'usd',
  status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists gmt_entitlements (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references gmt_orders(id),
  customer_email text not null,
  entitlement_key text not null,
  product_id text references gmt_products(id),
  expires_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists gmt_fulfillment_tasks (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references gmt_orders(id),
  title text not null,
  checklist jsonb default '[]'::jsonb,
  owner text default 'Lux Automaton',
  status text default 'queued',
  due_at timestamptz,
  created_at timestamptz default now()
);
