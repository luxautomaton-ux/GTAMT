# Payment Webhook Notes

Client-side buttons are good for testing, but real fulfillment should come from a server-verified webhook.

## Minimum production flow

1. Customer buys through Tebex/Stripe/PayPal.
2. Provider sends webhook to your backend.
3. Backend verifies signature.
4. Backend creates `gmt_orders` row.
5. Backend grants `gmt_entitlements` or creates a `gmt_fulfillment_tasks` row.
6. Customer receives download/setup instructions.

## Never do this

- Never mark an order paid just because the browser redirects to `/success`.
- Never accept Discord bot tokens in a public form.
- Never grant paid in-game currency, randomized rewards, weapons, drugs, or advantage packages.
- Never store raw secrets in the frontend.
