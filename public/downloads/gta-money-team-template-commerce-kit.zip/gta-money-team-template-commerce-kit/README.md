# GTA Money Team — Template Commerce Kit

Built for Lux Automaton / GTA Money Team to sell premium FiveM/GTA RP server templates, city packs, Discord setups, Tebex storefront blueprints, security audits, and monthly support retainers.

> Product promise: **Learn how to make money the legit way.**

This kit does **not** copy Tee Grizzley, GrizzleyWorld, NoPixel, paid private scripts, real police logos, real gang branding, or any copyrighted server assets. It studies public monetization patterns and turns them into original, legal, sellable systems.

## What is included

```text
app-drop-in/
  src/commerce/*                 React components, product data, calculators, store helpers
  src/styles/gmt-commerce.css    GTA Money Team marketplace styling
fivem-resources/[gmt]/gmt_commerce_engine/
  Lua demo resource for product entitlements, payouts, commands, and security reminders
server-products/
  Premium product folders with sales pages, buyer deliverables, setup guides, and fulfillment checklists
tebex-products/
  CSV + JSON package blueprints for safe store categories
discord-templates/
  Community setup, channels, roles, ticket flow, and applications
youtube-promo/
  Video scripts, thumbnail prompts, and 30-day faceless content calendar
legal-and-compliance/
  Cfx/Tebex-safe rules, asset/IP checklist, and monetization guardrails
research/
  GitHub + YouTube scan notes
backend-blueprint/
  Supabase-style schema for products, leads, orders, entitlements, and fulfillment
```

## Fast install into your current app

1. Copy `app-drop-in/src/commerce` into your app: `src/commerce`.
2. Copy `app-drop-in/src/styles/gmt-commerce.css` into your app: `src/styles/gmt-commerce.css`.
3. Import the marketplace component wherever you want the selling page:

```jsx
import TemplateMarketplace from './commerce/components/TemplateMarketplace.jsx';
import './styles/gmt-commerce.css';

export default function ServicesPage() {
  return <TemplateMarketplace />;
}
```

4. Edit `app-drop-in/src/commerce/paymentLinks.js` and replace placeholder URLs with your real Tebex/Stripe/PayPal links. For FiveM server perks, use Tebex as the compliant path. For selling template ZIPs/services outside the server, you can also use Stripe/PayPal.
5. Add your Discord invite, support email, and template download delivery flow.

## Best offer ladder

- Free lead magnet: Server launch checklist
- $99 entry product: Discord Community Machine or Tebex Store Blueprint
- $149-$299 core product: Access/Queue Pack, Gang Pack, Security Pack
- $499-$899 flagship: Celebrity-Scale RP Launch Pack
- $999-$1,499 bundle: Full Template Vault Bundle
- $249-$499/mo recurring: Monthly Ops Retainer
- $1,800+ high ticket: Custom city/server build

## Important compliance note

For FiveM/RedM server monetization, use authorized Cfx.re monetization systems and avoid pay-to-win, randomized paid rewards, real-world brand infringement, stolen scripts, leaked cars, copied MLOs, copied server identities, fake GTA VI claims, and anything that creates account/security risk.
