# Asset and IP Rules

- Use original city names or clearly fictionalized city identities.
- City inspiration is okay; copying actual government/police logos is not.
- Do not package paid vehicles, maps, MLOs, EUP, or scripts unless you own resale rights.
- Do not clone Tee Grizzley, GrizzleyWorld, NoPixel, or any other server identity.
- Do not claim official GTA VI affiliation.
- Do not sell fake beta keys, GTA coins, or mod menus.
- Keep GTA Money Team positioned as education, templates, service setup, and legal strategy.
