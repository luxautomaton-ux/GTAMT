# Cfx/Tebex-Safe Monetization Guardrails

Use this as a practical checklist before selling any server perk.

## Safer package categories

- Queue priority
- Access/application processing
- Supporter Discord roles
- Cosmetic/status recognition
- Staff-reviewed gang/business applications
- Template ZIPs and setup services
- Discord setup services
- Security audits
- Monthly support retainers

## Avoid selling

- Weapons
- Drugs
- In-game cash/currency
- Randomized paid rewards / loot boxes
- Exploit access
- Real police logos
- Real gang branding
- Real brand car/clothing logos without rights
- Leaked/private scripts
- Copied top-server assets

## Fulfillment rule

If a purchase affects server access or in-server perks, fulfill through compliant server monetization systems and verified webhooks. Do not grant based on screenshots or browser redirects.
