# Pricing and Offer Ladder

## Front-end products

- Server Launch Checklist: Free lead magnet
- Discord Community Machine: $99-$149
- Tebex Store Blueprint: $99-$199
- Single City Pack: $119-$159
- Security Audit Checklist Pack: $149-$199

## Core products

- Access & Queue Pack: $149-$249
- Gang Identity & Turf Pack: $199-$399
- Business Economy Pack: $299-$599
- Police/EMS/DOJ Pack: $249-$499
- Creator Streamer Pack: $149-$399

## Flagship offers

- Celebrity-Scale RP Launch Pack: $499-$899
- Full Template Vault Bundle: $999-$1,499
- Installed Server Identity: $549-$799

## High-ticket services

- DFY txAdmin/QBCore install: $299-$699
- Full custom city/server build: $1,800-$2,500+
- Script/security audit: $299-$499
- Monthly Ops Retainer: $249-$499/mo

## Funnel

YouTube/TikTok/Shorts -> Free checklist -> $99 pack -> $499 launch pack -> $1,499 bundle -> monthly support.
