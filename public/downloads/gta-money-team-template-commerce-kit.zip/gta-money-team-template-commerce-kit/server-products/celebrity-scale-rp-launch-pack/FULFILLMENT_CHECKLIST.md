# Fulfillment Checklist — Celebrity-Scale RP Launch Pack

## Before delivery

- Confirm payment/order ID.
- Confirm buyer email and Discord.
- Confirm whether this is a ZIP-only delivery or DFY install.
- Confirm framework: standalone, QBCore, ESX, vMenu, or custom.
- Confirm the buyer understands no stolen assets, real police logos, copied server brands, paid weapons, paid drugs, or paid cash.

## Build steps

- Prepare: Launch-day server identity map
- Prepare: Whitelist funnel
- Prepare: Discord community machine
- Prepare: Tebex-safe product ladder
- Prepare: Staff hiring checklist
- Prepare: Creator promo scripts
- Prepare: Launch calendar

## QA steps

- Check all files open.
- Confirm no third-party paid script is included without license.
- Confirm all placeholders are marked clearly.
- Confirm install instructions match the buyer's environment.
- Export final ZIP and delivery note.

## Upsell prompt

Recommended next offer: DFY txAdmin install, Custom city pack.
