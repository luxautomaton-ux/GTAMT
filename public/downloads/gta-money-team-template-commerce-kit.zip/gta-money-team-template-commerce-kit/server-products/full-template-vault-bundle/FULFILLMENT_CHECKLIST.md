# Fulfillment Checklist — Full Template Vault Bundle

## Before delivery

- Confirm payment/order ID.
- Confirm buyer email and Discord.
- Confirm whether this is a ZIP-only delivery or DFY install.
- Confirm framework: standalone, QBCore, ESX, vMenu, or custom.
- Confirm the buyer understands no stolen assets, real police logos, copied server brands, paid weapons, paid drugs, or paid cash.

## Build steps

- Prepare: All pack docs
- Prepare: App product catalog
- Prepare: Lead forms
- Prepare: Revenue calculators
- Prepare: Fulfillment checklists
- Prepare: Launch content

## QA steps

- Check all files open.
- Confirm no third-party paid script is included without license.
- Confirm all placeholders are marked clearly.
- Confirm install instructions match the buyer's environment.
- Export final ZIP and delivery note.

## Upsell prompt

Recommended next offer: $1,800+ custom city, $299/mo support.
