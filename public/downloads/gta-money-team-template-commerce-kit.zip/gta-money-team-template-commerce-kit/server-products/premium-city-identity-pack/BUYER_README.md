# Buyer README — Premium City Identity Pack

Thank you for purchasing from GTA Money Team.

## What to do first

1. Read the sales page and deliverables.
2. Open your setup ticket with your server name, framework, Discord, and launch goals.
3. Do not paste private tokens, passwords, database credentials, or bot secrets into public chat.
4. Use only original/licensed assets.

## Recommended install path

- Use txAdmin for basic FXServer deployment.
- Add framework resources like QBCore or ESX only if you understand their licenses and setup requirements.
- Add this pack's files after your base server is working.
- Test on a private dev server before public launch.

## Support boundary

This template is a launch system, not a guarantee of player count or revenue. Revenue depends on marketing, community quality, support, moderation, and compliance.
