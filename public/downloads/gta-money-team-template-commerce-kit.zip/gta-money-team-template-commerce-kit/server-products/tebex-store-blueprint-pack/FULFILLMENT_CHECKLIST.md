# Fulfillment Checklist — Tebex Store Blueprint Pack

## Before delivery

- Confirm payment/order ID.
- Confirm buyer email and Discord.
- Confirm whether this is a ZIP-only delivery or DFY install.
- Confirm framework: standalone, QBCore, ESX, vMenu, or custom.
- Confirm the buyer understands no stolen assets, real police logos, copied server brands, paid weapons, paid drugs, or paid cash.

## Build steps

- Prepare: Package category map
- Prepare: CSV package blueprint
- Prepare: Product descriptions
- Prepare: Legal-safe disclaimers
- Prepare: Launch sale plan
- Prepare: Coupon calendar

## QA steps

- Check all files open.
- Confirm no third-party paid script is included without license.
- Confirm all placeholders are marked clearly.
- Confirm install instructions match the buyer's environment.
- Export final ZIP and delivery note.

## Upsell prompt

Recommended next offer: Tebex implementation, Store art.
