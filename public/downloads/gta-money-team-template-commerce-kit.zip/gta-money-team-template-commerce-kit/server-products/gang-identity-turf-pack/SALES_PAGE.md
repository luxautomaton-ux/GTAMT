# Gang Identity & Turf Pack

**Price:** $199-$399  
**Category:** Roleplay Expansion

## Hook

Create fictional crews with turf rules, outfit placeholders, ranks, diplomacy, and payout discipline.

## Who this is for

Serious RP servers that need structure for gangs without chaos or real gang branding.

## What the buyer gets

- Fictional gang bible
- Turf zones
- Rank ladder
- Gang application form
- War approval SOP
- Crew payout sheet
- Discord category layout

## How this makes money

- Gang application review
- Cosmetic clothing access
- Crew event passes
- Monthly faction support

## Security and trust

- No real gang branding
- No random violence rules
- Staff approval for wars
- Evidence ticket workflow

## Upsells

- Custom gang logos
- Original clothing textures
- Faction balancing session

## Compliance note

Fictionalize all names, colors, logos, and stories. Avoid real gang identifiers or copyrighted apparel/brand marks.

## CTA

Buy the pack, then open a setup ticket with your city name, current framework, Discord link, staff size, desired launch date, and monetization goals.
