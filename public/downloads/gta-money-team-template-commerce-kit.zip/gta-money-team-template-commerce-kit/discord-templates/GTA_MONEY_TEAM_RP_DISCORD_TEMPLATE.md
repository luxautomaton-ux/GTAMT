# GTA Money Team RP Discord Template

## Category: Welcome

- #start-here
- #rules
- #announcements
- #server-status
- #how-to-join
- #supporter-info

## Category: Applications

- #whitelist-application
- #gang-application
- #business-application
- #police-application
- #ems-application
- #creator-application

## Category: Support Tickets

- #open-ticket
- #purchase-support
- #bug-reports
- #player-reports
- #ban-appeals

## Category: City Life

- #general
- #city-news
- #events
- #business-ads
- #content-clips

## Category: Staff Only

- #staff-chat
- #mod-log
- #payment-review
- #incident-reports
- #economy-watch

## Roles

Owner, Director, Admin, Moderator, Support, Developer, Police Chief, EMS Chief, DOJ Lead, Business Owner, Gang Lead, Creator Partner, Founder, Supporter, Whitelisted, Applicant.

## Security settings

- Require 2FA for staff.
- Keep bot tokens private.
- Use private ticket permissions.
- Do not allow public channels to see payment/order data.
- Separate moderation from development permissions.
