-- Security helper functions.
-- This file is intentionally defensive and educational.

GMTSecurity = GMTSecurity or {}

function GMTSecurity.HasAce(source, permission)
    -- ACE permission check. Add principals in server.cfg.
    -- Example: add_ace group.admin gmt.admin allow
    return IsPlayerAceAllowed(source, permission)
end

function GMTSecurity.RequireAdmin(source)
    if source == 0 then return true end -- console can run commands
    if GMTSecurity.HasAce(source, 'gmt.admin') then return true end
    GMTUtils.Chat(source, 'Access denied. Staff permission required.')
    return false
end

function GMTSecurity.PrintChecklist(source)
    for index, item in ipairs(GMT.SecurityChecklist) do
        GMTUtils.Chat(source, ('%s. %s'):format(index, item))
    end
end
