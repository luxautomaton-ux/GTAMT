GMTPayouts = GMTPayouts or {}

function GMTPayouts.Describe(modelName)
    local model = GMT.PayoutModels[modelName]
    if not model then return nil end
    return GMTUtils.PercentLine(model)
end

function GMTPayouts.ListModels(source)
    for modelName, model in pairs(GMT.PayoutModels) do
        GMTUtils.Chat(source, modelName .. ' => ' .. GMTUtils.PercentLine(model))
    end
end
