RegisterCommand('gmtstore', function(source)
    GMTUtils.Chat(source, GMT.Brand.tagline)
    GMTUtils.Chat(source, 'Safe package ideas:')
    for _, package in ipairs(GMT.SafeStorePackages) do
        GMTUtils.Chat(source, ('%s — $%s — %s'):format(package.label, package.recommendedPrice, package.description))
    end
end, false)

RegisterCommand('gmtpayouts', function(source)
    GMTPayouts.ListModels(source)
end, false)

RegisterCommand('gmtsecurity', function(source)
    GMTSecurity.PrintChecklist(source)
end, false)

RegisterCommand('gmtgrantdemo', function(source, args)
    if not GMTSecurity.RequireAdmin(source) then return end
    local target = tonumber(args[1] or '')
    local packageId = args[2]
    if not target or not packageId then
        GMTUtils.Chat(source, 'Usage: /gmtgrantdemo [playerId] [packageId]')
        return
    end
    GMTEntitlements.Grant(target, packageId, 'admin_demo_grant')
    GMTUtils.Chat(source, ('Granted demo package %s to player %s.'):format(packageId, target))
end, false)

RegisterCommand('gmtentitlements', function(source)
    TriggerEvent('gmt_commerce:server:requestMyEntitlements')
end, false)

AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    GMTUtils.Console('Commerce engine started. Use /gmtstore, /gmtpayouts, /gmtsecurity.')
end)
