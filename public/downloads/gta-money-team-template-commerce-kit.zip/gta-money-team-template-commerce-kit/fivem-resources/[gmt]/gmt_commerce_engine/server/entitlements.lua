-- In-memory entitlement demo.
-- Production should store this in a database and grant it only from verified Tebex/Stripe/PayPal webhooks.
-- Do NOT let clients trigger paid entitlements directly.

GMTEntitlements = GMTEntitlements or {}
GMTEntitlements.players = GMTEntitlements.players or {}

local function getIdentifier(source)
    -- license: identifier is usually the safest FiveM player identity key.
    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        if identifier:find('license:') == 1 then
            return identifier
        end
    end
    return ('source:%s'):format(source)
end

function GMTEntitlements.Grant(source, packageId, reason)
    local identifier = getIdentifier(source)
    GMTEntitlements.players[identifier] = GMTEntitlements.players[identifier] or {}
    GMTEntitlements.players[identifier][packageId] = {
        grantedAt = os.time(),
        reason = reason or 'manual'
    }
    GMTUtils.Console(('Granted %s to %s (%s)'):format(packageId, identifier, reason or 'manual'))
    return true
end

function GMTEntitlements.List(source)
    local identifier = getIdentifier(source)
    return GMTEntitlements.players[identifier] or {}
end

RegisterNetEvent('gmt_commerce:server:requestMyEntitlements', function()
    local source = source
    local entitlements = GMTEntitlements.List(source)
    local count = 0
    for packageId in pairs(entitlements) do
        count = count + 1
        GMTUtils.Chat(source, 'Entitlement: ' .. packageId)
    end
    if count == 0 then
        GMTUtils.Chat(source, 'No demo entitlements found. Supporter perks must be granted by verified server-side fulfillment.')
    end
end)
