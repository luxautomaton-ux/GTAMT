fx_version 'cerulean'
game 'gta5'

name 'gmt_commerce_engine'
author 'Lux Automaton / GTA Money Team'
description 'Legal FiveM RP commerce helper: access tiers, safe supporter perks, payout planning, and ops reminders.'
version '1.0.0'

lua54 'yes'

shared_scripts {
    'config.lua',
    'shared/utils.lua'
}

server_scripts {
    'server/security.lua',
    'server/entitlements.lua',
    'server/payouts.lua',
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}
