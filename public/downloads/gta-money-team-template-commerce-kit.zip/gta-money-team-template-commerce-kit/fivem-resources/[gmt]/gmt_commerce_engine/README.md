# gmt_commerce_engine

A legal, educational FiveM resource for GTA Money Team template buyers. It demonstrates safe store package ideas, crew payout models, entitlement placeholders, and security reminders.

## Install

1. Copy `gmt_commerce_engine` into your server resources folder.
2. Add this to `server.cfg`:

```cfg
ensure gmt_commerce_engine
add_ace group.admin gmt.admin allow
add_principal identifier.license:YOUR_LICENSE_HERE group.admin
```

3. Start the server and test:

```text
/gmthelp
/gmtstore
/gmtpayouts
/gmtsecurity
```

## Production warning

This resource does not verify payments. Real paid fulfillment must come from a verified Tebex/Stripe/PayPal webhook and a server-side database.
