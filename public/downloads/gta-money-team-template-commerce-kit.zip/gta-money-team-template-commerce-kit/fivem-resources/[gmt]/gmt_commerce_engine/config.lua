GMT = GMT or {}

-- Core brand settings shown in chat commands.
GMT.Brand = {
    name = 'GTA Money Team',
    tagline = 'Learn how to make money the legit way.',
    supportDiscord = 'discord.gg/YOUR_INVITE'
}

-- IMPORTANT: Keep monetization cosmetic, access-based, community-support oriented, or service-based.
-- Do NOT sell weapons, drugs, exploit access, paid in-game cash, randomized rewards, or copyrighted assets.
GMT.SafeStorePackages = {
    {
        id = 'server_access',
        label = 'Server Access Pass',
        type = 'access',
        recommendedPrice = 35,
        description = 'Application/access processing and community support. Manual approval still required.'
    },
    {
        id = 'queue_priority_1',
        label = 'Level 1 Queue Priority',
        type = 'queue',
        recommendedPrice = 25,
        description = 'Queue priority only. No gameplay advantage.'
    },
    {
        id = 'founder_badge',
        label = 'Founder Badge',
        type = 'cosmetic_status',
        recommendedPrice = 15,
        description = 'Discord/community recognition only.'
    },
    {
        id = 'gang_application_review',
        label = 'Gang Application Review',
        type = 'review_service',
        recommendedPrice = 45,
        description = 'Staff-reviewed faction setup request. Does not guarantee approval or advantage.'
    },
    {
        id = 'business_application_review',
        label = 'Business Application Review',
        type = 'review_service',
        recommendedPrice = 45,
        description = 'Staff-reviewed business proposal. Does not grant free money or unfair assets.'
    }
}

-- Crew payout templates for legal RP jobs and events.
GMT.PayoutModels = {
    equal_split = { leader = 25, driver = 25, security = 25, support = 25 },
    leader_weighted = { leader = 40, driver = 25, security = 20, support = 15 },
    event_staff = { host = 35, staff = 25, creator = 25, reserve = 15 }
}

GMT.SecurityChecklist = {
    'Use ACE permissions and least privilege for staff.',
    'Keep admin commands server-side and logged.',
    'Never trust client events for money, inventory, or permissions.',
    'Review every paid package for pay-to-win risk.',
    'Use original or licensed assets only.',
    'Back up database before major script changes.',
    'Use private channels for tokens and secrets; never paste them in public Discord.'
}
