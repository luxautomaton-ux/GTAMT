-- Client helper for player-facing commands.
-- Keep all money, inventory, and entitlement logic server-side.

RegisterCommand('gmthelp', function()
    TriggerEvent('chat:addMessage', {
        color = { 255, 211, 106 },
        multiline = true,
        args = { 'GTA Money Team', 'Commands: /gmtstore, /gmtpayouts, /gmtsecurity, /gmtentitlements' }
    })
end, false)
