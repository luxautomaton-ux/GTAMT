GMTUtils = GMTUtils or {}

function GMTUtils.Chat(source, message)
    TriggerClientEvent('chat:addMessage', source, {
        color = { 77, 248, 255 },
        multiline = true,
        args = { GMT.Brand.name, message }
    })
end

function GMTUtils.Console(message)
    print(('[%s] %s'):format(GMT.Brand.name, message))
end

function GMTUtils.PercentLine(tableData)
    local parts = {}
    for key, value in pairs(tableData) do
        parts[#parts + 1] = key .. ': ' .. tostring(value) .. '%'
    end
    return table.concat(parts, ' | ')
end
