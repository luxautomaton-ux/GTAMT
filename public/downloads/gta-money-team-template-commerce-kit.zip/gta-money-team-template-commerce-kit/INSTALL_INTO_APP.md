# Install Into Your GTA Money Team App

Your app is running locally at `http://localhost:5173/`, which is only visible on your machine. This kit is built as a drop-in upgrade.

## Add the marketplace page

1. Copy folders:

```bash
cp -R app-drop-in/src/commerce YOUR_APP/src/
cp app-drop-in/src/styles/gmt-commerce.css YOUR_APP/src/styles/gmt-commerce.css
```

2. In your app router/nav, add a page named one of these:

- Template Vault
- Server Packs
- City Pack Store
- Services
- Lux Ops

3. Render:

```jsx
import TemplateMarketplace from './commerce/components/TemplateMarketplace.jsx';
import './styles/gmt-commerce.css';

function TemplateVaultPage() {
  return <TemplateMarketplace />;
}
```

4. Edit checkout links in:

```text
src/commerce/paymentLinks.js
```

5. For production, connect leads/orders to the backend schema in `backend-blueprint/`.

## Add FiveM resource to a template pack

Copy:

```text
fivem-resources/[gmt]/gmt_commerce_engine
```

Into the buyer server's resources folder and add:

```cfg
ensure gmt_commerce_engine
```

## Best public nav labels

- Template Vault
- City Packs
- Server Forge
- Revenue Lab
- Discord Builder
- Security Audit
- Request DFY Setup

## Best internal-only labels

- Lux Ops Desk
- GitHub Research Radar
- Fulfillment Queue
- Lead Export
- Product Builder
