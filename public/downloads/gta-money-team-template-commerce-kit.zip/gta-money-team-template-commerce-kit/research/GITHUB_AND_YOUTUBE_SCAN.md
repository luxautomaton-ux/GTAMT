# GitHub + YouTube Scan Notes

## GitHub resources to study internally

- QBCore Framework / qb-core: core RP framework with GPL licensing. Study structure; do not copy into paid packs unless you comply with the license.
- QBCore organization resources: qb-inventory, qb-target, qb-spawn, qb-menu. Good inspiration for how modular FiveM resources are organized.
- ESX Framework / esx_core and ESX recipes: alternative legacy framework direction for buyers who prefer ESX.
- txAdmin repository/docs: useful for setup flow, recipes, and server management education.

## YouTube content themes found

- How to create a FiveM server with txAdmin.
- How to install QBCore through txAdmin/VPS.
- How to monetize FiveM with Tebex.
- Top RP server videos focus on realism, active community, gangs, police, economy, and creator moments.
- Tutorial videos sell well when they show setup steps, before/after organization, and common mistakes.

## Public top-server market observations

Public GrizzleyWorld/Tebex pages show categories around server access, ped menu, gang clothing, import chain, gang whitelist, virtual/status currency, and queue priority. GTA Money Team should NOT copy their branding or exact package system. Use the pattern safely: access, status, community, cosmetics, applications, and queue — with no pay-to-win and no stolen assets.

## Product strategy from scan

1. Build a flagship launch pack that feels celebrity-scale but original.
2. Turn city packs into individual products plus an all-city vault.
3. Sell safe monetization/store setup as a service.
4. Sell Discord setup and staff SOPs as an entry product.
5. Sell monthly ops/security/economy support as recurring revenue.
6. Use YouTube Shorts as traffic into the templates and service request form.
