export function estimatePackRevenue({ visits = 1000, conversionRate = 2, averageOrder = 149, refundRate = 5 }) {
  const buyers = Math.max(0, visits) * (Math.max(0, conversionRate) / 100);
  const gross = buyers * Math.max(0, averageOrder);
  const refunds = gross * (Math.max(0, refundRate) / 100);
  return {
    buyers: Math.round(buyers),
    gross: Math.round(gross),
    refunds: Math.round(refunds),
    net: Math.round(gross - refunds),
  };
}

export function estimateRetainerRevenue({ clients = 5, monthlyFee = 349, churnRate = 10 }) {
  const grossMonthly = Math.max(0, clients) * Math.max(0, monthlyFee);
  const churnLoss = grossMonthly * (Math.max(0, churnRate) / 100);
  return {
    grossMonthly: Math.round(grossMonthly),
    churnLoss: Math.round(churnLoss),
    netMonthly: Math.round(grossMonthly - churnLoss),
    annualized: Math.round((grossMonthly - churnLoss) * 12),
  };
}

export function estimateServicePipeline({ leads = 25, closeRate = 20, averageProject = 699, upsellRate = 25, upsellValue = 299 }) {
  const closed = Math.max(0, leads) * (Math.max(0, closeRate) / 100);
  const base = closed * Math.max(0, averageProject);
  const upsells = closed * (Math.max(0, upsellRate) / 100) * Math.max(0, upsellValue);
  return {
    closed: Math.round(closed),
    base: Math.round(base),
    upsells: Math.round(upsells),
    total: Math.round(base + upsells),
  };
}

export function formatCurrency(value) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(Number(value || 0));
}
