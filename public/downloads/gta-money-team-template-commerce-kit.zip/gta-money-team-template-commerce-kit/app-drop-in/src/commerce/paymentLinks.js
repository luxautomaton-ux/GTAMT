// Replace these placeholders with real checkout links.
// For FiveM/RedM server perks, use Tebex. For template ZIPs, services, or external consulting, you can also use Stripe/PayPal.
export const paymentLinks = {
  "celebrity-scale-rp-launch-pack": "https://your-tebex-or-stripe-link.example/celebrity-launch",
  "top-server-access-queue-pack": "https://your-tebex-or-stripe-link.example/access-queue",
  "gang-identity-turf-pack": "https://your-tebex-or-stripe-link.example/gang-turf",
  "police-ems-doj-pack": "https://your-tebex-or-stripe-link.example/police-ems-doj",
  "business-economy-pack": "https://your-tebex-or-stripe-link.example/business-economy",
  "security-anti-abuse-pack": "https://your-tebex-or-stripe-link.example/security-audit",
  "discord-community-machine-pack": "https://your-tebex-or-stripe-link.example/discord-machine",
  "tebex-store-blueprint-pack": "https://your-tebex-or-stripe-link.example/tebex-blueprint",
  "creator-streamer-pack": "https://your-tebex-or-stripe-link.example/creator-pack",
  "premium-city-identity-pack": "https://your-tebex-or-stripe-link.example/city-pack",
  "full-template-vault-bundle": "https://your-tebex-or-stripe-link.example/full-vault",
  "monthly-ops-retainer": "https://your-tebex-or-stripe-link.example/monthly-ops"
};


export const requestConfig = {
  supportEmail: 'luxautomaton@gmail.com',
  discordInvite: 'https://discord.gg/YOUR_INVITE',
  responsePromise: '24-48 hour reply window for paid service requests',
};
