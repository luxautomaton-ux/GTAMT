export const productCatalog = [
  {
    "id": "celebrity-scale-rp-launch-pack",
    "name": "Celebrity-Scale RP Launch Pack",
    "category": "Flagship Server Pack",
    "price": "$499-$899",
    "anchorPrice": 699,
    "headline": "A high-retention RP launch system built around whitelist access, creators, gangs, city status, and clean monetization.",
    "buyer": "Artists, streamers, community owners, and server founders who want a premium public launch without copying any existing server.",
    "deliverables": [
      "Launch-day server identity map",
      "Whitelist funnel",
      "Discord community machine",
      "Tebex-safe product ladder",
      "Staff hiring checklist",
      "Creator promo scripts",
      "Launch calendar"
    ],
    "moneyLevers": [
      "Application/access funnel",
      "Queue/supporter tiers",
      "Cosmetic supporter perks",
      "Custom city identity",
      "Monthly ops support"
    ],
    "security": [
      "Staff-only admin separation",
      "Anti-pay-to-win checklist",
      "Ticket evidence policy",
      "Moderation escalation ladder"
    ],
    "upsells": [
      "DFY txAdmin install",
      "Custom city pack",
      "Discord setup",
      "Monthly security audit"
    ],
    "legalNotes": "Do not copy Tee Grizzley/GrizzleyWorld branding, scripts, assets, private rules, or store design. This pack uses the public market pattern only: access, status, community, content, and safe cosmetics."
  },
  {
    "id": "top-server-access-queue-pack",
    "name": "Top-Server Access & Queue Pack",
    "category": "Monetization Blueprint",
    "price": "$149-$249",
    "anchorPrice": 199,
    "headline": "Sell access, priority, and supporter value without selling guns, drugs, cash, or unfair advantage.",
    "buyer": "Server owners who want a compliant first Tebex store with clean packages.",
    "deliverables": [
      "Access pass copy",
      "Priority queue tier matrix",
      "Discord role names",
      "Refund policy draft",
      "Tebex product CSV",
      "Buyer onboarding script"
    ],
    "moneyLevers": [
      "Queue priority",
      "Discord supporter role",
      "Founder badge",
      "Non-gameplay recognition"
    ],
    "security": [
      "No randomized rewards",
      "No paid weapons/cash",
      "Manual review before whitelist",
      "Order log export"
    ],
    "upsells": [
      "Tebex install",
      "Store graphics",
      "Monthly package audit"
    ],
    "legalNotes": "Use Tebex for FiveM/RedM monetization and keep benefits cosmetic, access-based, or community-support oriented."
  },
  {
    "id": "gang-identity-turf-pack",
    "name": "Gang Identity & Turf Pack",
    "category": "Roleplay Expansion",
    "price": "$199-$399",
    "anchorPrice": 299,
    "headline": "Create fictional crews with turf rules, outfit placeholders, ranks, diplomacy, and payout discipline.",
    "buyer": "Serious RP servers that need structure for gangs without chaos or real gang branding.",
    "deliverables": [
      "Fictional gang bible",
      "Turf zones",
      "Rank ladder",
      "Gang application form",
      "War approval SOP",
      "Crew payout sheet",
      "Discord category layout"
    ],
    "moneyLevers": [
      "Gang application review",
      "Cosmetic clothing access",
      "Crew event passes",
      "Monthly faction support"
    ],
    "security": [
      "No real gang branding",
      "No random violence rules",
      "Staff approval for wars",
      "Evidence ticket workflow"
    ],
    "upsells": [
      "Custom gang logos",
      "Original clothing textures",
      "Faction balancing session"
    ],
    "legalNotes": "Fictionalize all names, colors, logos, and stories. Avoid real gang identifiers or copyrighted apparel/brand marks."
  },
  {
    "id": "police-ems-doj-pack",
    "name": "Police, EMS & DOJ Authority Pack",
    "category": "Civil Services",
    "price": "$249-$499",
    "anchorPrice": 349,
    "headline": "Professional public-safety structure with ranks, SOPs, vehicle placeholders, training academy, and evidence rules.",
    "buyer": "Servers trying to look serious to streamers and whitelisted players.",
    "deliverables": [
      "LSPD-style fictional department SOP",
      "EMS protocol",
      "Court/DOJ process",
      "Fleet placeholder list",
      "Dispatch rules",
      "Training academy checklist"
    ],
    "moneyLevers": [
      "Application fee for staff-reviewed training",
      "Department supporter cosmetics",
      "Private academy session"
    ],
    "security": [
      "No real agency logos",
      "Least-privilege staff roles",
      "Audit logs",
      "Evidence-based discipline"
    ],
    "upsells": [
      "Custom badge graphics",
      "MLO sourcing checklist",
      "Cadet training video"
    ],
    "legalNotes": "Use fictional law enforcement agencies and original/commissioned artwork only."
  },
  {
    "id": "business-economy-pack",
    "name": "Business Economy & Payout Pack",
    "category": "Economy System",
    "price": "$299-$599",
    "anchorPrice": 449,
    "headline": "Give players legal money loops: restaurants, towing, trucking, fishing, mechanics, delivery, events, and business ownership.",
    "buyer": "Owners who need a balanced economy and repeatable RP jobs.",
    "deliverables": [
      "Job list",
      "Salary grid",
      "Business license flow",
      "Crew payout calculator",
      "Inflation checklist",
      "Event revenue plan",
      "RP tax ledger template"
    ],
    "moneyLevers": [
      "Business application review",
      "Event sponsorship",
      "Founder business packages",
      "Monthly economy tuning"
    ],
    "security": [
      "No pay-to-win currency sales",
      "Cap large payouts",
      "Review suspicious transfers",
      "Inflation trigger alerts"
    ],
    "upsells": [
      "Custom job scripts",
      "Spreadsheet dashboard",
      "Monthly economy balance"
    ],
    "legalNotes": "Do not sell in-game cash, weapons, or restricted advantage. Sell templates, services, cosmetics, access, and support."
  },
  {
    "id": "security-anti-abuse-pack",
    "name": "Security & Anti-Abuse Pack",
    "category": "Ops/Security",
    "price": "$199-$399",
    "anchorPrice": 299,
    "headline": "Protect the city from staff abuse, leaked scripts, permission mistakes, chargeback chaos, and economy exploits.",
    "buyer": "Any server owner before launch or before opening paid access.",
    "deliverables": [
      "ACE permissions template",
      "Staff role matrix",
      "Pre-launch audit",
      "Chargeback SOP",
      "Admin command policy",
      "Webhook log plan"
    ],
    "moneyLevers": [
      "Security audit service",
      "Monthly compliance retainer",
      "Incident response"
    ],
    "security": [
      "Least privilege",
      "No client-trusted payouts",
      "Server-side validation",
      "Audit logs",
      "Token secrecy"
    ],
    "upsells": [
      "Script audit",
      "Discord bot audit",
      "Database hardening"
    ],
    "legalNotes": "This pack is defensive only. No bypasses, cheats, token scraping, or exploit instructions."
  },
  {
    "id": "discord-community-machine-pack",
    "name": "Discord Community Machine Pack",
    "category": "Community",
    "price": "$99-$249",
    "anchorPrice": 149,
    "headline": "Turn a Discord into a conversion funnel: applications, tickets, role ladders, announcements, content drops, and support.",
    "buyer": "Server owners who need structure before opening applications.",
    "deliverables": [
      "Channel tree",
      "Role list",
      "Ticket categories",
      "Application forms",
      "Announcement calendar",
      "Moderator playbook"
    ],
    "moneyLevers": [
      "Whitelist applications",
      "Supporter roles",
      "Creator applications",
      "Template upsells"
    ],
    "security": [
      "2FA requirement for staff",
      "No token sharing",
      "Private ticket permissions",
      "Escalation logs"
    ],
    "upsells": [
      "DFY Discord build",
      "Bot setup",
      "Staff training"
    ],
    "legalNotes": "Never ask customers for passwords or Discord bot tokens in public forms. Use secure onboarding."
  },
  {
    "id": "tebex-store-blueprint-pack",
    "name": "Tebex Store Blueprint Pack",
    "category": "Storefront",
    "price": "$99-$299",
    "anchorPrice": 199,
    "headline": "A ready-to-build Tebex store map with safe categories, product descriptions, refund language, and delivery notes.",
    "buyer": "Owners who want to monetize correctly from day one.",
    "deliverables": [
      "Package category map",
      "CSV package blueprint",
      "Product descriptions",
      "Legal-safe disclaimers",
      "Launch sale plan",
      "Coupon calendar"
    ],
    "moneyLevers": [
      "Priority",
      "Access",
      "Cosmetics",
      "Services",
      "Subscriptions"
    ],
    "security": [
      "No loot boxes",
      "No paid random rewards",
      "No real brands",
      "No external checkout for server benefits"
    ],
    "upsells": [
      "Tebex implementation",
      "Store art",
      "Product audit"
    ],
    "legalNotes": "For FiveM/RedM server perks, Tebex is the authorized monetization path on Cfx.re."
  },
  {
    "id": "creator-streamer-pack",
    "name": "Creator & Streamer Growth Pack",
    "category": "Content Engine",
    "price": "$149-$399",
    "anchorPrice": 249,
    "headline": "Make the server look alive on YouTube, TikTok, Kick, and Twitch with faceless clips, events, and streamer-safe rules.",
    "buyer": "Servers that need traffic and creators who need content hooks.",
    "deliverables": [
      "30-day video calendar",
      "Shorts scripts",
      "Thumbnail prompts",
      "Streamer rules",
      "Clip submission workflow",
      "Event calendar"
    ],
    "moneyLevers": [
      "Creator partner tier",
      "Sponsored events",
      "Template bundle ads",
      "Affiliate hosting links"
    ],
    "security": [
      "Streamer privacy zones",
      "No doxxing",
      "No harassment content",
      "Moderated clip approval"
    ],
    "upsells": [
      "Argil video pack",
      "OBS overlay",
      "Monthly content calendar"
    ],
    "legalNotes": "Keep video claims accurate; avoid fake income promises and fake GTA VI access claims."
  },
  {
    "id": "premium-city-identity-pack",
    "name": "Premium City Identity Pack",
    "category": "City Packs",
    "price": "$119-$159 per city",
    "anchorPrice": 149,
    "headline": "Portland, Oakland, Riverside, Utah, St. Louis, Kansas City, Memphis, Charlotte, Philly, New Jersey, and DC city identities.",
    "buyer": "Server owners who want a city concept fast.",
    "deliverables": [
      "City config",
      "Landmarks",
      "Weather",
      "Factions",
      "Streets",
      "Police fleet placeholders",
      "Sales page"
    ],
    "moneyLevers": [
      "Single city packs",
      "All-city vault",
      "Custom city request",
      "Installed city setup"
    ],
    "security": [
      "Fictionalized gangs",
      "Original landmarks copy",
      "No real police marks",
      "No copied maps"
    ],
    "upsells": [
      "City art pack",
      "Custom MLO sourcing",
      "Full installed city"
    ],
    "legalNotes": "Use city inspiration, not copyrighted or official municipal marks."
  },
  {
    "id": "full-template-vault-bundle",
    "name": "Full Template Vault Bundle",
    "category": "Bundle",
    "price": "$999-$1,499",
    "anchorPrice": 1299,
    "headline": "Bundle the server starter, city packs, Tebex store, Discord machine, security, economy, and creator content into one premium offer.",
    "buyer": "High-ticket clients who want the full operating system instead of one ZIP.",
    "deliverables": [
      "All pack docs",
      "App product catalog",
      "Lead forms",
      "Revenue calculators",
      "Fulfillment checklists",
      "Launch content"
    ],
    "moneyLevers": [
      "High-ticket bundle",
      "DFY install",
      "Monthly support",
      "Custom city builds"
    ],
    "security": [
      "Pre-sale disclaimers",
      "License checklist",
      "Asset verification",
      "Support boundaries"
    ],
    "upsells": [
      "$1,800+ custom city",
      "$299/mo support",
      "$499 script audit"
    ],
    "legalNotes": "Sell original template systems and services. Never sell stolen assets or copied server identities."
  },
  {
    "id": "monthly-ops-retainer",
    "name": "Monthly Ops Retainer",
    "category": "Recurring Service",
    "price": "$249-$499/mo",
    "anchorPrice": 349,
    "headline": "Recurring support for economy tuning, security checks, Discord cleanup, content planning, and package optimization.",
    "buyer": "Owners who have launched and need consistent help.",
    "deliverables": [
      "Monthly audit",
      "Economy report",
      "Discord health report",
      "Tebex package review",
      "Content calendar",
      "Incident notes"
    ],
    "moneyLevers": [
      "Recurring revenue",
      "Priority support",
      "Quarterly relaunch",
      "New pack releases"
    ],
    "security": [
      "Monthly permission review",
      "Staff access audit",
      "Fraud/chargeback checklist",
      "Script update log"
    ],
    "upsells": [
      "Emergency incident response",
      "New city expansion",
      "Custom script commission"
    ],
    "legalNotes": "Do not take custody of passwords or tokens. Use scoped access and client-approved changes."
  }
];


export const categories = [
  'All',
  'Flagship Server Pack',
  'Monetization Blueprint',
  'Roleplay Expansion',
  'Civil Services',
  'Economy System',
  'Ops/Security',
  'Community',
  'Storefront',
  'Content Engine',
  'City Packs',
  'Bundle',
  'Recurring Service'
];

export const promiseStack = [
  'No cheats. No mod menus. No fake GTA crypto.',
  'Original server identity packs only — no copied top-server assets.',
  'Tebex-safe monetization planning for FiveM/RedM server perks.',
  'Sell templates, services, setup, Discord systems, and support retainers.',
  'Built for server owners, streamers, gangs/factions, and RP founders.'
];
