const KEY = 'gmt_template_commerce_leads_v1';

export function loadLeads() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '[]');
  } catch (error) {
    console.warn('Could not load leads', error);
    return [];
  }
}

export function saveLead(lead) {
  const leads = loadLeads();
  const next = {
    id: `lead_${Date.now()}`,
    createdAt: new Date().toISOString(),
    status: 'New',
    ...lead,
  };
  localStorage.setItem(KEY, JSON.stringify([next, ...leads]));
  return next;
}

export function clearLeads() {
  localStorage.removeItem(KEY);
}

export function leadsToCsv(leads) {
  const rows = [
    ['createdAt', 'name', 'email', 'discord', 'product', 'budget', 'timeline', 'message', 'status'],
    ...leads.map((lead) => [
      lead.createdAt,
      lead.name,
      lead.email,
      lead.discord,
      lead.product,
      lead.budget,
      lead.timeline,
      String(lead.message || '').replaceAll('\n', ' '),
      lead.status,
    ]),
  ];
  return rows.map((row) => row.map((cell) => `"${String(cell ?? '').replaceAll('"', '""')}"`).join(',')).join('\n');
}

export function downloadCsv(filename, csv) {
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
