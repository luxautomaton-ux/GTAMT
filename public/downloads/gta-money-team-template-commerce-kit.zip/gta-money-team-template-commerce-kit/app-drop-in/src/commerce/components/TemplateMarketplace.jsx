import { useMemo, useState } from 'react';
import { categories, productCatalog, promiseStack } from '../productCatalog.js';
import { paymentLinks, requestConfig } from '../paymentLinks.js';
import { estimatePackRevenue, estimateRetainerRevenue, estimateServicePipeline, formatCurrency } from '../calculators.js';
import { downloadCsv, leadsToCsv, loadLeads, saveLead } from '../storage.js';

function Field({ label, children }) {
  return (
    <label className="gmt-field">
      <span>{label}</span>
      {children}
    </label>
  );
}

function ProductCard({ product, onRequest }) {
  return (
    <article className="gmt-product-card">
      <div className="gmt-product-topline">
        <span>{product.category}</span>
        <strong>{product.price}</strong>
      </div>
      <h3>{product.name}</h3>
      <p>{product.headline}</p>
      <div className="gmt-chip-row">
        {product.moneyLevers.slice(0, 4).map((lever) => <span key={lever}>{lever}</span>)}
      </div>
      <div className="gmt-product-grid">
        <div>
          <b>Deliverables</b>
          <ul>{product.deliverables.slice(0, 4).map((item) => <li key={item}>{item}</li>)}</ul>
        </div>
        <div>
          <b>Security</b>
          <ul>{product.security.slice(0, 4).map((item) => <li key={item}>{item}</li>)}</ul>
        </div>
      </div>
      <div className="gmt-card-actions">
        <a className="gmt-btn gmt-btn-primary" href={paymentLinks[product.id]} target="_blank" rel="noreferrer">Buy / Checkout</a>
        <button className="gmt-btn" onClick={() => onRequest(product)}>Request Service</button>
      </div>
      <small>{product.legalNotes}</small>
    </article>
  );
}

function RequestModal({ selected, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: '', email: '', discord: '', product: selected?.name || '', budget: '$500-$1,000', timeline: 'This week', message: '',
  });
  if (!selected) return null;

  function update(key, value) { setForm((prev) => ({ ...prev, [key]: value })); }

  function submit(event) {
    event.preventDefault();
    const lead = saveLead(form);
    onSaved(lead);
    const subject = encodeURIComponent(`GTA Money Team Service Request — ${form.product}`);
    const body = encodeURIComponent(`Name: ${form.name}
Email: ${form.email}
Discord: ${form.discord}
Product: ${form.product}
Budget: ${form.budget}
Timeline: ${form.timeline}

Message:
${form.message}`);
    window.location.href = `mailto:${requestConfig.supportEmail}?subject=${subject}&body=${body}`;
  }

  return (
    <div className="gmt-modal-backdrop" role="presentation">
      <form className="gmt-modal" onSubmit={submit}>
        <button className="gmt-close" type="button" onClick={onClose}>×</button>
        <span className="gmt-kicker">Request Service</span>
        <h2>{selected.name}</h2>
        <p>Tell Lux Automaton what the buyer needs. This saves locally and opens an email handoff.</p>
        <div className="gmt-form-grid">
          <Field label="Name"><input required value={form.name} onChange={(e) => update('name', e.target.value)} /></Field>
          <Field label="Email"><input required type="email" value={form.email} onChange={(e) => update('email', e.target.value)} /></Field>
          <Field label="Discord"><input value={form.discord} onChange={(e) => update('discord', e.target.value)} /></Field>
          <Field label="Budget"><select value={form.budget} onChange={(e) => update('budget', e.target.value)}><option>$99-$299</option><option>$500-$1,000</option><option>$1,000-$2,500</option><option>$2,500+</option></select></Field>
          <Field label="Timeline"><select value={form.timeline} onChange={(e) => update('timeline', e.target.value)}><option>Today</option><option>This week</option><option>This month</option><option>Planning stage</option></select></Field>
        </div>
        <Field label="Project details"><textarea rows="5" value={form.message} onChange={(e) => update('message', e.target.value)} placeholder="City theme, framework, Discord size, Tebex needs, police/gang/business systems..." /></Field>
        <button className="gmt-btn gmt-btn-primary" type="submit">Submit Request</button>
      </form>
    </div>
  );
}

function RevenueLab() {
  const [pack, setPack] = useState({ visits: 3000, conversionRate: 2.5, averageOrder: 149, refundRate: 4 });
  const [retainer, setRetainer] = useState({ clients: 8, monthlyFee: 349, churnRate: 8 });
  const [service, setService] = useState({ leads: 30, closeRate: 18, averageProject: 699, upsellRate: 30, upsellValue: 299 });
  const packOut = estimatePackRevenue(pack);
  const retainerOut = estimateRetainerRevenue(retainer);
  const serviceOut = estimateServicePipeline(service);
  const update = (setter, key) => (event) => setter((prev) => ({ ...prev, [key]: Number(event.target.value) }));

  return (
    <section className="gmt-panel gmt-revenue-lab">
      <span className="gmt-kicker">Show Them The Money</span>
      <h2>Template + service revenue calculators</h2>
      <div className="gmt-calculator-grid">
        <div className="gmt-calc-card">
          <h3>Template Sales</h3>
          <Field label="Monthly visits"><input type="number" value={pack.visits} onChange={update(setPack, 'visits')} /></Field>
          <Field label="Conversion %"><input type="number" step="0.1" value={pack.conversionRate} onChange={update(setPack, 'conversionRate')} /></Field>
          <Field label="Average order"><input type="number" value={pack.averageOrder} onChange={update(setPack, 'averageOrder')} /></Field>
          <Field label="Refund %"><input type="number" step="0.1" value={pack.refundRate} onChange={update(setPack, 'refundRate')} /></Field>
          <strong>{formatCurrency(packOut.net)} net / month</strong>
          <small>{packOut.buyers} buyers · {formatCurrency(packOut.gross)} gross</small>
        </div>
        <div className="gmt-calc-card">
          <h3>Ops Retainer</h3>
          <Field label="Clients"><input type="number" value={retainer.clients} onChange={update(setRetainer, 'clients')} /></Field>
          <Field label="Monthly fee"><input type="number" value={retainer.monthlyFee} onChange={update(setRetainer, 'monthlyFee')} /></Field>
          <Field label="Churn/loss %"><input type="number" value={retainer.churnRate} onChange={update(setRetainer, 'churnRate')} /></Field>
          <strong>{formatCurrency(retainerOut.netMonthly)} net / month</strong>
          <small>{formatCurrency(retainerOut.annualized)} annualized</small>
        </div>
        <div className="gmt-calc-card">
          <h3>Service Pipeline</h3>
          <Field label="Monthly leads"><input type="number" value={service.leads} onChange={update(setService, 'leads')} /></Field>
          <Field label="Close %"><input type="number" value={service.closeRate} onChange={update(setService, 'closeRate')} /></Field>
          <Field label="Project value"><input type="number" value={service.averageProject} onChange={update(setService, 'averageProject')} /></Field>
          <Field label="Upsell %"><input type="number" value={service.upsellRate} onChange={update(setService, 'upsellRate')} /></Field>
          <Field label="Upsell value"><input type="number" value={service.upsellValue} onChange={update(setService, 'upsellValue')} /></Field>
          <strong>{formatCurrency(serviceOut.total)} / month</strong>
          <small>{serviceOut.closed} closed deals</small>
        </div>
      </div>
    </section>
  );
}

function LeadDesk() {
  const [leads, setLeads] = useState(() => loadLeads());
  function exportLeads() { downloadCsv('gta-money-team-leads.csv', leadsToCsv(leads)); }
  return (
    <section className="gmt-panel">
      <span className="gmt-kicker">Lux Ops Only</span>
      <h2>Lead tracker</h2>
      <p>Local demo tracker. Replace with Supabase/Stripe/Tebex webhooks before real production.</p>
      <button className="gmt-btn" onClick={exportLeads}>Export CSV</button>
      <div className="gmt-lead-list">
        {leads.length === 0 ? <em>No local leads yet.</em> : leads.map((lead) => (
          <div className="gmt-lead" key={lead.id}>
            <strong>{lead.product}</strong>
            <span>{lead.name} · {lead.email} · {lead.budget}</span>
            <small>{lead.createdAt}</small>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function TemplateMarketplace() {
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const filtered = useMemo(() => {
    return productCatalog.filter((product) => {
      const categoryMatch = category === 'All' || product.category === category;
      const search = `${product.name} ${product.headline} ${product.category} ${product.moneyLevers.join(' ')}`.toLowerCase();
      return categoryMatch && search.includes(query.toLowerCase());
    });
  }, [category, query]);

  function handleSaved() { setRefreshKey((key) => key + 1); setSelected(null); }

  return (
    <main className="gmt-commerce">
      <section className="gmt-commerce-hero">
        <div>
          <span className="gmt-kicker">GTA Money Team</span>
          <h1>Sell premium RP templates, city packs, Discord systems, and server ops services.</h1>
          <p>Built for paying customers who want a clean FiveM/GTA RP launch plan: access, community, safety, money systems, and creator traffic — not cheats.</p>
          <div className="gmt-hero-actions">
            <a className="gmt-btn gmt-btn-primary" href="#packs">View Packs</a>
            <a className="gmt-btn" href="#money">Revenue Lab</a>
          </div>
        </div>
        <aside className="gmt-promise-card">
          <h2>Legal money promise</h2>
          {promiseStack.map((item) => <p key={item}>✓ {item}</p>)}
        </aside>
      </section>

      <section id="packs" className="gmt-market-toolbar">
        <input placeholder="Search packs, services, money levers..." value={query} onChange={(e) => setQuery(e.target.value)} />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          {categories.map((item) => <option key={item}>{item}</option>)}
        </select>
      </section>

      <section className="gmt-product-list">
        {filtered.map((product) => <ProductCard key={product.id} product={product} onRequest={setSelected} />)}
      </section>

      <section id="money"><RevenueLab /></section>
      <LeadDesk key={refreshKey} />
      <RequestModal selected={selected} onClose={() => setSelected(null)} onSaved={handleSaved} />
    </main>
  );
}
