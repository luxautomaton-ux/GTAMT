# Legal-Safe Rules

Do not sell cheats, mod menus, exploits, copied assets, stolen code, fake beta access, fake crypto, or account-risk tools. Build around education, templates, server planning, Discord setup, content systems, and lawful monetization structures.
