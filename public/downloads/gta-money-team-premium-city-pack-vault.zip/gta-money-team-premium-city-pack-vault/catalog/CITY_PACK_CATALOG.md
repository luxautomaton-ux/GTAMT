# City Pack Catalog

## Vice Harbor RP

**Theme:** Luxury marina, neon beach, port money, streamer lifestyle

**Inspired by:** Miami / South Florida energy

**Weather:** EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

**Police fleet placeholders:** vh_police_cruiser, vh_police_interceptor, vh_sheriff_suv, vh_marine_unit, vh_air_one

**Gangs/Factions:** Harbor Kings, Palm Saints, South Beach Syndicate, Portside Circle

**Street grid:** Ocean Mile, Palm Run, Biscayne Strip, Marina Row, Viceport Causeway, Sunset Harbor Drive

**Landmarks:** Neon Marina, Palm Pier, Viceport Docks, Diamond Hotel Strip, Sunset Rooftop, Lux Automaton Waterfront HQ

**Money loops:** Yacht logistics contracts, Port trucking loops, Beach club ownership, Luxury vehicle imports, Creator nightlife events


## Liberty Metro RP

**Theme:** Big-city hustle, borough politics, finance districts, taxi grids

**Inspired by:** New York / Liberty City energy

**Weather:** CLEAR, OVERCAST, RAIN, FOGGY, XMAS

**Police fleet placeholders:** lm_patrol_sedan, lm_unmarked_taxi_unit, lm_highway_interceptor, lm_transit_suv, lm_air_support

**Gangs/Factions:** Borough Alliance, Canal Crew, Uptown Syndicate, Dockyard Family

**Street grid:** Broker Avenue, Liberty Exchange, Canal Row, Hudson Cut, Metro North Drive, Financial Loop

**Landmarks:** Central Station, Liberty Exchange Tower, Canal Market, Old Dockyard, Uptown Courts, Metro News Building

**Money loops:** Taxi medallion routes, Courier contracts, Stock room heists as RP events, Food truck franchises, High-rise security contracts


## Bayou Parish RP

**Theme:** Southern noir, swamp routes, sheriff politics, music economy

**Inspired by:** New Orleans / Louisiana bayou energy

**Weather:** CLEAR, CLOUDS, RAIN, THUNDER, FOGGY

**Police fleet placeholders:** bp_sheriff_tahoe, bp_state_trooper, bp_swamp_rescue, bp_marshal_unit, bp_airboat_unit

**Gangs/Factions:** Parish Riders, River Saints, Canal Boys, Gator Road Family

**Street grid:** Canal Crown, Bourbon Loop, Bayou Cutoff, Parish Road 12, Riverwalk East, Cypress Bend

**Landmarks:** Crescent Plaza, Bayou Landing, Parish Courthouse, Old Jazz Hall, Riverboat Dock, Gator Market

**Money loops:** Fishing contracts, Riverboat events, Food stand licenses, Swamp rescue work, Music venue ownership


## ATL Empire RP

**Theme:** Music business, airport logistics, film crews, high-growth crews

**Inspired by:** Atlanta creator and entertainment energy

**Weather:** EXTRASUNNY, CLEAR, CLOUDS, OVERCAST, RAIN

**Police fleet placeholders:** ae_city_patrol, ae_gsu_unit, ae_airport_police, ae_interceptor, ae_command_suv

**Gangs/Factions:** Peachtree Circle, Southside Management, Airport Road Crew, Studio Block

**Street grid:** Peachtree Run, A-Town Connector, Studio Lane, Airport Road, Cascade Bend, Midtown Loop

**Landmarks:** Empire Studio Lot, Peachtree Mall, Airport Cargo Yard, Cascade Club, Downtown Arena, Lux Automaton Creative Lab

**Money loops:** Studio bookings, Airport cargo contracts, Artist management, Vehicle rental company, Film permit missions


## West Coast Heat RP

**Theme:** Street crews, studios, beach money, luxury retail

**Inspired by:** Los Angeles / West Coast RP energy

**Weather:** EXTRASUNNY, CLEAR, SMOG, CLOUDS, RAIN

**Police fleet placeholders:** wch_lspd_cruiser, wch_lspd_interceptor, wch_swat_bearcat, wch_beach_patrol, wch_air_one

**Gangs/Factions:** Vinewood Set, South Beach Families, Eastside Royals, Canyon Cartel

**Street grid:** Vinewood Blvd, Del Perro Walk, Canyon Ridge, East Forum Drive, Movie Lot Road, Pacific Cliff

**Landmarks:** Vinewood Sign, Movie Studio Gate, Del Perro Pier, Canyon Overlook, Designer Row, Pacific Club

**Money loops:** Studio security, Influencer content missions, Luxury retail ownership, Beach delivery loops, Canyon racing events as legal RP


## Windy State RP

**Theme:** Cold city politics, trucking unions, neighborhood crews, hard economy

**Inspired by:** Chicago / Midwest city energy

**Weather:** CLOUDS, OVERCAST, RAIN, FOGGY, XMAS

**Police fleet placeholders:** ws_city_sedan, ws_highway_trooper, ws_tactical_van, ws_snow_patrol, ws_detective_unit

**Gangs/Factions:** Lakefront League, South Rail Crew, Northside Alliance, Steel Yard Union

**Street grid:** Lakefront Drive, South Rail Ave, Downtown Grid, North Market, Steel Yard Road, Windy Expressway

**Landmarks:** Lakefront Pier, Union Station, Steel Yard, City Hall Plaza, North Market, Winter Arena

**Money loops:** Trucking contracts, Tow company ownership, Cold-weather repair jobs, Union warehouse routes, City permit businesses


## Desert Strip RP

**Theme:** Casino strip, hotel security, desert racing, VIP economy

**Inspired by:** Las Vegas / desert luxury energy

**Weather:** EXTRASUNNY, CLEAR, SMOG, CLOUDS, THUNDER

**Police fleet placeholders:** ds_metro_police, ds_sheriff_suv, ds_casino_security, ds_desert_interceptor, ds_air_support

**Gangs/Factions:** Strip Kings, Desert Diamonds, High Roller Crew, Sandy Road Syndicate

**Street grid:** The Strip, Casino Mile, Desert Highway, Sandy Spur, Neon Plaza, High Roller Lane

**Landmarks:** Neon Casino Row, Desert Speedway, High Roller Hotel, Sandy Outpost, VIP Sky Lounge, Lux Automaton Resort Office

**Money loops:** Casino staffing, Hotel ownership, Desert race events, VIP shuttle routes, Security contracts


## Motor City RP

**Theme:** Car culture, repair economy, street-to-enterprise growth

**Inspired by:** Detroit / automotive comeback energy

**Weather:** CLEAR, OVERCAST, RAIN, FOGGY, XMAS

**Police fleet placeholders:** mc_city_cruiser, mc_auto_theft_unit, mc_highway_sedan, mc_tactical_van, mc_detective_suv

**Gangs/Factions:** Motor Block, East Yard Crew, River Rouge Family, Warehouse Kings

**Street grid:** Assembly Row, River Rouge Road, East Yard Ave, Motor Mile, Factory Loop, Downtown Recovery

**Landmarks:** Old Assembly Plant, River Warehouse, Motor Museum, Downtown Garage, Recovery Yard, Luxury Auto Mall

**Money loops:** Mechanic chains, Vehicle recovery contracts, Auto auction events, Warehouse ownership, Detail shop memberships


## Lone Star Border RP

**Theme:** Ranch money, state troopers, oil routes, border highways

**Inspired by:** Texas / Southwest energy

**Weather:** EXTRASUNNY, CLEAR, SMOG, CLOUDS, THUNDER

**Police fleet placeholders:** lsb_state_trooper, lsb_ranger_truck, lsb_border_unit, lsb_sheriff_pickup, lsb_air_support

**Gangs/Factions:** Ranch Road Crew, Borderline Kings, Oilfield Syndicate, Desert Saints

**Street grid:** Ranch Road 9, Oilfield Spur, Border Highway, Longhorn Main, Mesa Run, County Line

**Landmarks:** State Capitol Outpost, Oilfield Depot, County Rodeo, Border Crossing, Longhorn Ranch, Mesa Airstrip

**Money loops:** Ranch ownership, Oilfield hauling, County fair events, Tow and recovery, Airstrip logistics


## Emerald City RP

**Theme:** Rainy tech city, ports, startups, clean community systems

**Inspired by:** Seattle / Pacific Northwest energy

**Weather:** RAIN, CLOUDS, OVERCAST, FOGGY, CLEAR

**Police fleet placeholders:** ec_city_patrol, ec_port_police, ec_bike_unit, ec_detective_suv, ec_rescue_truck

**Gangs/Factions:** Rain City Circle, Portside Coders, Market Row Crew, Evergreen Collective

**Street grid:** Rainier Road, Portside Way, Market Row, Evergreen Ave, Tech Ridge, Sound Drive

**Landmarks:** Sky Needle Viewpoint, Fish Market, Port Terminal, Startup Tower, Rain Garden Park, Lux Automaton Cloud Office

**Money loops:** Startup pitches, Port contracts, Coffee shop chains, Tech repair services, Streamer coworking memberships


## Carolina Coast RP

**Theme:** Beach towns, highways, college nights, small-business RP

**Inspired by:** Carolinas / coastal southern energy

**Weather:** EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

**Police fleet placeholders:** cc_beach_patrol, cc_county_sheriff, cc_highway_unit, cc_marine_unit, cc_detective_sedan

**Gangs/Factions:** Boardwalk Boys, Pine Ridge Crew, College Circle, Harbor Families

**Street grid:** Boardwalk Drive, Pine Ridge Road, College Main, Harbor Cut, County 17, Lowcountry Loop

**Landmarks:** Boardwalk Pier, College Stadium, Harbor Market, Pine Ridge Park, Shrimp Dock, Coastal Courthouse

**Money loops:** Food trucks, College nightlife events, Fishing charters, Beach rental businesses, Highway delivery jobs


## Island Keys RP

**Theme:** Tropical islands, marine patrol, resort economy, ocean routes

**Inspired by:** Florida Keys / island luxury energy

**Weather:** EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

**Police fleet placeholders:** ik_marine_patrol, ik_resort_security, ik_sheriff_jeep, ik_coast_air, ik_island_cruiser

**Gangs/Factions:** Keyside Crew, Reef Riders, Resort Syndicate, Coral Circle

**Street grid:** Overseas Highway, Reef Road, Resort Row, Coral Bend, Dock Street, Island Mile

**Landmarks:** Coral Resort, Reef Marina, Island Airstrip, Dock Street Market, Sunset Key, Marine Patrol Station

**Money loops:** Resort memberships, Boat charter routes, Diving tours, Island delivery loops, VIP event hosting
