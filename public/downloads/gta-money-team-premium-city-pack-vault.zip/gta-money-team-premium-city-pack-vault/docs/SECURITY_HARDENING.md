# Security Hardening Checklist

This is a starter security layer for paid client installs.

## Server access

- Use strong txAdmin password.
- Add staff by license identifier, not by name.
- Keep owner/admin ACE permissions separate from moderator permissions.
- Do not share server.cfg publicly if it contains secrets.
- Do not store Discord bot tokens in public repos.

## Resource safety

- Only install scripts from trusted vendors.
- Read server-side code before enabling it.
- Avoid random free “anti-cheat” scripts with obfuscated code.
- Test new scripts on staging before production.
- Keep a backup before every install.

## Community safety

- Create a clear whitelist application.
- Use Discord verification and staff review.
- Ban doxxing, harassment, racism, hate, sexual content involving minors, and real-world threats.
- Use moderation logs.
- Require staff bodycam/report notes for bans.

## Economy safety

- Do not give unlimited money to staff.
- Log high-value payouts.
- Add weekly economy audits.
- Cap job payouts until server population is stable.
- Separate RP rewards from real-money purchases.

## Paid service delivery checklist

- Buyer signs install scope.
- Buyer confirms hosting login method.
- You never ask for personal passwords when an invite/user role will work.
- Deliver a backup ZIP after install.
- Record changes in a changelog.
