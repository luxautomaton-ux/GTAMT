# Seller Guide — How to Turn City Packs into Cash

## Product ladder

1. **Template ZIP** — $79 to $149
2. **Template + Discord Setup** — $199 to $299
3. **Installed Server Starter** — $399 to $799
4. **Custom City Build** — $1,500+
5. **Monthly Support** — $199 to $499/mo

## What buyers are paying for

They are not just buying files. They are buying speed, structure, confidence, and a server identity.

## Sales page headline examples

- “Launch your own RP city without starting from zero.”
- “A complete city identity kit for FiveM founders.”
- “Police, gangs, landmarks, weather, payouts, Discord, and server config in one starter pack.”

## Upsells

- Licensed police vehicle pack install.
- Custom EUP/clothing setup.
- QBCore or ESX connection.
- Discord whitelist automation.
- Tebex store setup.
- Staff training guide.
- Monthly economy tuning.

## Delivery flow

1. Customer buys the pack.
2. Customer receives ZIP and setup guide.
3. Customer books install call or submits hosting details.
4. You install base pack.
5. You add any paid custom assets they own.
6. You test commands.
7. You deliver a final backup.
