# Legal, Asset, and Resale Rules

Use this checklist before selling or installing a pack.

## Do not include these unless you own rights

- Real police department logos or real law-enforcement seals.
- Paid MLOs, vehicle models, EUP clothing, sound packs, or maps you did not purchase.
- Scripts copied from another server.
- Branding, names, or layouts from famous RP servers.
- Real gang logos or real-world criminal organization names.
- Malware, backdoors, token grabbers, or hidden admin tools.

## Safe selling language

Say: “Inspired city-roleplay starter pack.”  
Do not say: “Exact copy of [famous server].”

Say: “Police fleet placeholders ready for licensed vehicle models.”  
Do not say: “Includes real LAPD/NY Police cars” unless you have licensed/allowed assets.

## Monetization rules

Use Tebex or your approved checkout for FiveM/RedM server monetization. Keep perks cosmetic, community, convenience, or service-based. Avoid pay-to-win setups that damage community trust.

## Recommended buyer disclaimer

This is a starter template. Buyer is responsible for license keys, hosting, paid assets, framework setup, third-party resources, and production testing.
