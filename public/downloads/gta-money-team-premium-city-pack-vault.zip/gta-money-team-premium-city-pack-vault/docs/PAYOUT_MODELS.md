# Crew Payout Models

Use these payout systems to keep crews fair, motivated, and drama-free.

## Model A — Simple crew split

- Leader / planner: 30%
- Driver / runner: 25%
- Specialist: 20%
- Security / lookout: 15%
- Reserve fund: 10%

## Model B — Business operating split

- Owner: 25%
- Staff payroll: 35%
- Inventory / operating costs: 20%
- Marketing / events: 10%
- Reserve / taxes: 10%

## Model C — Server owner revenue split

- Hosting / tools: 20%
- Staff incentives: 20%
- Events / giveaways: 15%
- Asset upgrades: 25%
- Owner profit: 20%

## Anti-drama rules

- Post payout rules before events.
- Use screenshots or logs for major payouts.
- Keep reserves for refunds or mistakes.
- Never let one person control all money with no audit trail.
