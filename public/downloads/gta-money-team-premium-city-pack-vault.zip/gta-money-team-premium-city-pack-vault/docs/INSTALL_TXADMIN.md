# txAdmin Install Guide

## 1. Create the FiveM server

1. Install FXServer or open your hosting provider panel.
2. Launch FXServer.
3. Open txAdmin in the browser.
4. Link your Cfx.re account.
5. Create the server profile.
6. Add your license key.

## 2. Add the GTA Money Team resource

Copy this folder into your server resources folder:

```text
resources/[gmt]/gmt_city_engine
```

## 3. Pick your city pack

Choose one pack under:

```text
products/<city-pack-id>/city_config.lua
```

Copy it to:

```text
resources/[gmt]/gmt_city_engine/config/active_city.lua
```

## 4. Add server.cfg lines

Open the pack's `server-snippet.cfg`, copy the lines, and paste them into your server.cfg.

Minimum example:

```cfg
ensure gmt_city_engine
setr gmt_city_pack "vice-harbor-rp"
```

## 5. Add staff identifiers

Open `server.cfg` and add your owner/admin identifiers:

```cfg
add_principal identifier.license:YOUR_LICENSE_HERE group.owner
add_ace group.owner gmt.admin allow
add_ace group.owner gmt.staff allow
```

## 6. Restart server

Run:

```text
refresh
ensure gmt_city_engine
```

or restart from txAdmin.

## 7. Verify in game

Use these commands:

```text
/citypack
/spawns
/landmarks
/payouts
/securitycheck
```

## 8. Extend with frameworks

Connect to QBCore, ESX, or your preferred stack by replacing the demo profile logic in `server/player_profile.lua`.
