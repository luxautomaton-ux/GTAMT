# How to Create More City Packs

Duplicate any folder in `products/` and edit:

- `city_config.lua`
- `README.md`
- `discord-template.md`
- `sales-page-copy.md`
- `server-snippet.cfg`

## Pack formula

Every premium city pack should include:

1. City name and vibe.
2. Weather profile.
3. Police fleet placeholders.
4. Factions/gangs, all fictional.
5. Landmarks.
6. Streets/districts.
7. Spawn area.
8. Legal money loops.
9. Crew payout model.
10. Discord roles and channels.
11. Security notes.
12. Upsell path.

## Quality rule

Do not sell a pack as “complete production server” unless you have tested it live with the exact framework, assets, vehicles, and database resources installed.
