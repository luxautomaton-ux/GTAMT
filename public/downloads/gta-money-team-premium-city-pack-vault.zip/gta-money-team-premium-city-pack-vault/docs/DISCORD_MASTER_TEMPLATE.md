# Discord Master Template

Use this as the base for every city pack.

## Categories and Channels

### START HERE
- #welcome
- #rules
- #announcements
- #how-to-join
- #faq

### APPLICATIONS
- #whitelist-application
- #staff-application
- #business-application
- #gang-application
- #police-application
- #ems-application

### CITY LIFE
- #city-news
- #events
- #business-ads
- #job-board
- #marketplace

### PUBLIC SAFETY
- #police-announcements
- #ems-announcements
- #court-dockets
- #report-a-player

### SUPPORT
- #open-ticket
- #bug-reports
- #ban-appeals
- #donation-support

### STAFF ONLY
- #staff-chat
- #staff-logs
- #incident-reports
- #economy-audits
- #server-changelog

## Role hierarchy

1. Founder
2. Co-Founder
3. City Manager
4. Head Admin
5. Admin
6. Moderator
7. Department Head
8. Business Owner
9. Whitelisted Resident
10. New Arrival

## Permission tips

- Only owners can manage roles.
- Moderators can timeout/kick but not delete the server.
- Department heads manage their own department channels.
- Keep audit logs on.
