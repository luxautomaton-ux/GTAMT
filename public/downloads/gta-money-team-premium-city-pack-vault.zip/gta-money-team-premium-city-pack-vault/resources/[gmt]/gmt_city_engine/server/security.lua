GMTSecurity = GMTSecurity or {}

-- Basic ACE permission helper. Add license identifiers in server.cfg.
function GMTSecurity.HasStaffPermission(source)
  return IsPlayerAceAllowed(source, 'gmt.staff') or IsPlayerAceAllowed(source, 'gmt.admin') or IsPlayerAceAllowed(source, 'command')
end

function GMTSecurity.HasAdminPermission(source)
  return IsPlayerAceAllowed(source, 'gmt.admin') or IsPlayerAceAllowed(source, 'command')
end

-- Audit log helper. In production, replace print() with Discord webhook/database logging.
function GMTSecurity.Audit(source, action, details)
  local playerName = source > 0 and GetPlayerName(source) or 'CONSOLE'
  print(('[GMT AUDIT] player=%s source=%s action=%s details=%s'):format(playerName, source, action, details or 'none'))
end

-- Staff command: quick security checklist reminder.
RegisterCommand('securitycheck', function(source)
  if source ~= 0 and not GMTSecurity.HasStaffPermission(source) then
    TriggerClientEvent('chat:addMessage', source, { args = {'GMT', 'You do not have permission to run this command.'} })
    return
  end

  local checks = {
    'Use txAdmin password + Cfx account security.',
    'Add staff by license identifier, not by display name.',
    'Keep Discord bot tokens and license keys private.',
    'Test every paid/free script on staging before production.',
    'Audit payouts weekly and log all high-value money moves.'
  }

  if source == 0 then
    for _, check in ipairs(checks) do print('[GMT SECURITY] ' .. check) end
  else
    for _, check in ipairs(checks) do
      TriggerClientEvent('chat:addMessage', source, { args = {'GMT Security', check} })
    end
  end
end, false)
