-- Main server boot for GTA Money Team City Engine.
CreateThread(function()
  Wait(1000)
  GMT.Log(('Loaded city pack: %s (%s)'):format(GMTCity.title or 'Unknown', GMTCity.id or 'no-id'))
  GMT.Log('Police fleet placeholders: ' .. GMT.Join(GMTCity.policeFleet))
  GMT.Log('Gangs/factions: ' .. GMT.Join(GMTCity.gangs))
  GMT.Log('Streets/districts: ' .. GMT.Join(GMTCity.streets))
end)

RegisterCommand('citypack', function(source)
  local message = ('%s — %s'):format(GMTCity.title or 'Unknown City', GMTCity.tagline or 'No tagline set')
  if source == 0 then
    print('[GMT CITY] ' .. message)
  else
    TriggerClientEvent('chat:addMessage', source, { args = {'GTA Money Team', message} })
  end
end, false)

RegisterCommand('gangs', function(source)
  local message = 'City factions: ' .. GMT.Join(GMTCity.gangs)
  if source == 0 then print('[GMT GANGS] ' .. message) else TriggerClientEvent('chat:addMessage', source, { args = {'GMT', message} }) end
end, false)

RegisterCommand('streets', function(source)
  local message = 'Key streets/districts: ' .. GMT.Join(GMTCity.streets)
  if source == 0 then print('[GMT STREETS] ' .. message) else TriggerClientEvent('chat:addMessage', source, { args = {'GMT', message} }) end
end, false)

RegisterCommand('policefleet', function(source)
  local message = 'Police fleet placeholders: ' .. GMT.Join(GMTCity.policeFleet) .. ' — replace with licensed vehicles before selling custom assets.'
  if source == 0 then print('[GMT POLICE] ' .. message) else TriggerClientEvent('chat:addMessage', source, { args = {'GMT', message} }) end
end, false)
