GMTPayouts = GMTPayouts or {}

-- Returns the configured payout split for the active city.
function GMTPayouts.GetSplit()
  return GMT.SafeTable(GMTCity.payoutSplit, { leader = 30, driver = 25, support = 20, security = 15, reserve = 10 })
end

-- Staff/customer command to display recommended splits.
RegisterCommand('payouts', function(source)
  local split = GMTPayouts.GetSplit()
  local lines = {}

  for role, percent in pairs(split) do
    table.insert(lines, role .. ': ' .. tostring(percent) .. '%')
  end

  local message = 'Recommended crew payout split — ' .. table.concat(lines, ' | ')

  if source == 0 then
    print('[GMT PAYOUTS] ' .. message)
  else
    TriggerClientEvent('chat:addMessage', source, { args = {'GMT Payouts', message} })
  end
end, false)
