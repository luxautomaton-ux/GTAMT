GMTProfiles = GMTProfiles or {}

-- Demo in-memory profile store.
-- Production upgrade: replace this with QBCore/ESX player data or a MySQL table.
local profiles = {}

AddEventHandler('playerJoining', function()
  local src = source
  local name = GetPlayerName(src) or ('Player ' .. tostring(src))
  profiles[src] = {
    name = name,
    joinedAt = os.time(),
    starterRole = 'New Arrival',
    city = GMTCity.title or 'GTA Money Team City'
  }
  GMT.Log(('Profile created for %s in %s'):format(name, profiles[src].city))
end)

AddEventHandler('playerDropped', function(reason)
  local src = source
  if profiles[src] then
    GMT.Log(('Profile cleared for %s. Reason: %s'):format(profiles[src].name, reason or 'unknown'))
    profiles[src] = nil
  end
end)

RegisterCommand('mycity', function(source)
  if source == 0 then return end
  local profile = profiles[source]
  local cityName = profile and profile.city or (GMTCity.title or 'Unknown City')
  TriggerClientEvent('chat:addMessage', source, { args = {'GMT', 'Current city pack: ' .. cityName} })
end, false)
