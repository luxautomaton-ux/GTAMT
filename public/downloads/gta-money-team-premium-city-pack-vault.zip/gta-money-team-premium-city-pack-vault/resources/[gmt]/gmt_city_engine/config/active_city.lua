-- Active city config. Replace this file with any product city_config.lua.
GMTCity = {
  id = 'vice-harbor-rp',
  title = 'Vice Harbor RP',
  tagline = 'Luxury marina, neon beach, port money, streamer lifestyle',
  maxRecommendedPlayers = 64,
  policeFleet = {'vh_police_cruiser','vh_police_interceptor','vh_sheriff_suv','vh_marine_unit','vh_air_one'},
  weatherRotation = {'EXTRASUNNY','CLEAR','CLOUDS','RAIN','THUNDER'},
  gangs = {'Harbor Kings','Palm Saints','South Beach Syndicate','Portside Circle'},
  streets = {'Ocean Mile','Palm Run','Biscayne Strip','Marina Row','Viceport Causeway','Sunset Harbor Drive'},
  landmarks = {
    { name = 'Neon Marina', x = -800.0, y = -1500.0, z = 5.0 },
    { name = 'Palm Pier', x = -1600.0, y = -1040.0, z = 13.0 },
    { name = 'Viceport Docks', x = 900.0, y = -3200.0, z = 5.0 }
  },
  defaultSpawn = { x = -1037.4, y = -2737.6, z = 20.2, h = 330.0 },
  payoutSplit = { crew_leader = 35, driver = 25, security = 15, dispatcher = 15, reserve = 10 },
  security = { whitelistRecommended = true, eventLogging = true, economyAudit = true }
}
