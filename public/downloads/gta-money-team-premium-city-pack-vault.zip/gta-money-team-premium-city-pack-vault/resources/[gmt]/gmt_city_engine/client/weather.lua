-- Lightweight weather rotation. This is optional and can be replaced by vSync, cd_easytime, or another weather resource.
local currentIndex = 1

CreateThread(function()
  local rotation = GMT.SafeTable(GMTCity.weatherRotation, {'CLEAR'})

  while true do
    local weather = rotation[currentIndex] or 'CLEAR'

    -- Applies weather locally. Production servers often centralize weather in a dedicated sync resource.
    SetWeatherTypeNowPersist(weather)
    SetWeatherTypeNow(weather)
    SetWeatherTypePersist(weather)

    currentIndex = currentIndex + 1
    if currentIndex > #rotation then currentIndex = 1 end

    -- Rotate every 15 minutes by default.
    Wait(15 * 60 * 1000)
  end
end)
