RegisterCommand('spawns', function()
  local spawn = GMTCity.defaultSpawn or {x = 0.0, y = 0.0, z = 72.0, h = 0.0}
  TriggerEvent('chat:addMessage', {
    args = {'GMT Spawn', ('Default spawn: x=%.2f y=%.2f z=%.2f heading=%.2f'):format(spawn.x, spawn.y, spawn.z, spawn.h or 0.0)}
  })
end, false)

RegisterCommand('gotospawn', function()
  local spawn = GMTCity.defaultSpawn or {x = 0.0, y = 0.0, z = 72.0, h = 0.0}
  local ped = PlayerPedId()

  -- Staff-only teleport should be enforced server-side in production.
  SetEntityCoords(ped, spawn.x, spawn.y, spawn.z, false, false, false, false)
  SetEntityHeading(ped, spawn.h or 0.0)
end, false)
