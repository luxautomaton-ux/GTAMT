-- Client boot. Shows players which city pack is active.
CreateThread(function()
  Wait(3500)
  TriggerEvent('chat:addMessage', {
    args = {'GTA Money Team', 'Welcome to ' .. (GMTCity.title or 'the city') .. '. Type /citypack, /landmarks, /spawns, /payouts, or /streets.'}
  })
end)
