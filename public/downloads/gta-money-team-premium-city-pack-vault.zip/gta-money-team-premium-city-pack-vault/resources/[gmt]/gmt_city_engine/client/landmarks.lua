RegisterCommand('landmarks', function()
  local landmarks = GMT.SafeTable(GMTCity.landmarks, {})
  if #landmarks == 0 then
    TriggerEvent('chat:addMessage', { args = {'GMT Landmarks', 'No landmarks configured.'} })
    return
  end

  TriggerEvent('chat:addMessage', { args = {'GMT Landmarks', 'Key city landmarks:'} })
  for _, landmark in ipairs(landmarks) do
    local msg = ('%s — x=%.1f y=%.1f z=%.1f'):format(landmark.name, landmark.x or 0.0, landmark.y or 0.0, landmark.z or 0.0)
    TriggerEvent('chat:addMessage', { args = {'•', msg} })
  end
end, false)
