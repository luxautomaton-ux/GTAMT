fx_version 'cerulean'
game 'gta5'

author 'Lux Automaton / GTA Money Team'
description 'Premium city pack engine: city identity, weather, landmarks, gangs, police fleet placeholders, payouts, and staff commands.'
version '1.0.0'

-- Shared files load on both client and server.
shared_scripts {
  'config/active_city.lua',
  'shared/utils.lua'
}

-- Server scripts handle permissions, player profiles, payout logic, and staff-safe commands.
server_scripts {
  'server/security.lua',
  'server/player_profile.lua',
  'server/payouts.lua',
  'server/main.lua'
}

-- Client scripts display info, rotate weather, and give players spawn/landmark guidance.
client_scripts {
  'client/main.lua',
  'client/weather.lua',
  'client/spawn.lua',
  'client/landmarks.lua'
}
