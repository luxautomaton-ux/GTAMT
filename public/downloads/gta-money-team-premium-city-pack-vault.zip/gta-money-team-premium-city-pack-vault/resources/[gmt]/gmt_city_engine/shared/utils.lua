GMT = GMT or {}

-- Prints a branded message in server or client console.
function GMT.Log(message)
  print(('[GTA Money Team] %s'):format(tostring(message)))
end

-- Safely reads a table value. This keeps the scripts from crashing if a customer edits config wrong.
function GMT.SafeTable(value, fallback)
  if type(value) == 'table' then return value end
  return fallback or {}
end

-- Turns a Lua table list into a readable comma-separated string.
function GMT.Join(list)
  list = GMT.SafeTable(list, {})
  local output = ''
  for i, item in ipairs(list) do
    output = output .. tostring(item)
    if i < #list then output = output .. ', ' end
  end
  return output
end
