-- =========================================================
-- GTA Money Team City Pack Config: Windy State RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'windy-state-rp',
  title = 'Windy State RP',
  tagline = 'Cold city politics, trucking unions, neighborhood crews, hard economy',
  inspiredBy = 'Chicago / Midwest city energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["ws_city_sedan", "ws_highway_trooper", "ws_tactical_van", "ws_snow_patrol", "ws_detective_unit"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["CLOUDS", "OVERCAST", "RAIN", "FOGGY", "XMAS"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Lakefront League", "South Rail Crew", "Northside Alliance", "Steel Yard Union"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Lakefront Drive", "South Rail Ave", "Downtown Grid", "North Market", "Steel Yard Road", "Windy Expressway"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Lakefront Pier', x = 435.9, y = -982.2, z = 30.7 },
    { name = 'Union Station', x = 473.4, y = -940.0, z = 32.7 },
    { name = 'Steel Yard', x = 510.9, y = -897.7, z = 34.7 },
    { name = 'City Hall Plaza', x = 548.4, y = -855.5, z = 30.7 },
    { name = 'North Market', x = 585.9, y = -813.2, z = 32.7 },
    { name = 'Winter Arena', x = 623.4, y = -771.0, z = 34.7 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = 435.9, y = -982.2, z = 30.7, h = 90.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { foreman = 30, driver = 25, mechanic = 20, security = 15, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Trucking contracts", "Tow company ownership", "Cold-weather repair jobs", "Union warehouse routes", "City permit businesses"],

  -- Discord template data used by the setup guide.
  discordChannels = ["city-hall", "union-hall", "trucking-dispatch", "mechanic-shops", "neighborhood-watch", "support-tickets"],
  discordRoles = ["City Owner", "Mayor", "Police Superintendent", "Union Boss", "Mechanic", "Business Owner", "VIP", "New Arrival"]
}
