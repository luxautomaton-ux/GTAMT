# Windy State RP — Premium City Pack

**Theme:** Cold city politics, trucking unions, neighborhood crews, hard economy  
**Inspired by:** Chicago / Midwest city energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `ws_city_sedan` — replace with a licensed vehicle model or vanilla equivalent.
- `ws_highway_trooper` — replace with a licensed vehicle model or vanilla equivalent.
- `ws_tactical_van` — replace with a licensed vehicle model or vanilla equivalent.
- `ws_snow_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `ws_detective_unit` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Lakefront Drive
- South Rail Ave
- Downtown Grid
- North Market
- Steel Yard Road
- Windy Expressway

### Landmarks
- Lakefront Pier
- Union Station
- Steel Yard
- City Hall Plaza
- North Market
- Winter Arena

### Fictional gangs / factions
- Lakefront League
- South Rail Crew
- Northside Alliance
- Steel Yard Union

### Weather rotation
CLOUDS, OVERCAST, RAIN, FOGGY, XMAS

### Legal money loops
- Trucking contracts
- Tow company ownership
- Cold-weather repair jobs
- Union warehouse routes
- City permit businesses

## Recommended crew payout split
- foreman: 30%
- driver: 25%
- mechanic: 20%
- security: 15%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
