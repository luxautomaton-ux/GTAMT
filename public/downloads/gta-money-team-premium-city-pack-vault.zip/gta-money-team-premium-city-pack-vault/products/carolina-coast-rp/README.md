# Carolina Coast RP — Premium City Pack

**Theme:** Beach towns, highways, college nights, small-business RP  
**Inspired by:** Carolinas / coastal southern energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `cc_beach_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `cc_county_sheriff` — replace with a licensed vehicle model or vanilla equivalent.
- `cc_highway_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `cc_marine_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `cc_detective_sedan` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Boardwalk Drive
- Pine Ridge Road
- College Main
- Harbor Cut
- County 17
- Lowcountry Loop

### Landmarks
- Boardwalk Pier
- College Stadium
- Harbor Market
- Pine Ridge Park
- Shrimp Dock
- Coastal Courthouse

### Fictional gangs / factions
- Boardwalk Boys
- Pine Ridge Crew
- College Circle
- Harbor Families

### Weather rotation
EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

### Legal money loops
- Food trucks
- College nightlife events
- Fishing charters
- Beach rental businesses
- Highway delivery jobs

## Recommended crew payout split
- operator: 30%
- driver: 22%
- vendor: 18%
- security: 20%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
