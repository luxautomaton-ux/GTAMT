-- =========================================================
-- GTA Money Team City Pack Config: Carolina Coast RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'carolina-coast-rp',
  title = 'Carolina Coast RP',
  tagline = 'Beach towns, highways, college nights, small-business RP',
  inspiredBy = 'Carolinas / coastal southern energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["cc_beach_patrol", "cc_county_sheriff", "cc_highway_unit", "cc_marine_unit", "cc_detective_sedan"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "CLOUDS", "RAIN", "THUNDER"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Boardwalk Boys", "Pine Ridge Crew", "College Circle", "Harbor Families"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Boardwalk Drive", "Pine Ridge Road", "College Main", "Harbor Cut", "County 17", "Lowcountry Loop"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Boardwalk Pier', x = -1603.4, y = -1045.0, z = 13.0 },
    { name = 'College Stadium', x = -1565.9, y = -1002.8, z = 15.0 },
    { name = 'Harbor Market', x = -1528.4, y = -960.5, z = 17.0 },
    { name = 'Pine Ridge Park', x = -1490.9, y = -918.2, z = 13.0 },
    { name = 'Shrimp Dock', x = -1453.4, y = -876.0, z = 15.0 },
    { name = 'Coastal Courthouse', x = -1415.9, y = -833.8, z = 17.0 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -1603.4, y = -1045.0, z = 13.0, h = 225.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { operator = 30, driver = 22, vendor = 18, security = 20, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Food trucks", "College nightlife events", "Fishing charters", "Beach rental businesses", "Highway delivery jobs"],

  -- Discord template data used by the setup guide.
  discordChannels = ["boardwalk-events", "college-life", "food-trucks", "county-sheriff", "rental-business", "support-tickets"],
  discordRoles = ["City Owner", "Sheriff", "Event Promoter", "Vendor", "Harbor Master", "VIP Resident", "Student", "New Arrival"]
}
