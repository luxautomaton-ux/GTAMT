# Desert Strip RP — Premium City Pack

**Theme:** Casino strip, hotel security, desert racing, VIP economy  
**Inspired by:** Las Vegas / desert luxury energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `ds_metro_police` — replace with a licensed vehicle model or vanilla equivalent.
- `ds_sheriff_suv` — replace with a licensed vehicle model or vanilla equivalent.
- `ds_casino_security` — replace with a licensed vehicle model or vanilla equivalent.
- `ds_desert_interceptor` — replace with a licensed vehicle model or vanilla equivalent.
- `ds_air_support` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- The Strip
- Casino Mile
- Desert Highway
- Sandy Spur
- Neon Plaza
- High Roller Lane

### Landmarks
- Neon Casino Row
- Desert Speedway
- High Roller Hotel
- Sandy Outpost
- VIP Sky Lounge
- Lux Automaton Resort Office

### Fictional gangs / factions
- Strip Kings
- Desert Diamonds
- High Roller Crew
- Sandy Road Syndicate

### Weather rotation
EXTRASUNNY, CLEAR, SMOG, CLOUDS, THUNDER

### Legal money loops
- Casino staffing
- Hotel ownership
- Desert race events
- VIP shuttle routes
- Security contracts

## Recommended crew payout split
- host: 28%
- driver: 22%
- dealer: 20%
- security: 20%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
