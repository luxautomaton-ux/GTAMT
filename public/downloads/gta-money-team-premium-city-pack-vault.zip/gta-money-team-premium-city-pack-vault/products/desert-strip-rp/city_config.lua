-- =========================================================
-- GTA Money Team City Pack Config: Desert Strip RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'desert-strip-rp',
  title = 'Desert Strip RP',
  tagline = 'Casino strip, hotel security, desert racing, VIP economy',
  inspiredBy = 'Las Vegas / desert luxury energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["ds_metro_police", "ds_sheriff_suv", "ds_casino_security", "ds_desert_interceptor", "ds_air_support"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "SMOG", "CLOUDS", "THUNDER"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Strip Kings", "Desert Diamonds", "High Roller Crew", "Sandy Road Syndicate"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["The Strip", "Casino Mile", "Desert Highway", "Sandy Spur", "Neon Plaza", "High Roller Lane"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Neon Casino Row', x = 927.9, y = 46.1, z = 80.9 },
    { name = 'Desert Speedway', x = 965.4, y = 88.3, z = 82.9 },
    { name = 'High Roller Hotel', x = 1002.9, y = 130.6, z = 84.9 },
    { name = 'Sandy Outpost', x = 1040.4, y = 172.8, z = 80.9 },
    { name = 'VIP Sky Lounge', x = 1077.9, y = 215.1, z = 82.9 },
    { name = 'Lux Automaton Resort Office', x = 1115.4, y = 257.4, z = 84.9 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = 927.9, y = 46.1, z = 80.9, h = 60.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { host = 28, driver = 22, dealer = 20, security = 20, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Casino staffing", "Hotel ownership", "Desert race events", "VIP shuttle routes", "Security contracts"],

  -- Discord template data used by the setup guide.
  discordChannels = ["casino-floor", "hotel-bookings", "race-events", "vip-requests", "security-office", "support-tickets"],
  discordRoles = ["Casino Owner", "Hotel Manager", "Metro Chief", "VIP Host", "Race Promoter", "Dealer", "VIP Guest", "New Arrival"]
}
