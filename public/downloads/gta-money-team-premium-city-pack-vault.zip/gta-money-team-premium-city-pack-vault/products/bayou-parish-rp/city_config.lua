-- =========================================================
-- GTA Money Team City Pack Config: Bayou Parish RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'bayou-parish-rp',
  title = 'Bayou Parish RP',
  tagline = 'Southern noir, swamp routes, sheriff politics, music economy',
  inspiredBy = 'New Orleans / Louisiana bayou energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["bp_sheriff_tahoe", "bp_state_trooper", "bp_swamp_rescue", "bp_marshal_unit", "bp_airboat_unit"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["CLEAR", "CLOUDS", "RAIN", "THUNDER", "FOGGY"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Parish Riders", "River Saints", "Canal Boys", "Gator Road Family"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Canal Crown", "Bourbon Loop", "Bayou Cutoff", "Parish Road 12", "Riverwalk East", "Cypress Bend"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Crescent Plaza', x = 1964.1, y = 3819.9, z = 32.4 },
    { name = 'Bayou Landing', x = 2001.6, y = 3862.2, z = 34.4 },
    { name = 'Parish Courthouse', x = 2039.1, y = 3904.4, z = 36.4 },
    { name = 'Old Jazz Hall', x = 2076.6, y = 3946.7, z = 32.4 },
    { name = 'Riverboat Dock', x = 2114.1, y = 3988.9, z = 34.4 },
    { name = 'Gator Market', x = 2151.6, y = 4031.2, z = 36.4 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = 1964.1, y = 3819.9, z = 32.4, h = 120.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { boss = 32, runner = 24, cook = 18, security = 16, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Fishing contracts", "Riverboat events", "Food stand licenses", "Swamp rescue work", "Music venue ownership"],

  -- Discord template data used by the setup guide.
  discordChannels = ["parish-rules", "sheriff-office", "music-bookings", "food-vendors", "bayou-business", "support-tickets"],
  discordRoles = ["Parish Owner", "Sheriff", "Deputy", "EMS", "Venue Owner", "Food Vendor", "Musician", "New Arrival"]
}
