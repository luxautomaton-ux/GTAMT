# Bayou Parish RP — Premium City Pack

**Theme:** Southern noir, swamp routes, sheriff politics, music economy  
**Inspired by:** New Orleans / Louisiana bayou energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `bp_sheriff_tahoe` — replace with a licensed vehicle model or vanilla equivalent.
- `bp_state_trooper` — replace with a licensed vehicle model or vanilla equivalent.
- `bp_swamp_rescue` — replace with a licensed vehicle model or vanilla equivalent.
- `bp_marshal_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `bp_airboat_unit` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Canal Crown
- Bourbon Loop
- Bayou Cutoff
- Parish Road 12
- Riverwalk East
- Cypress Bend

### Landmarks
- Crescent Plaza
- Bayou Landing
- Parish Courthouse
- Old Jazz Hall
- Riverboat Dock
- Gator Market

### Fictional gangs / factions
- Parish Riders
- River Saints
- Canal Boys
- Gator Road Family

### Weather rotation
CLEAR, CLOUDS, RAIN, THUNDER, FOGGY

### Legal money loops
- Fishing contracts
- Riverboat events
- Food stand licenses
- Swamp rescue work
- Music venue ownership

## Recommended crew payout split
- boss: 32%
- runner: 24%
- cook: 18%
- security: 16%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
