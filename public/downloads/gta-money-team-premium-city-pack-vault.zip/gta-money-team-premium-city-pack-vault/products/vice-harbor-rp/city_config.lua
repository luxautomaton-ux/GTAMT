-- =========================================================
-- GTA Money Team City Pack Config: Vice Harbor RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'vice-harbor-rp',
  title = 'Vice Harbor RP',
  tagline = 'Luxury marina, neon beach, port money, streamer lifestyle',
  inspiredBy = 'Miami / South Florida energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["vh_police_cruiser", "vh_police_interceptor", "vh_sheriff_suv", "vh_marine_unit", "vh_air_one"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "CLOUDS", "RAIN", "THUNDER"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Harbor Kings", "Palm Saints", "South Beach Syndicate", "Portside Circle"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Ocean Mile", "Palm Run", "Biscayne Strip", "Marina Row", "Viceport Causeway", "Sunset Harbor Drive"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Neon Marina', x = -1037.4, y = -2737.6, z = 20.2 },
    { name = 'Palm Pier', x = -999.9, y = -2695.3, z = 22.2 },
    { name = 'Viceport Docks', x = -962.4, y = -2653.1, z = 24.2 },
    { name = 'Diamond Hotel Strip', x = -924.9, y = -2610.8, z = 20.2 },
    { name = 'Sunset Rooftop', x = -887.4, y = -2568.6, z = 22.2 },
    { name = 'Lux Automaton Waterfront HQ', x = -849.9, y = -2526.3, z = 24.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -1037.4, y = -2737.6, z = 20.2, h = 330.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { crew_leader = 35, driver = 25, security = 15, dispatcher = 15, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Yacht logistics contracts", "Port trucking loops", "Beach club ownership", "Luxury vehicle imports", "Creator nightlife events"],

  -- Discord template data used by the setup guide.
  discordChannels = ["announcements", "rules", "apply-for-whitelist", "marina-business", "port-contracts", "creator-clips", "support-tickets"],
  discordRoles = ["Founder", "City Manager", "Police Chief", "EMS Director", "Business Owner", "VIP Resident", "Streamer", "New Arrival"]
}
