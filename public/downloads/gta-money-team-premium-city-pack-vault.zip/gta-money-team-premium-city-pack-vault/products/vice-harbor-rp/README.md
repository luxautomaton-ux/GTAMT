# Vice Harbor RP — Premium City Pack

**Theme:** Luxury marina, neon beach, port money, streamer lifestyle  
**Inspired by:** Miami / South Florida energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `vh_police_cruiser` — replace with a licensed vehicle model or vanilla equivalent.
- `vh_police_interceptor` — replace with a licensed vehicle model or vanilla equivalent.
- `vh_sheriff_suv` — replace with a licensed vehicle model or vanilla equivalent.
- `vh_marine_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `vh_air_one` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Ocean Mile
- Palm Run
- Biscayne Strip
- Marina Row
- Viceport Causeway
- Sunset Harbor Drive

### Landmarks
- Neon Marina
- Palm Pier
- Viceport Docks
- Diamond Hotel Strip
- Sunset Rooftop
- Lux Automaton Waterfront HQ

### Fictional gangs / factions
- Harbor Kings
- Palm Saints
- South Beach Syndicate
- Portside Circle

### Weather rotation
EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

### Legal money loops
- Yacht logistics contracts
- Port trucking loops
- Beach club ownership
- Luxury vehicle imports
- Creator nightlife events

## Recommended crew payout split
- crew_leader: 35%
- driver: 25%
- security: 15%
- dispatcher: 15%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
