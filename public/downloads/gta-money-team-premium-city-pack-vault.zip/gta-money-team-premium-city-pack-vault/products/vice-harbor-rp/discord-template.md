# Discord Template — Vice Harbor RP

## Recommended roles
- Founder
- City Manager
- Police Chief
- EMS Director
- Business Owner
- VIP Resident
- Streamer
- New Arrival

## Recommended channels
- #announcements
- #rules
- #apply-for-whitelist
- #marina-business
- #port-contracts
- #creator-clips
- #support-tickets

## Community rules starter copy

1. Stay in character during serious RP scenes.
2. No doxxing, harassment, hate speech, or real-world threats.
3. No cheating, mod menus, exploit abuse, money glitches, or malicious downloads.
4. No combat logging.
5. No staff disrespect; use tickets and appeals.
6. All gangs and businesses must apply and receive approval.
7. Economy exploits must be reported, not abused.
8. Stream sniping is not allowed.

## Whitelist application questions

1. What is your RP experience?
2. What kind of character will you create?
3. Do you understand no-cheat/no-exploit rules?
4. What time zone are you in?
5. Are you interested in police, EMS, business, gang, or civilian RP?

## Ticket categories

- General Support
- Ban Appeal
- Donation Support
- Bug Report
- Business Application
- Gang Application
- Police / EMS Application
