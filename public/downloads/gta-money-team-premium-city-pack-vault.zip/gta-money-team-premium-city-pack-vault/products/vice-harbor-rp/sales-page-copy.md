# Sales Page Copy — Vice Harbor RP

## Headline
Launch **Vice Harbor RP** without starting from zero.

## Subheadline
A premium FiveM city identity pack with police fleet placeholders, original factions, key streets, landmarks, weather, crew payout plans, Discord setup, and legal money loops.

## What buyers get

- City identity and lore foundation.
- Police/security structure.
- Fictional gangs/factions.
- Street and landmark map language.
- Weather and atmosphere profile.
- Crew payout model.
- Discord server template.
- Setup instructions.
- Starter Lua city config.

## Price anchors

- Template ZIP only: $99
- Template + Discord setup: $249
- Installed server identity: $499
- Custom assets/framework integration: $1,500+

## CTA
Buy the pack, install the city identity, and start building your RP community the smart way.
