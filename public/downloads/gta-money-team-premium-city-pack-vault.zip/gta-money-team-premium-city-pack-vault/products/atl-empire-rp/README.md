# ATL Empire RP — Premium City Pack

**Theme:** Music business, airport logistics, film crews, high-growth crews  
**Inspired by:** Atlanta creator and entertainment energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `ae_city_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `ae_gsu_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `ae_airport_police` — replace with a licensed vehicle model or vanilla equivalent.
- `ae_interceptor` — replace with a licensed vehicle model or vanilla equivalent.
- `ae_command_suv` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Peachtree Run
- A-Town Connector
- Studio Lane
- Airport Road
- Cascade Bend
- Midtown Loop

### Landmarks
- Empire Studio Lot
- Peachtree Mall
- Airport Cargo Yard
- Cascade Club
- Downtown Arena
- Lux Automaton Creative Lab

### Fictional gangs / factions
- Peachtree Circle
- Southside Management
- Airport Road Crew
- Studio Block

### Weather rotation
EXTRASUNNY, CLEAR, CLOUDS, OVERCAST, RAIN

### Legal money loops
- Studio bookings
- Airport cargo contracts
- Artist management
- Vehicle rental company
- Film permit missions

## Recommended crew payout split
- executive: 30%
- artist: 20%
- producer: 20%
- security: 15%
- ops: 15%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
