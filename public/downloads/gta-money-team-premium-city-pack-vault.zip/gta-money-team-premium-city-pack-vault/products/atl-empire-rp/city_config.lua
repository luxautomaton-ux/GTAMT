-- =========================================================
-- GTA Money Team City Pack Config: ATL Empire RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'atl-empire-rp',
  title = 'ATL Empire RP',
  tagline = 'Music business, airport logistics, film crews, high-growth crews',
  inspiredBy = 'Atlanta creator and entertainment energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["ae_city_patrol", "ae_gsu_unit", "ae_airport_police", "ae_interceptor", "ae_command_suv"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "CLOUDS", "OVERCAST", "RAIN"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Peachtree Circle", "Southside Management", "Airport Road Crew", "Studio Block"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Peachtree Run", "A-Town Connector", "Studio Lane", "Airport Road", "Cascade Bend", "Midtown Loop"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Empire Studio Lot', x = -1034.6, y = -2733.6, z = 20.2 },
    { name = 'Peachtree Mall', x = -997.1, y = -2691.3, z = 22.2 },
    { name = 'Airport Cargo Yard', x = -959.6, y = -2649.1, z = 24.2 },
    { name = 'Cascade Club', x = -922.1, y = -2606.8, z = 20.2 },
    { name = 'Downtown Arena', x = -884.6, y = -2564.6, z = 22.2 },
    { name = 'Lux Automaton Creative Lab', x = -847.1, y = -2522.3, z = 24.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -1034.6, y = -2733.6, z = 20.2, h = 327.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { executive = 30, artist = 20, producer = 20, security = 15, ops = 15 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Studio bookings", "Airport cargo contracts", "Artist management", "Vehicle rental company", "Film permit missions"],

  -- Discord template data used by the setup guide.
  discordChannels = ["studio-announcements", "artist-applications", "airport-jobs", "business-pitches", "clip-submissions", "support-tickets"],
  discordRoles = ["Founder", "Label Boss", "Police Chief", "Studio Owner", "Promoter", "VIP Artist", "Security", "New Arrival"]
}
