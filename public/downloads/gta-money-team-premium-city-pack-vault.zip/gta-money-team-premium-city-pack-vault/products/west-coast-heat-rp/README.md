# West Coast Heat RP — Premium City Pack

**Theme:** Street crews, studios, beach money, luxury retail  
**Inspired by:** Los Angeles / West Coast RP energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `wch_lspd_cruiser` — replace with a licensed vehicle model or vanilla equivalent.
- `wch_lspd_interceptor` — replace with a licensed vehicle model or vanilla equivalent.
- `wch_swat_bearcat` — replace with a licensed vehicle model or vanilla equivalent.
- `wch_beach_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `wch_air_one` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Vinewood Blvd
- Del Perro Walk
- Canyon Ridge
- East Forum Drive
- Movie Lot Road
- Pacific Cliff

### Landmarks
- Vinewood Sign
- Movie Studio Gate
- Del Perro Pier
- Canyon Overlook
- Designer Row
- Pacific Club

### Fictional gangs / factions
- Vinewood Set
- South Beach Families
- Eastside Royals
- Canyon Cartel

### Weather rotation
EXTRASUNNY, CLEAR, SMOG, CLOUDS, RAIN

### Legal money loops
- Studio security
- Influencer content missions
- Luxury retail ownership
- Beach delivery loops
- Canyon racing events as legal RP

## Recommended crew payout split
- leader: 34%
- driver: 22%
- producer: 18%
- security: 16%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
