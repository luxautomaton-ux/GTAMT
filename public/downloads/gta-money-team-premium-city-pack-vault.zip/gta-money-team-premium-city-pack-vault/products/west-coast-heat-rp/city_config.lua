-- =========================================================
-- GTA Money Team City Pack Config: West Coast Heat RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'west-coast-heat-rp',
  title = 'West Coast Heat RP',
  tagline = 'Street crews, studios, beach money, luxury retail',
  inspiredBy = 'Los Angeles / West Coast RP energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["wch_lspd_cruiser", "wch_lspd_interceptor", "wch_swat_bearcat", "wch_beach_patrol", "wch_air_one"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "SMOG", "CLOUDS", "RAIN"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Vinewood Set", "South Beach Families", "Eastside Royals", "Canyon Cartel"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Vinewood Blvd", "Del Perro Walk", "Canyon Ridge", "East Forum Drive", "Movie Lot Road", "Pacific Cliff"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Vinewood Sign', x = -1376.6, y = -494.2, z = 33.2 },
    { name = 'Movie Studio Gate', x = -1339.1, y = -451.9, z = 35.2 },
    { name = 'Del Perro Pier', x = -1301.6, y = -409.7, z = 37.2 },
    { name = 'Canyon Overlook', x = -1264.1, y = -367.4, z = 33.2 },
    { name = 'Designer Row', x = -1226.6, y = -325.2, z = 35.2 },
    { name = 'Pacific Club', x = -1189.1, y = -282.9, z = 37.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -1376.6, y = -494.2, z = 33.2, h = 98.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { leader = 34, driver = 22, producer = 18, security = 16, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Studio security", "Influencer content missions", "Luxury retail ownership", "Beach delivery loops", "Canyon racing events as legal RP"],

  -- Discord template data used by the setup guide.
  discordChannels = ["film-lot", "crew-apps", "beach-business", "vip-lounge", "event-calendar", "support-tickets"],
  discordRoles = ["Owner", "City Admin", "LSPD Chief", "Studio Head", "Retail Owner", "Streamer", "VIP", "New Arrival"]
}
