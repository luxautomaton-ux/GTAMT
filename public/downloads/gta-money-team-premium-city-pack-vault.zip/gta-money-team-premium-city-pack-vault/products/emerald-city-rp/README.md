# Emerald City RP — Premium City Pack

**Theme:** Rainy tech city, ports, startups, clean community systems  
**Inspired by:** Seattle / Pacific Northwest energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `ec_city_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `ec_port_police` — replace with a licensed vehicle model or vanilla equivalent.
- `ec_bike_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `ec_detective_suv` — replace with a licensed vehicle model or vanilla equivalent.
- `ec_rescue_truck` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Rainier Road
- Portside Way
- Market Row
- Evergreen Ave
- Tech Ridge
- Sound Drive

### Landmarks
- Sky Needle Viewpoint
- Fish Market
- Port Terminal
- Startup Tower
- Rain Garden Park
- Lux Automaton Cloud Office

### Fictional gangs / factions
- Rain City Circle
- Portside Coders
- Market Row Crew
- Evergreen Collective

### Weather rotation
RAIN, CLOUDS, OVERCAST, FOGGY, CLEAR

### Legal money loops
- Startup pitches
- Port contracts
- Coffee shop chains
- Tech repair services
- Streamer coworking memberships

## Recommended crew payout split
- founder: 30%
- engineer: 20%
- operator: 20%
- sales: 15%
- community: 15%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
