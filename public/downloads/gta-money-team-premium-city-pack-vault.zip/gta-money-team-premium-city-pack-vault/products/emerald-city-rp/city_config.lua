-- =========================================================
-- GTA Money Team City Pack Config: Emerald City RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'emerald-city-rp',
  title = 'Emerald City RP',
  tagline = 'Rainy tech city, ports, startups, clean community systems',
  inspiredBy = 'Seattle / Pacific Northwest energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["ec_city_patrol", "ec_port_police", "ec_bike_unit", "ec_detective_suv", "ec_rescue_truck"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["RAIN", "CLOUDS", "OVERCAST", "FOGGY", "CLEAR"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Rain City Circle", "Portside Coders", "Market Row Crew", "Evergreen Collective"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Rainier Road", "Portside Way", "Market Row", "Evergreen Ave", "Tech Ridge", "Sound Drive"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Sky Needle Viewpoint', x = -705.7, y = -913.5, z = 19.2 },
    { name = 'Fish Market', x = -668.2, y = -871.2, z = 21.2 },
    { name = 'Port Terminal', x = -630.7, y = -829.0, z = 23.2 },
    { name = 'Startup Tower', x = -593.2, y = -786.8, z = 19.2 },
    { name = 'Rain Garden Park', x = -555.7, y = -744.5, z = 21.2 },
    { name = 'Lux Automaton Cloud Office', x = -518.2, y = -702.2, z = 23.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -705.7, y = -913.5, z = 19.2, h = 90.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { founder = 30, engineer = 20, operator = 20, sales = 15, community = 15 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Startup pitches", "Port contracts", "Coffee shop chains", "Tech repair services", "Streamer coworking memberships"],

  -- Discord template data used by the setup guide.
  discordChannels = ["startup-hub", "port-work", "coffee-shops", "tech-support", "community-events", "support-tickets"],
  discordRoles = ["Founder", "Police Chief", "Port Director", "Startup CEO", "Engineer", "Creator", "VIP", "New Arrival"]
}
