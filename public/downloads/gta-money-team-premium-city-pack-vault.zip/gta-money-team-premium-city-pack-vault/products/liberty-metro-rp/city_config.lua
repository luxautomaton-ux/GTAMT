-- =========================================================
-- GTA Money Team City Pack Config: Liberty Metro RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'liberty-metro-rp',
  title = 'Liberty Metro RP',
  tagline = 'Big-city hustle, borough politics, finance districts, taxi grids',
  inspiredBy = 'New York / Liberty City energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["lm_patrol_sedan", "lm_unmarked_taxi_unit", "lm_highway_interceptor", "lm_transit_suv", "lm_air_support"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["CLEAR", "OVERCAST", "RAIN", "FOGGY", "XMAS"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Borough Alliance", "Canal Crew", "Uptown Syndicate", "Dockyard Family"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Broker Avenue", "Liberty Exchange", "Canal Row", "Hudson Cut", "Metro North Drive", "Financial Loop"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Central Station', x = -268.7, y = -956.0, z = 31.2 },
    { name = 'Liberty Exchange Tower', x = -231.2, y = -913.8, z = 33.2 },
    { name = 'Canal Market', x = -193.7, y = -871.5, z = 35.2 },
    { name = 'Old Dockyard', x = -156.2, y = -829.2, z = 31.2 },
    { name = 'Uptown Courts', x = -118.7, y = -787.0, z = 33.2 },
    { name = 'Metro News Building', x = -81.2, y = -744.8, z = 35.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -268.7, y = -956.0, z = 31.2, h = 205.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { crew_leader = 30, driver = 25, planner = 20, lookout = 15, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Taxi medallion routes", "Courier contracts", "Stock room heists as RP events", "Food truck franchises", "High-rise security contracts"],

  -- Discord template data used by the setup guide.
  discordChannels = ["city-hall", "court-dockets", "taxi-dispatch", "business-license", "media-room", "support-tickets"],
  discordRoles = ["Mayor", "Commissioner", "Judge", "Transit Boss", "Union Rep", "VIP Resident", "Press", "New Arrival"]
}
