# Liberty Metro RP — Premium City Pack

**Theme:** Big-city hustle, borough politics, finance districts, taxi grids  
**Inspired by:** New York / Liberty City energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `lm_patrol_sedan` — replace with a licensed vehicle model or vanilla equivalent.
- `lm_unmarked_taxi_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `lm_highway_interceptor` — replace with a licensed vehicle model or vanilla equivalent.
- `lm_transit_suv` — replace with a licensed vehicle model or vanilla equivalent.
- `lm_air_support` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Broker Avenue
- Liberty Exchange
- Canal Row
- Hudson Cut
- Metro North Drive
- Financial Loop

### Landmarks
- Central Station
- Liberty Exchange Tower
- Canal Market
- Old Dockyard
- Uptown Courts
- Metro News Building

### Fictional gangs / factions
- Borough Alliance
- Canal Crew
- Uptown Syndicate
- Dockyard Family

### Weather rotation
CLEAR, OVERCAST, RAIN, FOGGY, XMAS

### Legal money loops
- Taxi medallion routes
- Courier contracts
- Stock room heists as RP events
- Food truck franchises
- High-rise security contracts

## Recommended crew payout split
- crew_leader: 30%
- driver: 25%
- planner: 20%
- lookout: 15%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
