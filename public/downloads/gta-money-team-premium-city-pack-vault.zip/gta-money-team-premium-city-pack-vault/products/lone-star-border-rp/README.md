# Lone Star Border RP — Premium City Pack

**Theme:** Ranch money, state troopers, oil routes, border highways  
**Inspired by:** Texas / Southwest energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `lsb_state_trooper` — replace with a licensed vehicle model or vanilla equivalent.
- `lsb_ranger_truck` — replace with a licensed vehicle model or vanilla equivalent.
- `lsb_border_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `lsb_sheriff_pickup` — replace with a licensed vehicle model or vanilla equivalent.
- `lsb_air_support` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Ranch Road 9
- Oilfield Spur
- Border Highway
- Longhorn Main
- Mesa Run
- County Line

### Landmarks
- State Capitol Outpost
- Oilfield Depot
- County Rodeo
- Border Crossing
- Longhorn Ranch
- Mesa Airstrip

### Fictional gangs / factions
- Ranch Road Crew
- Borderline Kings
- Oilfield Syndicate
- Desert Saints

### Weather rotation
EXTRASUNNY, CLEAR, SMOG, CLOUDS, THUNDER

### Legal money loops
- Ranch ownership
- Oilfield hauling
- County fair events
- Tow and recovery
- Airstrip logistics

## Recommended crew payout split
- owner: 32%
- hauler: 24%
- ranch_hand: 18%
- security: 16%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
