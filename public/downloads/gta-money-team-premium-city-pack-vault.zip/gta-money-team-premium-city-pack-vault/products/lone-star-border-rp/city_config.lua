-- =========================================================
-- GTA Money Team City Pack Config: Lone Star Border RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'lone-star-border-rp',
  title = 'Lone Star Border RP',
  tagline = 'Ranch money, state troopers, oil routes, border highways',
  inspiredBy = 'Texas / Southwest energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["lsb_state_trooper", "lsb_ranger_truck", "lsb_border_unit", "lsb_sheriff_pickup", "lsb_air_support"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "SMOG", "CLOUDS", "THUNDER"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Ranch Road Crew", "Borderline Kings", "Oilfield Syndicate", "Desert Saints"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Ranch Road 9", "Oilfield Spur", "Border Highway", "Longhorn Main", "Mesa Run", "County Line"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'State Capitol Outpost', x = 1853.2, y = 3689.5, z = 34.2 },
    { name = 'Oilfield Depot', x = 1890.7, y = 3731.8, z = 36.2 },
    { name = 'County Rodeo', x = 1928.2, y = 3774.0, z = 38.2 },
    { name = 'Border Crossing', x = 1965.7, y = 3816.2, z = 34.2 },
    { name = 'Longhorn Ranch', x = 2003.2, y = 3858.5, z = 36.2 },
    { name = 'Mesa Airstrip', x = 2040.7, y = 3900.8, z = 38.2 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = 1853.2, y = 3689.5, z = 34.2, h = 210.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { owner = 32, hauler = 24, ranch_hand = 18, security = 16, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Ranch ownership", "Oilfield hauling", "County fair events", "Tow and recovery", "Airstrip logistics"],

  -- Discord template data used by the setup guide.
  discordChannels = ["ranch-office", "trooper-hq", "oilfield-dispatch", "county-court", "business-permits", "support-tickets"],
  discordRoles = ["County Owner", "State Trooper", "Ranger", "Ranch Owner", "Oil Boss", "Pilot", "VIP Resident", "New Arrival"]
}
