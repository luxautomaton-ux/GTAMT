-- =========================================================
-- GTA Money Team City Pack Config: Island Keys RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'island-keys-rp',
  title = 'Island Keys RP',
  tagline = 'Tropical islands, marine patrol, resort economy, ocean routes',
  inspiredBy = 'Florida Keys / island luxury energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["ik_marine_patrol", "ik_resort_security", "ik_sheriff_jeep", "ik_coast_air", "ik_island_cruiser"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["EXTRASUNNY", "CLEAR", "CLOUDS", "RAIN", "THUNDER"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Keyside Crew", "Reef Riders", "Resort Syndicate", "Coral Circle"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Overseas Highway", "Reef Road", "Resort Row", "Coral Bend", "Dock Street", "Island Mile"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Coral Resort', x = -2183.8, y = -400.5, z = 13.3 },
    { name = 'Reef Marina', x = -2146.3, y = -358.2, z = 15.3 },
    { name = 'Island Airstrip', x = -2108.8, y = -316.0, z = 17.3 },
    { name = 'Dock Street Market', x = -2071.3, y = -273.8, z = 13.3 },
    { name = 'Sunset Key', x = -2033.8, y = -231.5, z = 15.3 },
    { name = 'Marine Patrol Station', x = -1996.3, y = -189.2, z = 17.3 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -2183.8, y = -400.5, z = 13.3, h = 130.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { captain = 30, pilot = 20, guide = 20, security = 20, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Resort memberships", "Boat charter routes", "Diving tours", "Island delivery loops", "VIP event hosting"],

  -- Discord template data used by the setup guide.
  discordChannels = ["resort-checkin", "boat-charters", "marine-patrol", "vip-events", "island-market", "support-tickets"],
  discordRoles = ["Island Owner", "Marine Chief", "Captain", "Resort Manager", "Tour Guide", "VIP Guest", "Dock Worker", "New Arrival"]
}
