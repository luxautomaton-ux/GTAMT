# Island Keys RP — Premium City Pack

**Theme:** Tropical islands, marine patrol, resort economy, ocean routes  
**Inspired by:** Florida Keys / island luxury energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `ik_marine_patrol` — replace with a licensed vehicle model or vanilla equivalent.
- `ik_resort_security` — replace with a licensed vehicle model or vanilla equivalent.
- `ik_sheriff_jeep` — replace with a licensed vehicle model or vanilla equivalent.
- `ik_coast_air` — replace with a licensed vehicle model or vanilla equivalent.
- `ik_island_cruiser` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Overseas Highway
- Reef Road
- Resort Row
- Coral Bend
- Dock Street
- Island Mile

### Landmarks
- Coral Resort
- Reef Marina
- Island Airstrip
- Dock Street Market
- Sunset Key
- Marine Patrol Station

### Fictional gangs / factions
- Keyside Crew
- Reef Riders
- Resort Syndicate
- Coral Circle

### Weather rotation
EXTRASUNNY, CLEAR, CLOUDS, RAIN, THUNDER

### Legal money loops
- Resort memberships
- Boat charter routes
- Diving tours
- Island delivery loops
- VIP event hosting

## Recommended crew payout split
- captain: 30%
- pilot: 20%
- guide: 20%
- security: 20%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
