# Motor City RP — Premium City Pack

**Theme:** Car culture, repair economy, street-to-enterprise growth  
**Inspired by:** Detroit / automotive comeback energy  
**Use case:** Sell as a city starter pack, install as a DFY server identity, or use as the foundation for a custom roleplay server.

## What this city includes

### Police fleet placeholders
- `mc_city_cruiser` — replace with a licensed vehicle model or vanilla equivalent.
- `mc_auto_theft_unit` — replace with a licensed vehicle model or vanilla equivalent.
- `mc_highway_sedan` — replace with a licensed vehicle model or vanilla equivalent.
- `mc_tactical_van` — replace with a licensed vehicle model or vanilla equivalent.
- `mc_detective_suv` — replace with a licensed vehicle model or vanilla equivalent.

### Key streets / districts
- Assembly Row
- River Rouge Road
- East Yard Ave
- Motor Mile
- Factory Loop
- Downtown Recovery

### Landmarks
- Old Assembly Plant
- River Warehouse
- Motor Museum
- Downtown Garage
- Recovery Yard
- Luxury Auto Mall

### Fictional gangs / factions
- Motor Block
- East Yard Crew
- River Rouge Family
- Warehouse Kings

### Weather rotation
CLEAR, OVERCAST, RAIN, FOGGY, XMAS

### Legal money loops
- Mechanic chains
- Vehicle recovery contracts
- Auto auction events
- Warehouse ownership
- Detail shop memberships

## Recommended crew payout split
- shop_owner: 30%
- mechanic: 25%
- tow_driver: 20%
- sales: 15%
- reserve: 10%

## Setup

1. Copy `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
2. Copy `server-snippet.cfg` lines into your `server.cfg`.
3. Start or restart the `gmt_city_engine` resource.
4. Join the server and test `/citypack`, `/landmarks`, `/gangs`, `/streets`, and `/payouts`.
5. Replace police vehicle placeholders with assets you own or licensed marketplace assets.
6. Customize Discord channels using `discord-template.md`.

## Best upsell for this pack

Sell this pack with a **DFY install + Discord setup** bundle. The buyer gets the city identity, staff roles, channels, starter economy, and testing session.
