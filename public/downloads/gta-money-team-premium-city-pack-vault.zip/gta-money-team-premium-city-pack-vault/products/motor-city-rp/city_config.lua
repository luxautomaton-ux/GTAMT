-- =========================================================
-- GTA Money Team City Pack Config: Motor City RP
-- =========================================================
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- Then restart the resource.

GMTCity = {
  id = 'motor-city-rp',
  title = 'Motor City RP',
  tagline = 'Car culture, repair economy, street-to-enterprise growth',
  inspiredBy = 'Detroit / automotive comeback energy',
  maxRecommendedPlayers = 64,

  -- Police vehicle model placeholders. Replace with vanilla GTA vehicle models or licensed custom models.
  policeFleet = ["mc_city_cruiser", "mc_auto_theft_unit", "mc_highway_sedan", "mc_tactical_van", "mc_detective_suv"],

  -- Weather types supported by GTA/FiveM. Replace or shorten if you use a dedicated weather resource.
  weatherRotation = ["CLEAR", "OVERCAST", "RAIN", "FOGGY", "XMAS"],

  -- Fictional factions only. Avoid real gang names/logos in paid templates.
  gangs = ["Motor Block", "East Yard Crew", "River Rouge Family", "Warehouse Kings"],

  -- Street/district identity used in guides, dispatch names, RP documents, and route planning.
  streets = ["Assembly Row", "River Rouge Road", "East Yard Ave", "Motor Mile", "Factory Loop", "Downtown Recovery"],

  -- Landmark coordinates are starter RP markers. Adjust to match your MLO/map layout.
  landmarks = {

    { name = 'Old Assembly Plant', x = -356.9, y = -134.8, z = 39.0 },
    { name = 'River Warehouse', x = -319.4, y = -92.6, z = 41.0 },
    { name = 'Motor Museum', x = -281.9, y = -50.3, z = 43.0 },
    { name = 'Downtown Garage', x = -244.4, y = -8.1, z = 39.0 },
    { name = 'Recovery Yard', x = -206.9, y = 34.2, z = 41.0 },
    { name = 'Luxury Auto Mall', x = -169.4, y = 76.4, z = 43.0 }
  },

  -- Main spawn / welcome area for this city identity.
  defaultSpawn = { x = -356.9, y = -134.8, z = 39.0, h = 250.0 },

  -- Recommended split to reduce crew payout drama.
  payoutSplit = { shop_owner = 30, mechanic = 25, tow_driver = 20, sales = 15, reserve = 10 },

  -- Starter security recommendations shown in guide/UI.
  security = {
    whitelistRecommended = true,
    eventLogging = true,
    economyAudit = true,
    staffBodycamPolicy = true,
    paidAssetsMustBeLicensed = true
  },

  -- Money loops are legal RP gameplay/business ideas, not cheats or exploits.
  moneyLoops = ["Mechanic chains", "Vehicle recovery contracts", "Auto auction events", "Warehouse ownership", "Detail shop memberships"],

  -- Discord template data used by the setup guide.
  discordChannels = ["garage-bay", "tow-dispatch", "auto-auctions", "shop-applications", "parts-market", "support-tickets"],
  discordRoles = ["Shop Owner", "Police Chief", "Mechanic Lead", "Tow Boss", "Dealer", "VIP Driver", "Rookie Tech", "New Arrival"]
}
