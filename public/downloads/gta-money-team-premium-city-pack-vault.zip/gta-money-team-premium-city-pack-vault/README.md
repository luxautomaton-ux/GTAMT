# GTA Money Team — Premium FiveM City Pack Vault

**Product:** 12 original premium city-roleplay starter packs for FiveM / GTA V RP sellers.  
**Brand:** GTA Money Team — Learn how to make money the legit way.  
**Built by:** Lux Automaton.

This vault is built so you can sell city-themed starter packs, install them for clients, or use them as a base for custom server builds. Every pack is original. It is designed to give buyers the *structure* of a professional RP server: city concept, police fleet placeholders, landmark list, weather rotation, gang/faction names, street districts, payout models, Discord community layout, security notes, and starter Lua/resource files.

## Important legal / product note

This vault does **not** include ripped vehicles, real police department logos, paid scripts, copyrighted maps, or cloned logic from any famous RP server. Each city is inspired by real-world vibes, but all names, gangs, police units, landmarks, and economies are original templates. Buyers can add their own licensed vehicle packs, MLOs, EUP, clothing, maps, and frameworks later.

## What is included

- 12 sellable city concepts.
- A shared FiveM resource: `gmt_city_engine`.
- Per-city Lua config files.
- Per-city `server.cfg` snippets.
- Per-city Discord templates.
- Security hardening checklist.
- Crew payout models.
- Tebex/product pricing suggestions.
- Customer onboarding docs.

## City packs included

- **Vice Harbor RP** — Luxury marina, neon beach, port money, streamer lifestyle
- **Liberty Metro RP** — Big-city hustle, borough politics, finance districts, taxi grids
- **Bayou Parish RP** — Southern noir, swamp routes, sheriff politics, music economy
- **ATL Empire RP** — Music business, airport logistics, film crews, high-growth crews
- **West Coast Heat RP** — Street crews, studios, beach money, luxury retail
- **Windy State RP** — Cold city politics, trucking unions, neighborhood crews, hard economy
- **Desert Strip RP** — Casino strip, hotel security, desert racing, VIP economy
- **Motor City RP** — Car culture, repair economy, street-to-enterprise growth
- **Lone Star Border RP** — Ranch money, state troopers, oil routes, border highways
- **Emerald City RP** — Rainy tech city, ports, startups, clean community systems
- **Carolina Coast RP** — Beach towns, highways, college nights, small-business RP
- **Island Keys RP** — Tropical islands, marine patrol, resort economy, ocean routes

## Quick install

1. Install FXServer / txAdmin.
2. Copy `resources/[gmt]/gmt_city_engine` into your server resources folder.
3. Pick one city pack from `products/<pack-id>/city_config.lua`.
4. Copy it to `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
5. Add the `server.cfg` snippet for the chosen pack.
6. Start or restart the server.

## Suggested pricing

- Single city pack ZIP: **$79–$149**
- City pack + Discord template: **$199–$299**
- Installed by Lux Automaton: **$399–$799**
- Custom city with vehicles/MLO integration: **$1,500+**
- Monthly support / security / economy tuning: **$199–$499/mo**

## Recommended next layer

This vault is intentionally framework-neutral. For a full server, connect it to QBCore, ESX, ox_inventory, ox_lib, ps-dispatch, pma-voice, or your preferred licensed resources. Use this pack as the city identity, economy structure, security policy, and product foundation.
