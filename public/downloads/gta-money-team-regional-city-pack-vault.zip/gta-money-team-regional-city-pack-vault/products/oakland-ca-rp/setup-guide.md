# Setup Guide — Bayline Oakland RP

## Step 1 — Install shared resource

Copy:

`resources/[gmt]/gmt_city_engine`

to your FiveM resources folder.

## Step 2 — Activate this city

Copy:

`products/oakland-ca-rp/city_config.lua`

to:

`resources/[gmt]/gmt_city_engine/config/active_city.lua`

## Step 3 — Update server.cfg

Add the contents of `server-snippet.cfg`, then restart.

## Step 4 — Test in game

Run:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/moneyloops`
- `/securitycheck`

## Step 5 — Add licensed assets

Replace placeholder vehicles with legal/liscensed assets:

- `oak_patrol_sedan` — Bayline Patrol Sedan
- `oak_interceptor` — Bridge Interceptor
- `oak_port_suv` — Port Authority SUV
- `oak_hills_unit` — Hillside Response Unit
- `oak_unmarked` — Investigations Unit
- `oak_marine` — Marine Patrol

## Step 6 — Add framework integration

This pack is framework-neutral. Add QBCore, ESX, ox_lib, inventory, dispatch, voice, and jobs after testing the base commands.
