-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "oakland-ca-rp",
    title = "Oakland CA RP",
    premium_name = "Bayline Oakland RP",
    tagline = "Port power, lake culture, music crews, and Bay Area logistics built for serious community RP.",
    region = "Oakland, California",
    vibe = "port city, lake, hills, music, street art, bay bridges, entrepreneurship",
    seller_angle = "A high-energy Bay Area pack for creators who want port money, music scenes, street crews, and strict anti-griefing enforcement.",
    spawn = {
        x = -1037.4,
        y = -2737.6,
        z = 20.2,
        h = 330.0,
        label = "Bayline Arrival Terminal",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 26,
            note = "sunny Bay days",
        },
        {
            type = "CLOUDS",
            weight = 22,
            note = "mild commute traffic",
        },
        {
            type = "FOGGY",
            weight = 18,
            note = "morning bridge fog",
        },
        {
            type = "SMOG",
            weight = 14,
            note = "industrial port mood",
        },
        {
            type = "OVERCAST",
            weight = 12,
            note = "cooler evening RP",
        },
        {
            type = "RAIN",
            weight = 8,
            note = "special storm patrols",
        },
    },
    districts = {
        {
            name = "Lake District",
            roads = {
                "Merritt Loop",
                "Grand Avenue",
                "Lakeshore Cut",
            },
            money = "food trucks, fitness events, community meetups",
        },
        {
            name = "Jack London Docks",
            roads = {
                "Portline Way",
                "Warehouse Pier",
                "Embarcadero Row",
            },
            money = "port hauling, boat charters, cargo security",
        },
        {
            name = "Telegraph Creative Mile",
            roads = {
                "Telegraph Run",
                "Temescal Strip",
                "Art Alley",
            },
            money = "music venues, mural contracts, clothing drops",
        },
        {
            name = "Hillside Estates",
            roads = {
                "Skyline Ridge",
                "Redwood Bend",
                "Hillside Drive",
            },
            money = "luxury real estate, security patrols, VIP transport",
        },
        {
            name = "International Market",
            roads = {
                "Market Mile",
                "Fruitvale Cut",
                "Eastline Ave",
            },
            money = "markets, mechanic garages, courier loops",
        },
    },
    landmarks = {
        "Lake Merritt Circle",
        "Jack London Port",
        "Bay Bridge View",
        "Telegraph Arts Block",
        "Hillside Overlook",
        "Port Authority Yard",
        "Lux Automaton Bay Lab",
    },
    police_fleet = {
        {
            slot = "oak_patrol_sedan",
            label = "Bayline Patrol Sedan",
            use = "daily patrol",
        },
        {
            slot = "oak_interceptor",
            label = "Bridge Interceptor",
            use = "freeway response",
        },
        {
            slot = "oak_port_suv",
            label = "Port Authority SUV",
            use = "dock security",
        },
        {
            slot = "oak_hills_unit",
            label = "Hillside Response Unit",
            use = "hills patrol",
        },
        {
            slot = "oak_unmarked",
            label = "Investigations Unit",
            use = "detective RP",
        },
        {
            slot = "oak_marine",
            label = "Marine Patrol",
            use = "bay events",
        },
    },
    factions = {
        {
            name = "Lake Circle Crew",
            type = "social faction",
            business = "fitness meets, food events, content nights",
        },
        {
            name = "Portside Union",
            type = "labor crew",
            business = "hauling, storage, shipyard contracts",
        },
        {
            name = "Telegraph Kings",
            type = "music/arts crew",
            business = "venues, merch, promo runs",
        },
        {
            name = "Hillside Brokers",
            type = "luxury faction",
            business = "real estate, security, private events",
        },
    },
    money_loops = {
        "Port hauling ladder",
        "Lake event permits",
        "Music venue tickets",
        "Mechanic shop retainer",
        "VIP hillside transport",
    },
    payouts = {
        boss = 32,
        ops_lead = 22,
        driver = 18,
        security = 15,
        creator = 8,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "bayline-rules",
        "whitelist-apps",
        "port-jobs",
        "music-venue-booking",
        "business-registry",
        "security-reports",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Port Boss",
        "Venue Owner",
        "Crew Lead",
        "Streamer",
        "New Arrival",
    },
    starter_jobs = {
        "Port Trucker",
        "Venue Promoter",
        "Food Truck Owner",
        "Mechanic",
        "Luxury Driver",
        "Bay Patrol",
    },
    security_focus = {
        "port access permissions",
        "venue weapon-free zones",
        "bridge pursuit policy",
        "combat logging review",
    },
    pricing = {
        zip = 149,
        discord = 299,
        install = 699,
        custom = 2200,
        support = 349,
    },
}
