# Security Playbook — Bayline Oakland RP

## City-specific focus

- port access permissions
- venue weapon-free zones
- bridge pursuit policy
- combat logging review

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Lake District — food trucks, fitness events, community meetups
- Jack London Docks — port hauling, boat charters, cargo security
- Telegraph Creative Mile — music venues, mural contracts, clothing drops
- Hillside Estates — luxury real estate, security patrols, VIP transport
- International Market — markets, mechanic garages, courier loops
