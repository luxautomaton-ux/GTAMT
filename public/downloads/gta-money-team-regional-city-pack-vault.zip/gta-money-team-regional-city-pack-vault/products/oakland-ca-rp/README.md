# Bayline Oakland RP (Oakland CA RP)

**Region:** Oakland, California  
**Sales angle:** A high-energy Bay Area pack for creators who want port money, music scenes, street crews, and strict anti-griefing enforcement.  
**Tagline:** Port power, lake culture, music crews, and Bay Area logistics built for serious community RP.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Lake District
Roads: Merritt Loop, Grand Avenue, Lakeshore Cut.  
Money loop: food trucks, fitness events, community meetups

### Jack London Docks
Roads: Portline Way, Warehouse Pier, Embarcadero Row.  
Money loop: port hauling, boat charters, cargo security

### Telegraph Creative Mile
Roads: Telegraph Run, Temescal Strip, Art Alley.  
Money loop: music venues, mural contracts, clothing drops

### Hillside Estates
Roads: Skyline Ridge, Redwood Bend, Hillside Drive.  
Money loop: luxury real estate, security patrols, VIP transport

### International Market
Roads: Market Mile, Fruitvale Cut, Eastline Ave.  
Money loop: markets, mechanic garages, courier loops


## Landmarks

- Lake Merritt Circle
- Jack London Port
- Bay Bridge View
- Telegraph Arts Block
- Hillside Overlook
- Port Authority Yard
- Lux Automaton Bay Lab

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `oak_patrol_sedan` — **Bayline Patrol Sedan**: daily patrol
- `oak_interceptor` — **Bridge Interceptor**: freeway response
- `oak_port_suv` — **Port Authority SUV**: dock security
- `oak_hills_unit` — **Hillside Response Unit**: hills patrol
- `oak_unmarked` — **Investigations Unit**: detective RP
- `oak_marine` — **Marine Patrol**: bay events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Lake Circle Crew** (social faction): fitness meets, food events, content nights
- **Portside Union** (labor crew): hauling, storage, shipyard contracts
- **Telegraph Kings** (music/arts crew): venues, merch, promo runs
- **Hillside Brokers** (luxury faction): real estate, security, private events

## Legal money loops

- Port hauling ladder
- Lake event permits
- Music venue tickets
- Mechanic shop retainer
- VIP hillside transport

## Crew payout split

- **Boss**: 32%
- **Ops Lead**: 22%
- **Driver**: 18%
- **Security**: 15%
- **Creator**: 8%
- **Reserve**: 5%

## Starter jobs

- Port Trucker
- Venue Promoter
- Food Truck Owner
- Mechanic
- Luxury Driver
- Bay Patrol

## Security focus

- port access permissions
- venue weapon-free zones
- bridge pursuit policy
- combat logging review
