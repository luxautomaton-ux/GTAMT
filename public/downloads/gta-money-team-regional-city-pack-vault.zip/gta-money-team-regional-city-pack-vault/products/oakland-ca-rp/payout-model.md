# Payout Model — Bayline Oakland RP

Use this default split for legal money routes.

- **Boss**: 32%
- **Ops Lead**: 22%
- **Driver**: 18%
- **Security**: 15%
- **Creator**: 8%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Boss: $3,200
- Ops Lead: $2,200
- Driver: $1,800
- Security: $1,500
- Creator: $800
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
