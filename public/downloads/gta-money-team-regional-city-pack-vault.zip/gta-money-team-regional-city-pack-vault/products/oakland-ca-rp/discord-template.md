# Discord Template — Bayline Oakland RP

## Channels

- #announcements
- #bayline-rules
- #whitelist-apps
- #port-jobs
- #music-venue-booking
- #business-registry
- #security-reports
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Port Boss
- Venue Owner
- Crew Lead
- Streamer
- New Arrival

## Welcome copy

Welcome to **Bayline Oakland RP** — Port power, lake culture, music crews, and Bay Area logistics built for serious community RP.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
