# Rose City Rain RP (Portland OR RP)

**Region:** Portland, Oregon  
**Sales angle:** A clean PNW city identity for communities that want grounded jobs, rainy patrols, river logistics, and creator-friendly RP.  
**Tagline:** Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Downtown Core
Roads: Burnside Run, Morrison Grid, Yamhill Cut.  
Money loop: courier loops, food cart permits, parking enforcement RP

### Pearl Warehouse
Roads: Pearl Freight Ave, NW Dockline, Glisan Connector.  
Money loop: warehouse leasing, art gallery security, delivery contracts

### Hawthorne Strip
Roads: Hawthorne Mile, Division Lane, Belmont Spur.  
Money loop: coffee shops, indie retail, nightlife events

### St. Johns Bridge Yard
Roads: Bridgeview Road, Cathedral Cut, Portsmouth Loop.  
Money loop: tow jobs, bridge patrol, port trucking

### Mt. Tabor Heights
Roads: Tabor Climb, Reservoir Drive, Pine Ridge.  
Money loop: park ranger RP, bike events, high-end home services


## Landmarks

- Rose City Waterfront
- St. Johns Bridge Lookout
- Pioneer Plaza
- Pearl Warehouse Row
- Mt. Tabor Overlook
- Forest Park Trailhead
- Lux Automaton Rain Lab

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `pdx_patrol_sedan` — **Metro Patrol Sedan**: daily patrol / traffic
- `pdx_patrol_suv` — **Rain Response SUV**: wet-road patrol / supervisor
- `pdx_interceptor` — **Bridge Interceptor**: highway pursuits
- `pdx_unmarked` — **Plainclothes Unit**: detective RP
- `pdx_bike_unit` — **Bike / Park Unit**: downtown and park patrol
- `pdx_rescue` — **River Rescue Truck**: event response

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Roseblock Riders** (street crew): bike couriers, legal races, apparel drops
- **Bridge City Circle** (crew union): tow, repair, bridge logistics
- **Pearl Syndicate** (white-collar RP faction): gallery fronts, warehouse leases, security contracts
- **Rain Market Collective** (community faction): food carts, coffee chain, farmers market events

## Legal money loops

- Rain courier route
- Port freight dispatch
- Coffee shop franchise
- Tow + repair chain
- Event security for indie shows

## Crew payout split

- **Owner**: 30%
- **Route Lead**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Support**: 10%
- **Reserve**: 5%

## Starter jobs

- Coffee Shop Owner
- Tow Operator
- Bike Courier
- Port Trucker
- Park Ranger
- Event Security

## Security focus

- rain pursuit rules
- bridge ambush ban zones
- port robbery cooldowns
- whitelist for high-risk jobs
