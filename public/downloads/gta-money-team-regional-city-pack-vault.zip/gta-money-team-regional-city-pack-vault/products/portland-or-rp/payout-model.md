# Payout Model — Rose City Rain RP

Use this default split for legal money routes.

- **Owner**: 30%
- **Route Lead**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Support**: 10%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Owner: $3,000
- Route Lead: $2,000
- Driver: $2,000
- Security: $1,500
- Support: $1,000
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
