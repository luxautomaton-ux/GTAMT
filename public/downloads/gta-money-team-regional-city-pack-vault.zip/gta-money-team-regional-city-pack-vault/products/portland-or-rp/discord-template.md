# Discord Template — Rose City Rain RP

## Channels

- #announcements
- #rose-city-rules
- #whitelist-apps
- #business-licenses
- #port-dispatch
- #coffee-shop-rp
- #rain-patrol
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Port Director
- Business Owner
- Crew Lead
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Rose City Rain RP** — Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
