# Security Playbook — Rose City Rain RP

## City-specific focus

- rain pursuit rules
- bridge ambush ban zones
- port robbery cooldowns
- whitelist for high-risk jobs

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Downtown Core — courier loops, food cart permits, parking enforcement RP
- Pearl Warehouse — warehouse leasing, art gallery security, delivery contracts
- Hawthorne Strip — coffee shops, indie retail, nightlife events
- St. Johns Bridge Yard — tow jobs, bridge patrol, port trucking
- Mt. Tabor Heights — park ranger RP, bike events, high-end home services
