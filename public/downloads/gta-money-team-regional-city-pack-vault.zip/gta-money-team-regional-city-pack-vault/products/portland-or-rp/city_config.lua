-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "portland-or-rp",
    title = "Portland OR RP",
    premium_name = "Rose City Rain RP",
    tagline = "Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.",
    region = "Portland, Oregon",
    vibe = "rain, bridges, independent creators, downtown riverfront, bikes, coffee, ports, forests",
    seller_angle = "A clean PNW city identity for communities that want grounded jobs, rainy patrols, river logistics, and creator-friendly RP.",
    spawn = {
        x = -268.7,
        y = -956.0,
        z = 31.2,
        h = 205.0,
        label = "Rose City Transit Hub",
    },
    weather = {
        {
            type = "RAIN",
            weight = 28,
            note = "signature rainy patrol atmosphere",
        },
        {
            type = "OVERCAST",
            weight = 24,
            note = "daily downtown mood",
        },
        {
            type = "FOGGY",
            weight = 16,
            note = "bridge and forest immersion",
        },
        {
            type = "CLOUDS",
            weight = 16,
            note = "soft daytime cruising",
        },
        {
            type = "CLEAR",
            weight = 10,
            note = "rare clean event weather",
        },
        {
            type = "THUNDER",
            weight = 6,
            note = "special storm event nights",
        },
    },
    districts = {
        {
            name = "Downtown Core",
            roads = {
                "Burnside Run",
                "Morrison Grid",
                "Yamhill Cut",
            },
            money = "courier loops, food cart permits, parking enforcement RP",
        },
        {
            name = "Pearl Warehouse",
            roads = {
                "Pearl Freight Ave",
                "NW Dockline",
                "Glisan Connector",
            },
            money = "warehouse leasing, art gallery security, delivery contracts",
        },
        {
            name = "Hawthorne Strip",
            roads = {
                "Hawthorne Mile",
                "Division Lane",
                "Belmont Spur",
            },
            money = "coffee shops, indie retail, nightlife events",
        },
        {
            name = "St. Johns Bridge Yard",
            roads = {
                "Bridgeview Road",
                "Cathedral Cut",
                "Portsmouth Loop",
            },
            money = "tow jobs, bridge patrol, port trucking",
        },
        {
            name = "Mt. Tabor Heights",
            roads = {
                "Tabor Climb",
                "Reservoir Drive",
                "Pine Ridge",
            },
            money = "park ranger RP, bike events, high-end home services",
        },
    },
    landmarks = {
        "Rose City Waterfront",
        "St. Johns Bridge Lookout",
        "Pioneer Plaza",
        "Pearl Warehouse Row",
        "Mt. Tabor Overlook",
        "Forest Park Trailhead",
        "Lux Automaton Rain Lab",
    },
    police_fleet = {
        {
            slot = "pdx_patrol_sedan",
            label = "Metro Patrol Sedan",
            use = "daily patrol / traffic",
        },
        {
            slot = "pdx_patrol_suv",
            label = "Rain Response SUV",
            use = "wet-road patrol / supervisor",
        },
        {
            slot = "pdx_interceptor",
            label = "Bridge Interceptor",
            use = "highway pursuits",
        },
        {
            slot = "pdx_unmarked",
            label = "Plainclothes Unit",
            use = "detective RP",
        },
        {
            slot = "pdx_bike_unit",
            label = "Bike / Park Unit",
            use = "downtown and park patrol",
        },
        {
            slot = "pdx_rescue",
            label = "River Rescue Truck",
            use = "event response",
        },
    },
    factions = {
        {
            name = "Roseblock Riders",
            type = "street crew",
            business = "bike couriers, legal races, apparel drops",
        },
        {
            name = "Bridge City Circle",
            type = "crew union",
            business = "tow, repair, bridge logistics",
        },
        {
            name = "Pearl Syndicate",
            type = "white-collar RP faction",
            business = "gallery fronts, warehouse leases, security contracts",
        },
        {
            name = "Rain Market Collective",
            type = "community faction",
            business = "food carts, coffee chain, farmers market events",
        },
    },
    money_loops = {
        "Rain courier route",
        "Port freight dispatch",
        "Coffee shop franchise",
        "Tow + repair chain",
        "Event security for indie shows",
    },
    payouts = {
        owner = 30,
        route_lead = 20,
        driver = 20,
        security = 15,
        support = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "rose-city-rules",
        "whitelist-apps",
        "business-licenses",
        "port-dispatch",
        "coffee-shop-rp",
        "rain-patrol",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Port Director",
        "Business Owner",
        "Crew Lead",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Coffee Shop Owner",
        "Tow Operator",
        "Bike Courier",
        "Port Trucker",
        "Park Ranger",
        "Event Security",
    },
    security_focus = {
        "rain pursuit rules",
        "bridge ambush ban zones",
        "port robbery cooldowns",
        "whitelist for high-risk jobs",
    },
    pricing = {
        zip = 129,
        discord = 249,
        install = 599,
        custom = 1800,
        support = 299,
    },
}
