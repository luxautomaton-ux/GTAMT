# Sales Page Copy — Rose City Rain RP

## Headline

Launch **Rose City Rain RP** without building your RP city from zero.

## Subheadline

Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.

## What buyers get

- City identity and theme based on Portland, Oregon energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$129**
- Template + Discord Setup: **$249**
- Installed Server Identity: **$599**
- Full Custom Build: **$1800+**
- Monthly Support: **$299/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
