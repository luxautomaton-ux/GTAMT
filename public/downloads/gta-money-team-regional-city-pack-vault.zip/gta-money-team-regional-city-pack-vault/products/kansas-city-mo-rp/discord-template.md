# Discord Template — KC Crossroads RP

## Channels

- #announcements
- #kc-rules
- #whitelist-apps
- #bbq-business
- #jazz-bookings
- #rail-dispatch
- #sports-events
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Venue Owner
- BBQ Owner
- Rail Boss
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **KC Crossroads RP** — BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
