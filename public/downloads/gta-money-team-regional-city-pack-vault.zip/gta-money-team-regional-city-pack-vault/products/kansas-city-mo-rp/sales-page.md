# Sales Page Copy — KC Crossroads RP

## Headline

Launch **KC Crossroads RP** without building your RP city from zero.

## Subheadline

BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.

## What buyers get

- City identity and theme based on Kansas City, Missouri / Kansas metro energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$129**
- Template + Discord Setup: **$249**
- Installed Server Identity: **$599**
- Full Custom Build: **$1800+**
- Monthly Support: **$299/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
