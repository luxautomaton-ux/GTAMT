# Payout Model — KC Crossroads RP

Use this default split for legal money routes.

- **Manager**: 30%
- **Promoter**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Vendor**: 10%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Manager: $3,000
- Promoter: $2,000
- Driver: $2,000
- Security: $1,500
- Vendor: $1,000
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
