# KC Crossroads RP (Kansas City RP)

**Region:** Kansas City, Missouri / Kansas metro  
**Sales angle:** A community-first pack with BBQ businesses, jazz clubs, rail logistics, sports events, and high-retention Discord systems.  
**Tagline:** BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Power District
Roads: Power Loop, Main Street, Arena Way.  
Money loop: concert security, sports nights, nightclub permits

### Crossroads Arts
Roads: Crossroads Lane, Gallery Row, Freight House Road.  
Money loop: art shows, print shops, creative content

### River Market
Roads: Market Row, Riverfront Road, Walnut Cut.  
Money loop: farmers market, food trucks, vendor permits

### 18th & Vine
Roads: Jazz Mile, Vine Street, Museum Loop.  
Money loop: music venues, history tours, promoter RP

### Rail Yard South
Roads: Stockyard Spur, Rail Road, Industrial Ave.  
Money loop: rail freight, tow, warehouse logistics


## Landmarks

- Jazz District
- BBQ Row
- River Market
- Crossroads Gallery
- Sports Complex
- Rail Yard South
- Lux Automaton KC Studio

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `kc_patrol_sedan` — **Metro Patrol Sedan**: city patrol
- `kc_interceptor` — **Interstate Interceptor**: pursuits
- `kc_event_suv` — **Event Command SUV**: sports/concerts
- `kc_unmarked` — **Detective Unit**: investigations
- `kc_k9_placeholder` — **K9 Placeholder**: replace with licensed K9 resource
- `kc_rail_unit` — **Rail Yard Patrol**: industrial district

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Jazz District Crew** (music faction): clubs, shows, VIP events
- **BBQ Kings** (business faction): restaurants, catering, food trucks
- **River Market Circle** (vendor faction): market stalls, produce delivery
- **Crossroads Syndicate** (creative faction): galleries, printing, nightlife

## Legal money loops

- BBQ franchise ladder
- Jazz venue ticketing
- Rail freight dispatch
- Sports event security
- Farmers market permits

## Crew payout split

- **Manager**: 30%
- **Promoter**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Vendor**: 10%
- **Reserve**: 5%

## Starter jobs

- BBQ Vendor
- Rail Trucker
- Jazz Promoter
- Event Security
- Tow Operator
- Market Vendor

## Security focus

- event crowd rules
- rail-yard whitelist
- vendor fraud checks
- anti-harassment music venue policy
