# Security Playbook — KC Crossroads RP

## City-specific focus

- event crowd rules
- rail-yard whitelist
- vendor fraud checks
- anti-harassment music venue policy

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Power District — concert security, sports nights, nightclub permits
- Crossroads Arts — art shows, print shops, creative content
- River Market — farmers market, food trucks, vendor permits
- 18th & Vine — music venues, history tours, promoter RP
- Rail Yard South — rail freight, tow, warehouse logistics
