-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "kansas-city-mo-rp",
    title = "Kansas City RP",
    premium_name = "KC Crossroads RP",
    tagline = "BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.",
    region = "Kansas City, Missouri / Kansas metro",
    vibe = "jazz, BBQ, rail yards, fountains, sports, crossroads, river market",
    seller_angle = "A community-first pack with BBQ businesses, jazz clubs, rail logistics, sports events, and high-retention Discord systems.",
    spawn = {
        x = -356.9,
        y = -134.8,
        z = 39.0,
        h = 250.0,
        label = "Crossroads Garage",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 24,
            note = "normal city routes",
        },
        {
            type = "CLOUDS",
            weight = 20,
            note = "Midwest days",
        },
        {
            type = "OVERCAST",
            weight = 18,
            note = "rail-yard atmosphere",
        },
        {
            type = "RAIN",
            weight = 14,
            note = "stormy patrols",
        },
        {
            type = "FOGGY",
            weight = 10,
            note = "river market mornings",
        },
        {
            type = "THUNDER",
            weight = 8,
            note = "special weather events",
        },
        {
            type = "XMAS",
            weight = 6,
            note = "winter events",
        },
    },
    districts = {
        {
            name = "Power District",
            roads = {
                "Power Loop",
                "Main Street",
                "Arena Way",
            },
            money = "concert security, sports nights, nightclub permits",
        },
        {
            name = "Crossroads Arts",
            roads = {
                "Crossroads Lane",
                "Gallery Row",
                "Freight House Road",
            },
            money = "art shows, print shops, creative content",
        },
        {
            name = "River Market",
            roads = {
                "Market Row",
                "Riverfront Road",
                "Walnut Cut",
            },
            money = "farmers market, food trucks, vendor permits",
        },
        {
            name = "18th & Vine",
            roads = {
                "Jazz Mile",
                "Vine Street",
                "Museum Loop",
            },
            money = "music venues, history tours, promoter RP",
        },
        {
            name = "Rail Yard South",
            roads = {
                "Stockyard Spur",
                "Rail Road",
                "Industrial Ave",
            },
            money = "rail freight, tow, warehouse logistics",
        },
    },
    landmarks = {
        "Jazz District",
        "BBQ Row",
        "River Market",
        "Crossroads Gallery",
        "Sports Complex",
        "Rail Yard South",
        "Lux Automaton KC Studio",
    },
    police_fleet = {
        {
            slot = "kc_patrol_sedan",
            label = "Metro Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "kc_interceptor",
            label = "Interstate Interceptor",
            use = "pursuits",
        },
        {
            slot = "kc_event_suv",
            label = "Event Command SUV",
            use = "sports/concerts",
        },
        {
            slot = "kc_unmarked",
            label = "Detective Unit",
            use = "investigations",
        },
        {
            slot = "kc_k9_placeholder",
            label = "K9 Placeholder",
            use = "replace with licensed K9 resource",
        },
        {
            slot = "kc_rail_unit",
            label = "Rail Yard Patrol",
            use = "industrial district",
        },
    },
    factions = {
        {
            name = "Jazz District Crew",
            type = "music faction",
            business = "clubs, shows, VIP events",
        },
        {
            name = "BBQ Kings",
            type = "business faction",
            business = "restaurants, catering, food trucks",
        },
        {
            name = "River Market Circle",
            type = "vendor faction",
            business = "market stalls, produce delivery",
        },
        {
            name = "Crossroads Syndicate",
            type = "creative faction",
            business = "galleries, printing, nightlife",
        },
    },
    money_loops = {
        "BBQ franchise ladder",
        "Jazz venue ticketing",
        "Rail freight dispatch",
        "Sports event security",
        "Farmers market permits",
    },
    payouts = {
        manager = 30,
        promoter = 20,
        driver = 20,
        security = 15,
        vendor = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "kc-rules",
        "whitelist-apps",
        "bbq-business",
        "jazz-bookings",
        "rail-dispatch",
        "sports-events",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Venue Owner",
        "BBQ Owner",
        "Rail Boss",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "BBQ Vendor",
        "Rail Trucker",
        "Jazz Promoter",
        "Event Security",
        "Tow Operator",
        "Market Vendor",
    },
    security_focus = {
        "event crowd rules",
        "rail-yard whitelist",
        "vendor fraud checks",
        "anti-harassment music venue policy",
    },
    pricing = {
        zip = 129,
        discord = 249,
        install = 599,
        custom = 1800,
        support = 299,
    },
}
