# Discord Template — Bluff City RP

## Channels

- #announcements
- #bluff-city-rules
- #whitelist-apps
- #music-bookings
- #river-jobs
- #airport-cargo
- #creator-clips
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Venue Owner
- Artist
- Logistics Boss
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Bluff City RP** — Music, river freight, street fashion, logistics, and creator economy in a Southern nightlife city.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
