# Security Playbook — Bluff City RP

## City-specific focus

- venue safety rules
- video shoot permits
- cargo cooldowns
- anti-stream-sniping moderation

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Beale Nightlife — venue cover, artist bookings, VIP security
- Riverfront Bluff — river tours, freight, food vendors
- South Main Arts — photo shoots, art shows, boutique shops
- Airport Cargo — air freight, courier routes, customs RP
- Midtown Motors — mechanics, dealerships, legal meets
