-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "memphis-tn-rp",
    title = "Memphis RP",
    premium_name = "Bluff City RP",
    tagline = "Music, river freight, street fashion, logistics, and creator economy in a Southern nightlife city.",
    region = "Memphis, Tennessee",
    vibe = "Beale Street, riverfront, blues, warehouses, BBQ, airport logistics, southern nightlife",
    seller_angle = "A strong streamer/creator pack with music-video RP, river hauling, airport logistics, nightlife security, and crew payout models.",
    spawn = {
        x = 927.9,
        y = 46.1,
        z = 80.9,
        h = 60.0,
        label = "Bluff City Welcome Center",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 24,
            note = "nightlife cruising",
        },
        {
            type = "EXTRASUNNY",
            weight = 16,
            note = "hot southern days",
        },
        {
            type = "CLOUDS",
            weight = 18,
            note = "normal RP",
        },
        {
            type = "OVERCAST",
            weight = 14,
            note = "riverfront mood",
        },
        {
            type = "RAIN",
            weight = 14,
            note = "stormy nights",
        },
        {
            type = "FOGGY",
            weight = 8,
            note = "river mornings",
        },
        {
            type = "THUNDER",
            weight = 6,
            note = "special events",
        },
    },
    districts = {
        {
            name = "Beale Nightlife",
            roads = {
                "Beale Run",
                "Music Row",
                "Club Lane",
            },
            money = "venue cover, artist bookings, VIP security",
        },
        {
            name = "Riverfront Bluff",
            roads = {
                "Riverwalk Road",
                "Bluff Drive",
                "Dockside Ave",
            },
            money = "river tours, freight, food vendors",
        },
        {
            name = "South Main Arts",
            roads = {
                "South Main",
                "Gallery Cut",
                "Rail Spur",
            },
            money = "photo shoots, art shows, boutique shops",
        },
        {
            name = "Airport Cargo",
            roads = {
                "Cargo Way",
                "Runway Road",
                "Logistics Lane",
            },
            money = "air freight, courier routes, customs RP",
        },
        {
            name = "Midtown Motors",
            roads = {
                "Union Ave",
                "Auto Row",
                "Cooper Strip",
            },
            money = "mechanics, dealerships, legal meets",
        },
    },
    landmarks = {
        "Beale Street Stage",
        "Mississippi Riverfront",
        "South Main Arts Block",
        "Airport Cargo Yard",
        "BBQ Row",
        "Bluff Overlook",
        "Lux Automaton Music Lab",
    },
    police_fleet = {
        {
            slot = "mem_patrol_sedan",
            label = "Bluff Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "mem_interceptor",
            label = "Riverfront Interceptor",
            use = "pursuits",
        },
        {
            slot = "mem_airport_suv",
            label = "Airport Security SUV",
            use = "cargo district",
        },
        {
            slot = "mem_unmarked",
            label = "Detective Unit",
            use = "investigations",
        },
        {
            slot = "mem_event_van",
            label = "Event Command Van",
            use = "nightlife response",
        },
        {
            slot = "mem_marine",
            label = "River Patrol",
            use = "river events",
        },
    },
    factions = {
        {
            name = "Beale Street Crew",
            type = "music faction",
            business = "show bookings, merch, VIP club nights",
        },
        {
            name = "River Kings",
            type = "logistics faction",
            business = "dock freight, river charters",
        },
        {
            name = "South Main Circle",
            type = "creator faction",
            business = "video shoots, boutiques, art nights",
        },
        {
            name = "Bluff City Riders",
            type = "auto faction",
            business = "mechanics, legal meets, towing",
        },
    },
    money_loops = {
        "Music venue tier ladder",
        "River freight dispatch",
        "Airport cargo route",
        "BBQ food truck chain",
        "Creator video package",
    },
    payouts = {
        executive = 30,
        artist = 18,
        driver = 18,
        security = 18,
        promoter = 11,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "bluff-city-rules",
        "whitelist-apps",
        "music-bookings",
        "river-jobs",
        "airport-cargo",
        "creator-clips",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Venue Owner",
        "Artist",
        "Logistics Boss",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Artist Manager",
        "Venue Security",
        "River Trucker",
        "Airport Courier",
        "Mechanic",
        "BBQ Vendor",
    },
    security_focus = {
        "venue safety rules",
        "video shoot permits",
        "cargo cooldowns",
        "anti-stream-sniping moderation",
    },
    pricing = {
        zip = 139,
        discord = 279,
        install = 649,
        custom = 2000,
        support = 299,
    },
}
