# Bluff City RP (Memphis RP)

**Region:** Memphis, Tennessee  
**Sales angle:** A strong streamer/creator pack with music-video RP, river hauling, airport logistics, nightlife security, and crew payout models.  
**Tagline:** Music, river freight, street fashion, logistics, and creator economy in a Southern nightlife city.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Beale Nightlife
Roads: Beale Run, Music Row, Club Lane.  
Money loop: venue cover, artist bookings, VIP security

### Riverfront Bluff
Roads: Riverwalk Road, Bluff Drive, Dockside Ave.  
Money loop: river tours, freight, food vendors

### South Main Arts
Roads: South Main, Gallery Cut, Rail Spur.  
Money loop: photo shoots, art shows, boutique shops

### Airport Cargo
Roads: Cargo Way, Runway Road, Logistics Lane.  
Money loop: air freight, courier routes, customs RP

### Midtown Motors
Roads: Union Ave, Auto Row, Cooper Strip.  
Money loop: mechanics, dealerships, legal meets


## Landmarks

- Beale Street Stage
- Mississippi Riverfront
- South Main Arts Block
- Airport Cargo Yard
- BBQ Row
- Bluff Overlook
- Lux Automaton Music Lab

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `mem_patrol_sedan` — **Bluff Patrol Sedan**: city patrol
- `mem_interceptor` — **Riverfront Interceptor**: pursuits
- `mem_airport_suv` — **Airport Security SUV**: cargo district
- `mem_unmarked` — **Detective Unit**: investigations
- `mem_event_van` — **Event Command Van**: nightlife response
- `mem_marine` — **River Patrol**: river events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Beale Street Crew** (music faction): show bookings, merch, VIP club nights
- **River Kings** (logistics faction): dock freight, river charters
- **South Main Circle** (creator faction): video shoots, boutiques, art nights
- **Bluff City Riders** (auto faction): mechanics, legal meets, towing

## Legal money loops

- Music venue tier ladder
- River freight dispatch
- Airport cargo route
- BBQ food truck chain
- Creator video package

## Crew payout split

- **Executive**: 30%
- **Artist**: 18%
- **Driver**: 18%
- **Security**: 18%
- **Promoter**: 11%
- **Reserve**: 5%

## Starter jobs

- Artist Manager
- Venue Security
- River Trucker
- Airport Courier
- Mechanic
- BBQ Vendor

## Security focus

- venue safety rules
- video shoot permits
- cargo cooldowns
- anti-stream-sniping moderation
