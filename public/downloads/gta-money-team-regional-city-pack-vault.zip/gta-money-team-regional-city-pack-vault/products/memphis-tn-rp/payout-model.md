# Payout Model — Bluff City RP

Use this default split for legal money routes.

- **Executive**: 30%
- **Artist**: 18%
- **Driver**: 18%
- **Security**: 18%
- **Promoter**: 11%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Executive: $3,000
- Artist: $1,800
- Driver: $1,800
- Security: $1,800
- Promoter: $1,100
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
