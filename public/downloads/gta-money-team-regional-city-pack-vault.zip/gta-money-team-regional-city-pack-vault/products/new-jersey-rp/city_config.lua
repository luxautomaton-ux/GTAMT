-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "new-jersey-rp",
    title = "New Jersey RP",
    premium_name = "Garden State RP",
    tagline = "Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.",
    region = "New Jersey statewide / metro shore",
    vibe = "turnpike, ports, shore towns, boardwalks, diners, suburbs, Meadowlands, Atlantic-style resort energy",
    seller_angle = "A statewide pack for communities that want multiple regions in one: shore resorts, industrial ports, suburbs, highways, and state police operations.",
    spawn = {
        x = -1603.4,
        y = -1045.0,
        z = 13.0,
        h = 225.0,
        label = "Garden State Welcome Plaza",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 20,
            note = "shore days",
        },
        {
            type = "EXTRASUNNY",
            weight = 14,
            note = "boardwalk events",
        },
        {
            type = "CLOUDS",
            weight = 18,
            note = "suburban routes",
        },
        {
            type = "OVERCAST",
            weight = 16,
            note = "turnpike mood",
        },
        {
            type = "RAIN",
            weight = 14,
            note = "stormy coast",
        },
        {
            type = "FOGGY",
            weight = 10,
            note = "port mornings",
        },
        {
            type = "XMAS",
            weight = 8,
            note = "winter north Jersey events",
        },
    },
    districts = {
        {
            name = "Turnpike Corridor",
            roads = {
                "Turnpike Main",
                "Parkway Run",
                "Service Plaza Loop",
            },
            money = "towing, toll security, trucking",
        },
        {
            name = "Port Newark Yard",
            roads = {
                "Container Row",
                "Doremus Spur",
                "Dockside Road",
            },
            money = "container hauling, port security, customs RP",
        },
        {
            name = "Jersey Shore Boardwalk",
            roads = {
                "Boardwalk Ave",
                "Oceanfront Road",
                "Pier Lane",
            },
            money = "arcades, food stands, hotel work",
        },
        {
            name = "Meadowlands District",
            roads = {
                "Stadium Way",
                "Meadowlands Loop",
                "Arena Road",
            },
            money = "sports events, parking, security",
        },
        {
            name = "Suburban Diner Belt",
            roads = {
                "Route 1",
                "Diner Row",
                "Garden Avenue",
            },
            money = "diners, delivery, small businesses",
        },
    },
    landmarks = {
        "Garden State Parkway Plaza",
        "Port Newark Yard",
        "Shore Boardwalk",
        "Meadowlands Stadium",
        "Hoboken Waterfront",
        "Pine Barrens Outpost",
        "Lux Automaton Turnpike Office",
    },
    police_fleet = {
        {
            slot = "nj_state_trooper",
            label = "State Trooper Sedan",
            use = "highway patrol",
        },
        {
            slot = "nj_turnpike_interceptor",
            label = "Turnpike Interceptor",
            use = "pursuits",
        },
        {
            slot = "nj_port_suv",
            label = "Port Authority SUV",
            use = "industrial district",
        },
        {
            slot = "nj_shore_patrol",
            label = "Shore Patrol SUV",
            use = "boardwalk events",
        },
        {
            slot = "nj_unmarked",
            label = "Investigations Unit",
            use = "cases",
        },
        {
            slot = "nj_marine",
            label = "Harbor Patrol",
            use = "shore/port events",
        },
    },
    factions = {
        {
            name = "Turnpike Kings",
            type = "auto/logistics faction",
            business = "tow, trucking, service plaza work",
        },
        {
            name = "Shoreline Crew",
            type = "tourism faction",
            business = "boardwalks, hotels, seasonal events",
        },
        {
            name = "Meadowlands Syndicate",
            type = "event faction",
            business = "stadium security, parking, merch",
        },
        {
            name = "Brick City Brokers",
            type = "business faction",
            business = "warehouses, permits, diners",
        },
    },
    money_loops = {
        "Turnpike towing ladder",
        "Port container dispatch",
        "Boardwalk vendor permits",
        "Stadium parking events",
        "Diner franchise route",
    },
    payouts = {
        operator = 30,
        dispatcher = 20,
        driver = 18,
        security = 17,
        vendor = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "garden-state-rules",
        "whitelist-apps",
        "turnpike-dispatch",
        "shore-business",
        "port-jobs",
        "stadium-events",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "State Director",
        "Trooper Chief",
        "Port Boss",
        "Shore Owner",
        "Event Promoter",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "State Trooper",
        "Tow Operator",
        "Port Trucker",
        "Boardwalk Vendor",
        "Diner Worker",
        "Event Security",
    },
    security_focus = {
        "port access control",
        "shore event griefing bans",
        "turnpike pursuit rules",
        "seasonal economy caps",
    },
    pricing = {
        zip = 149,
        discord = 299,
        install = 699,
        custom = 2200,
        support = 349,
    },
}
