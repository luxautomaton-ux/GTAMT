# Security Playbook — Garden State RP

## City-specific focus

- port access control
- shore event griefing bans
- turnpike pursuit rules
- seasonal economy caps

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Turnpike Corridor — towing, toll security, trucking
- Port Newark Yard — container hauling, port security, customs RP
- Jersey Shore Boardwalk — arcades, food stands, hotel work
- Meadowlands District — sports events, parking, security
- Suburban Diner Belt — diners, delivery, small businesses
