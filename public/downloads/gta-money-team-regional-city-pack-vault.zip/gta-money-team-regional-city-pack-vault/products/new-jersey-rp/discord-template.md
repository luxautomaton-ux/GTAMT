# Discord Template — Garden State RP

## Channels

- #announcements
- #garden-state-rules
- #whitelist-apps
- #turnpike-dispatch
- #shore-business
- #port-jobs
- #stadium-events
- #support-tickets

## Roles

- Founder
- State Director
- Trooper Chief
- Port Boss
- Shore Owner
- Event Promoter
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Garden State RP** — Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
