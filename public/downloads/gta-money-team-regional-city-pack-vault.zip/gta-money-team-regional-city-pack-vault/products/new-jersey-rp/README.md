# Garden State RP (New Jersey RP)

**Region:** New Jersey statewide / metro shore  
**Sales angle:** A statewide pack for communities that want multiple regions in one: shore resorts, industrial ports, suburbs, highways, and state police operations.  
**Tagline:** Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Turnpike Corridor
Roads: Turnpike Main, Parkway Run, Service Plaza Loop.  
Money loop: towing, toll security, trucking

### Port Newark Yard
Roads: Container Row, Doremus Spur, Dockside Road.  
Money loop: container hauling, port security, customs RP

### Jersey Shore Boardwalk
Roads: Boardwalk Ave, Oceanfront Road, Pier Lane.  
Money loop: arcades, food stands, hotel work

### Meadowlands District
Roads: Stadium Way, Meadowlands Loop, Arena Road.  
Money loop: sports events, parking, security

### Suburban Diner Belt
Roads: Route 1, Diner Row, Garden Avenue.  
Money loop: diners, delivery, small businesses


## Landmarks

- Garden State Parkway Plaza
- Port Newark Yard
- Shore Boardwalk
- Meadowlands Stadium
- Hoboken Waterfront
- Pine Barrens Outpost
- Lux Automaton Turnpike Office

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `nj_state_trooper` — **State Trooper Sedan**: highway patrol
- `nj_turnpike_interceptor` — **Turnpike Interceptor**: pursuits
- `nj_port_suv` — **Port Authority SUV**: industrial district
- `nj_shore_patrol` — **Shore Patrol SUV**: boardwalk events
- `nj_unmarked` — **Investigations Unit**: cases
- `nj_marine` — **Harbor Patrol**: shore/port events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Turnpike Kings** (auto/logistics faction): tow, trucking, service plaza work
- **Shoreline Crew** (tourism faction): boardwalks, hotels, seasonal events
- **Meadowlands Syndicate** (event faction): stadium security, parking, merch
- **Brick City Brokers** (business faction): warehouses, permits, diners

## Legal money loops

- Turnpike towing ladder
- Port container dispatch
- Boardwalk vendor permits
- Stadium parking events
- Diner franchise route

## Crew payout split

- **Operator**: 30%
- **Dispatcher**: 20%
- **Driver**: 18%
- **Security**: 17%
- **Vendor**: 10%
- **Reserve**: 5%

## Starter jobs

- State Trooper
- Tow Operator
- Port Trucker
- Boardwalk Vendor
- Diner Worker
- Event Security

## Security focus

- port access control
- shore event griefing bans
- turnpike pursuit rules
- seasonal economy caps
