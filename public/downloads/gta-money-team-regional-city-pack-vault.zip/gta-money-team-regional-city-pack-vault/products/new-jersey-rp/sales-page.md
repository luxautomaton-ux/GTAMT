# Sales Page Copy — Garden State RP

## Headline

Launch **Garden State RP** without building your RP city from zero.

## Subheadline

Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.

## What buyers get

- City identity and theme based on New Jersey statewide / metro shore energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$149**
- Template + Discord Setup: **$299**
- Installed Server Identity: **$699**
- Full Custom Build: **$2200+**
- Monthly Support: **$349/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
