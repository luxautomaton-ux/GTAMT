# Payout Model — Wasatch State RP

Use this default split for legal money routes.

- **Director**: 28%
- **Route Lead**: 22%
- **Driver**: 18%
- **Ranger**: 14%
- **Security**: 12%
- **Reserve**: 6%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Director: $2,800
- Route Lead: $2,200
- Driver: $1,800
- Ranger: $1,400
- Security: $1,200
- Reserve: $600

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
