# Setup Guide — Wasatch State RP

## Step 1 — Install shared resource

Copy:

`resources/[gmt]/gmt_city_engine`

to your FiveM resources folder.

## Step 2 — Activate this city

Copy:

`products/utah-wasatch-rp/city_config.lua`

to:

`resources/[gmt]/gmt_city_engine/config/active_city.lua`

## Step 3 — Update server.cfg

Add the contents of `server-snippet.cfg`, then restart.

## Step 4 — Test in game

Run:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/moneyloops`
- `/securitycheck`

## Step 5 — Add licensed assets

Replace placeholder vehicles with legal/liscensed assets:

- `ut_state_trooper` — State Trooper Sedan
- `ut_snow_suv` — Snow Patrol SUV
- `ut_ranger_truck` — Canyon Ranger Truck
- `ut_unmarked` — Investigations Unit
- `ut_rescue` — Search & Rescue
- `ut_air_one` — Air Rescue

## Step 6 — Add framework integration

This pack is framework-neutral. Add QBCore, ESX, ox_lib, inventory, dispatch, voice, and jobs after testing the base commands.
