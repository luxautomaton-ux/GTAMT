# Wasatch State RP (Utah RP)

**Region:** Utah / Wasatch corridor  
**Sales angle:** A rare mountain-state pack with seasonal weather, highway patrol, outdoor tourism, clean money loops, and wide-open road RP.  
**Tagline:** Mountain-state RP with snow patrol, ski towns, salt flats, desert routes, and clean economy ladders.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Salt Metro
Roads: State Street, Temple Grid, Downtown Loop.  
Money loop: tech jobs, finance offices, city contracts

### Wasatch Canyon
Roads: Canyon Pass, Ski Lift Road, Pine Bowl.  
Money loop: ski patrol, lodge ownership, rescue missions

### Salt Flats
Roads: Flatline Highway, Bonneville Spur, Mirage Road.  
Money loop: legal speed events, vehicle testing, film shoots

### Red Rock South
Roads: Moab Run, Canyon Rim, Desert Loop.  
Money loop: tour guides, off-road rentals, park ranger RP

### Tech Corridor
Roads: Silicon Slopes, Provo Connector, Lehi Park.  
Money loop: startup contracts, delivery apps, cybersecurity RP


## Landmarks

- Wasatch Overlook
- Salt Flats Speedway
- Red Rock Rim
- Downtown Temple Grid
- Ski Village
- Tech Corridor Tower
- Lux Automaton Mountain Ops

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `ut_state_trooper` — **State Trooper Sedan**: highway patrol
- `ut_snow_suv` — **Snow Patrol SUV**: mountain response
- `ut_ranger_truck` — **Canyon Ranger Truck**: parks and desert
- `ut_unmarked` — **Investigations Unit**: state cases
- `ut_rescue` — **Search & Rescue**: blizzard events
- `ut_air_one` — **Air Rescue**: special events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Wasatch Riders** (mountain crew): tourism, lodge security, legal road events
- **Salt Flats Syndicate** (auto faction): speed trials, rentals, mechanic testing
- **Canyon Crew** (outdoor faction): guide services, ranger contracts
- **Silicon Brokers** (tech faction): software contracts, security audits, app delivery

## Legal money loops

- Ski lodge operations
- Salt Flats event tickets
- Canyon tour permits
- Tech contract ladder
- State highway towing

## Crew payout split

- **Director**: 28%
- **Route Lead**: 22%
- **Driver**: 18%
- **Ranger**: 14%
- **Security**: 12%
- **Reserve**: 6%

## Starter jobs

- State Trooper
- Ski Patrol
- Off-road Tour Guide
- Tech Courier
- Tow Driver
- Lodge Worker

## Security focus

- weather event whitelist
- off-road boundaries
- speed event permits
- state police hierarchy controls
