# Security Playbook — Wasatch State RP

## City-specific focus

- weather event whitelist
- off-road boundaries
- speed event permits
- state police hierarchy controls

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Salt Metro — tech jobs, finance offices, city contracts
- Wasatch Canyon — ski patrol, lodge ownership, rescue missions
- Salt Flats — legal speed events, vehicle testing, film shoots
- Red Rock South — tour guides, off-road rentals, park ranger RP
- Tech Corridor — startup contracts, delivery apps, cybersecurity RP
