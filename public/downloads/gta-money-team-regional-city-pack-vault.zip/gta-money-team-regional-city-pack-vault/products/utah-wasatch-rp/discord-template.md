# Discord Template — Wasatch State RP

## Channels

- #announcements
- #wasatch-rules
- #whitelist-apps
- #state-patrol
- #ski-lodge
- #salt-flats-events
- #tech-corridor
- #support-tickets

## Roles

- Founder
- State Director
- Trooper Chief
- Ranger Lead
- Lodge Owner
- Tech CEO
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Wasatch State RP** — Mountain-state RP with snow patrol, ski towns, salt flats, desert routes, and clean economy ladders.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
