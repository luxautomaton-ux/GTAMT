-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "utah-wasatch-rp",
    title = "Utah RP",
    premium_name = "Wasatch State RP",
    tagline = "Mountain-state RP with snow patrol, ski towns, salt flats, desert routes, and clean economy ladders.",
    region = "Utah / Wasatch corridor",
    vibe = "mountains, snow, highways, tech suburbs, desert, national-park style tours, state troopers",
    seller_angle = "A rare mountain-state pack with seasonal weather, highway patrol, outdoor tourism, clean money loops, and wide-open road RP.",
    spawn = {
        x = 1853.2,
        y = 3689.5,
        z = 34.2,
        h = 210.0,
        label = "Wasatch County Station",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 22,
            note = "high desert clarity",
        },
        {
            type = "EXTRASUNNY",
            weight = 18,
            note = "salt flat events",
        },
        {
            type = "CLOUDS",
            weight = 14,
            note = "mountain pass travel",
        },
        {
            type = "FOGGY",
            weight = 10,
            note = "canyon mornings",
        },
        {
            type = "SNOW",
            weight = 16,
            note = "winter patrol",
        },
        {
            type = "SNOWLIGHT",
            weight = 12,
            note = "ski-town routes",
        },
        {
            type = "BLIZZARD",
            weight = 8,
            note = "special emergency events",
        },
    },
    districts = {
        {
            name = "Salt Metro",
            roads = {
                "State Street",
                "Temple Grid",
                "Downtown Loop",
            },
            money = "tech jobs, finance offices, city contracts",
        },
        {
            name = "Wasatch Canyon",
            roads = {
                "Canyon Pass",
                "Ski Lift Road",
                "Pine Bowl",
            },
            money = "ski patrol, lodge ownership, rescue missions",
        },
        {
            name = "Salt Flats",
            roads = {
                "Flatline Highway",
                "Bonneville Spur",
                "Mirage Road",
            },
            money = "legal speed events, vehicle testing, film shoots",
        },
        {
            name = "Red Rock South",
            roads = {
                "Moab Run",
                "Canyon Rim",
                "Desert Loop",
            },
            money = "tour guides, off-road rentals, park ranger RP",
        },
        {
            name = "Tech Corridor",
            roads = {
                "Silicon Slopes",
                "Provo Connector",
                "Lehi Park",
            },
            money = "startup contracts, delivery apps, cybersecurity RP",
        },
    },
    landmarks = {
        "Wasatch Overlook",
        "Salt Flats Speedway",
        "Red Rock Rim",
        "Downtown Temple Grid",
        "Ski Village",
        "Tech Corridor Tower",
        "Lux Automaton Mountain Ops",
    },
    police_fleet = {
        {
            slot = "ut_state_trooper",
            label = "State Trooper Sedan",
            use = "highway patrol",
        },
        {
            slot = "ut_snow_suv",
            label = "Snow Patrol SUV",
            use = "mountain response",
        },
        {
            slot = "ut_ranger_truck",
            label = "Canyon Ranger Truck",
            use = "parks and desert",
        },
        {
            slot = "ut_unmarked",
            label = "Investigations Unit",
            use = "state cases",
        },
        {
            slot = "ut_rescue",
            label = "Search & Rescue",
            use = "blizzard events",
        },
        {
            slot = "ut_air_one",
            label = "Air Rescue",
            use = "special events",
        },
    },
    factions = {
        {
            name = "Wasatch Riders",
            type = "mountain crew",
            business = "tourism, lodge security, legal road events",
        },
        {
            name = "Salt Flats Syndicate",
            type = "auto faction",
            business = "speed trials, rentals, mechanic testing",
        },
        {
            name = "Canyon Crew",
            type = "outdoor faction",
            business = "guide services, ranger contracts",
        },
        {
            name = "Silicon Brokers",
            type = "tech faction",
            business = "software contracts, security audits, app delivery",
        },
    },
    money_loops = {
        "Ski lodge operations",
        "Salt Flats event tickets",
        "Canyon tour permits",
        "Tech contract ladder",
        "State highway towing",
    },
    payouts = {
        director = 28,
        route_lead = 22,
        driver = 18,
        ranger = 14,
        security = 12,
        reserve = 6,
    },
    discord_channels = {
        "announcements",
        "wasatch-rules",
        "whitelist-apps",
        "state-patrol",
        "ski-lodge",
        "salt-flats-events",
        "tech-corridor",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "State Director",
        "Trooper Chief",
        "Ranger Lead",
        "Lodge Owner",
        "Tech CEO",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "State Trooper",
        "Ski Patrol",
        "Off-road Tour Guide",
        "Tech Courier",
        "Tow Driver",
        "Lodge Worker",
    },
    security_focus = {
        "weather event whitelist",
        "off-road boundaries",
        "speed event permits",
        "state police hierarchy controls",
    },
    pricing = {
        zip = 139,
        discord = 279,
        install = 649,
        custom = 2000,
        support = 299,
    },
}
