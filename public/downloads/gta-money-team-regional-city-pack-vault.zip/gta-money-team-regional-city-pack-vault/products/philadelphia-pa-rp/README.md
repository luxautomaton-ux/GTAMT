# Liberty Row RP (Philadelphia RP)

**Region:** Philadelphia, Pennsylvania  
**Sales angle:** A strong Northeast RP pack with deep neighborhood identity, sports events, food economy, and courtroom/political RP potential.  
**Tagline:** Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Center City Grid
Roads: Market Street, Broad Street, City Hall Loop.  
Money loop: taxi, office security, courthouse RP

### South Street Strip
Roads: South Street, Passyunk Cut, Italian Market Row.  
Money loop: food shops, nightlife, delivery

### Fishtown Port
Roads: Frankford Ave, River Ward Road, Port Richmond Spur.  
Money loop: bars, freight, fishing charters

### Sports Complex
Roads: Stadium Way, Packer Ave, Tailgate Row.  
Money loop: event security, merch, parking

### Art Museum Parkway
Roads: Parkway Drive, Museum Steps, Schuylkill Loop.  
Money loop: tourism, photo shoots, park patrol


## Landmarks

- Liberty Bell Square
- City Hall Loop
- Art Museum Steps
- Sports Complex
- Italian Market Row
- Schuylkill Riverfront
- Lux Automaton Liberty Office

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `phi_patrol_sedan` — **Liberty Patrol Sedan**: city patrol
- `phi_highway_unit` — **Expressway Interceptor**: pursuits
- `phi_event_suv` — **Sports Event SUV**: stadium events
- `phi_unmarked` — **Detective Unit**: cases
- `phi_tactical_van` — **Tactical Van**: crowd-control RP
- `phi_bike_unit` — **Center City Bike Unit**: downtown patrol

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Liberty Bell Crew** (neighborhood faction): food shops, delivery, sports merch
- **Broad Street Circle** (event faction): sports nights, security, parking
- **River Ward Syndicate** (logistics faction): dock freight, bar ownership
- **Market Row Brokers** (business faction): markets, permits, food courts

## Legal money loops

- Food shop franchise
- Sports event parking
- Courier grid route
- Court/security contracts
- River ward freight

## Crew payout split

- **Owner**: 30%
- **Manager**: 20%
- **Driver**: 18%
- **Security**: 17%
- **Vendor**: 10%
- **Reserve**: 5%

## Starter jobs

- Food Vendor
- Courier
- Event Security
- Taxi Driver
- Court Clerk
- Dock Worker

## Security focus

- stadium crowd rules
- courthouse RP protections
- vendor fraud checks
- neighborhood conflict cooldowns
