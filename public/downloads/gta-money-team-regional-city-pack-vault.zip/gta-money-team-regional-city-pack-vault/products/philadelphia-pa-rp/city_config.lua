-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "philadelphia-pa-rp",
    title = "Philadelphia RP",
    premium_name = "Liberty Row RP",
    tagline = "Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.",
    region = "Philadelphia, Pennsylvania",
    vibe = "history, rowhomes, sports, riverfront, markets, cheesesteak shops, gritty city politics",
    seller_angle = "A strong Northeast RP pack with deep neighborhood identity, sports events, food economy, and courtroom/political RP potential.",
    spawn = {
        x = 1964.1,
        y = 3819.9,
        z = 32.4,
        h = 120.0,
        label = "Liberty Row Transit Hub",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 18,
            note = "normal day",
        },
        {
            type = "CLOUDS",
            weight = 20,
            note = "Northeast mood",
        },
        {
            type = "OVERCAST",
            weight = 18,
            note = "gritty city vibe",
        },
        {
            type = "RAIN",
            weight = 16,
            note = "stormy sports nights",
        },
        {
            type = "FOGGY",
            weight = 10,
            note = "river mornings",
        },
        {
            type = "XMAS",
            weight = 10,
            note = "winter events",
        },
        {
            type = "SNOWLIGHT",
            weight = 8,
            note = "special winter patrol",
        },
    },
    districts = {
        {
            name = "Center City Grid",
            roads = {
                "Market Street",
                "Broad Street",
                "City Hall Loop",
            },
            money = "taxi, office security, courthouse RP",
        },
        {
            name = "South Street Strip",
            roads = {
                "South Street",
                "Passyunk Cut",
                "Italian Market Row",
            },
            money = "food shops, nightlife, delivery",
        },
        {
            name = "Fishtown Port",
            roads = {
                "Frankford Ave",
                "River Ward Road",
                "Port Richmond Spur",
            },
            money = "bars, freight, fishing charters",
        },
        {
            name = "Sports Complex",
            roads = {
                "Stadium Way",
                "Packer Ave",
                "Tailgate Row",
            },
            money = "event security, merch, parking",
        },
        {
            name = "Art Museum Parkway",
            roads = {
                "Parkway Drive",
                "Museum Steps",
                "Schuylkill Loop",
            },
            money = "tourism, photo shoots, park patrol",
        },
    },
    landmarks = {
        "Liberty Bell Square",
        "City Hall Loop",
        "Art Museum Steps",
        "Sports Complex",
        "Italian Market Row",
        "Schuylkill Riverfront",
        "Lux Automaton Liberty Office",
    },
    police_fleet = {
        {
            slot = "phi_patrol_sedan",
            label = "Liberty Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "phi_highway_unit",
            label = "Expressway Interceptor",
            use = "pursuits",
        },
        {
            slot = "phi_event_suv",
            label = "Sports Event SUV",
            use = "stadium events",
        },
        {
            slot = "phi_unmarked",
            label = "Detective Unit",
            use = "cases",
        },
        {
            slot = "phi_tactical_van",
            label = "Tactical Van",
            use = "crowd-control RP",
        },
        {
            slot = "phi_bike_unit",
            label = "Center City Bike Unit",
            use = "downtown patrol",
        },
    },
    factions = {
        {
            name = "Liberty Bell Crew",
            type = "neighborhood faction",
            business = "food shops, delivery, sports merch",
        },
        {
            name = "Broad Street Circle",
            type = "event faction",
            business = "sports nights, security, parking",
        },
        {
            name = "River Ward Syndicate",
            type = "logistics faction",
            business = "dock freight, bar ownership",
        },
        {
            name = "Market Row Brokers",
            type = "business faction",
            business = "markets, permits, food courts",
        },
    },
    money_loops = {
        "Food shop franchise",
        "Sports event parking",
        "Courier grid route",
        "Court/security contracts",
        "River ward freight",
    },
    payouts = {
        owner = 30,
        manager = 20,
        driver = 18,
        security = 17,
        vendor = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "liberty-rules",
        "whitelist-apps",
        "sports-events",
        "market-business",
        "river-jobs",
        "court-dockets",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "Mayor",
        "Police Commissioner",
        "Business Owner",
        "Venue Owner",
        "Crew Lead",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Food Vendor",
        "Courier",
        "Event Security",
        "Taxi Driver",
        "Court Clerk",
        "Dock Worker",
    },
    security_focus = {
        "stadium crowd rules",
        "courthouse RP protections",
        "vendor fraud checks",
        "neighborhood conflict cooldowns",
    },
    pricing = {
        zip = 149,
        discord = 299,
        install = 699,
        custom = 2200,
        support = 349,
    },
}
