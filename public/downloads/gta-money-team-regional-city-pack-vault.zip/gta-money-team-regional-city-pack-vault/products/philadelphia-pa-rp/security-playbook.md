# Security Playbook — Liberty Row RP

## City-specific focus

- stadium crowd rules
- courthouse RP protections
- vendor fraud checks
- neighborhood conflict cooldowns

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Center City Grid — taxi, office security, courthouse RP
- South Street Strip — food shops, nightlife, delivery
- Fishtown Port — bars, freight, fishing charters
- Sports Complex — event security, merch, parking
- Art Museum Parkway — tourism, photo shoots, park patrol
