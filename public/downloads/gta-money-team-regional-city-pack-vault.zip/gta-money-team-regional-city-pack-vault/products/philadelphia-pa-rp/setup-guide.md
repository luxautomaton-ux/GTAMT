# Setup Guide — Liberty Row RP

## Step 1 — Install shared resource

Copy:

`resources/[gmt]/gmt_city_engine`

to your FiveM resources folder.

## Step 2 — Activate this city

Copy:

`products/philadelphia-pa-rp/city_config.lua`

to:

`resources/[gmt]/gmt_city_engine/config/active_city.lua`

## Step 3 — Update server.cfg

Add the contents of `server-snippet.cfg`, then restart.

## Step 4 — Test in game

Run:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/moneyloops`
- `/securitycheck`

## Step 5 — Add licensed assets

Replace placeholder vehicles with legal/liscensed assets:

- `phi_patrol_sedan` — Liberty Patrol Sedan
- `phi_highway_unit` — Expressway Interceptor
- `phi_event_suv` — Sports Event SUV
- `phi_unmarked` — Detective Unit
- `phi_tactical_van` — Tactical Van
- `phi_bike_unit` — Center City Bike Unit

## Step 6 — Add framework integration

This pack is framework-neutral. Add QBCore, ESX, ox_lib, inventory, dispatch, voice, and jobs after testing the base commands.
