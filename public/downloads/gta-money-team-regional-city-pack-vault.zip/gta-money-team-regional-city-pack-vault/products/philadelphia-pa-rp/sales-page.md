# Sales Page Copy — Liberty Row RP

## Headline

Launch **Liberty Row RP** without building your RP city from zero.

## Subheadline

Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.

## What buyers get

- City identity and theme based on Philadelphia, Pennsylvania energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$149**
- Template + Discord Setup: **$299**
- Installed Server Identity: **$699**
- Full Custom Build: **$2200+**
- Monthly Support: **$349/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
