# Discord Template — Liberty Row RP

## Channels

- #announcements
- #liberty-rules
- #whitelist-apps
- #sports-events
- #market-business
- #river-jobs
- #court-dockets
- #support-tickets

## Roles

- Founder
- Mayor
- Police Commissioner
- Business Owner
- Venue Owner
- Crew Lead
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Liberty Row RP** — Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
