# Security Playbook — Queen City RP

## City-specific focus

- racing permit system
- finance district safe zones
- VIP fraud prevention
- event moderation

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Uptown Finance — bank security, offices, consulting jobs
- South End Rail — bars, breweries, apartment services
- NoDa Creative — venues, murals, merch shops
- Speedway Corridor — legal races, mechanic teams, sponsor events
- University City — student jobs, tech support, campus events
