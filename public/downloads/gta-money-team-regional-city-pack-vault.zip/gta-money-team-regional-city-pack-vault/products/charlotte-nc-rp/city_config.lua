-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "charlotte-nc-rp",
    title = "Charlotte NC RP",
    premium_name = "Queen City RP",
    tagline = "Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.",
    region = "Charlotte, North Carolina",
    vibe = "Uptown skyline, banking, sports, racing, South End nightlife, NoDa creativity, highways",
    seller_angle = "A polished city pack for owners who want business RP, racing events, office politics, creator bars, and strong VIP membership options.",
    spawn = {
        x = -1376.6,
        y = -494.2,
        z = 33.2,
        h = 98.0,
        label = "Queen City Uptown Lobby",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 26,
            note = "business district play",
        },
        {
            type = "EXTRASUNNY",
            weight = 18,
            note = "race day events",
        },
        {
            type = "CLOUDS",
            weight = 18,
            note = "normal RP",
        },
        {
            type = "OVERCAST",
            weight = 12,
            note = "city mood",
        },
        {
            type = "RAIN",
            weight = 14,
            note = "southern storms",
        },
        {
            type = "THUNDER",
            weight = 8,
            note = "special storm nights",
        },
        {
            type = "FOGGY",
            weight = 4,
            note = "early morning routes",
        },
    },
    districts = {
        {
            name = "Uptown Finance",
            roads = {
                "Tryon Grid",
                "Trade Street",
                "Bank Tower Loop",
            },
            money = "bank security, offices, consulting jobs",
        },
        {
            name = "South End Rail",
            roads = {
                "South Boulevard",
                "Rail Trail",
                "Brewery Lane",
            },
            money = "bars, breweries, apartment services",
        },
        {
            name = "NoDa Creative",
            roads = {
                "NoDa Strip",
                "Gallery Row",
                "Music Hall Drive",
            },
            money = "venues, murals, merch shops",
        },
        {
            name = "Speedway Corridor",
            roads = {
                "Concord Run",
                "Pit Road",
                "Speedway Spur",
            },
            money = "legal races, mechanic teams, sponsor events",
        },
        {
            name = "University City",
            roads = {
                "Campus Way",
                "Mallard Creek",
                "Research Drive",
            },
            money = "student jobs, tech support, campus events",
        },
    },
    landmarks = {
        "Uptown Skyline",
        "Queen Stadium",
        "Speedway Corridor",
        "South End Rail Trail",
        "NoDa Arts Block",
        "University City",
        "Lux Automaton Crown Office",
    },
    police_fleet = {
        {
            slot = "clt_patrol_sedan",
            label = "Queen City Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "clt_interceptor",
            label = "Speedway Interceptor",
            use = "race event enforcement",
        },
        {
            slot = "clt_finance_suv",
            label = "Finance District SUV",
            use = "executive security",
        },
        {
            slot = "clt_unmarked",
            label = "Investigations Unit",
            use = "white collar RP",
        },
        {
            slot = "clt_event_van",
            label = "Event Command Van",
            use = "stadium/nightlife",
        },
        {
            slot = "clt_bike_unit",
            label = "Rail Trail Bike Unit",
            use = "district patrol",
        },
    },
    factions = {
        {
            name = "Queen City Elite",
            type = "business faction",
            business = "finance offices, VIP services, consulting",
        },
        {
            name = "NoDa Crew",
            type = "creator faction",
            business = "music venues, art, merch",
        },
        {
            name = "South End Syndicate",
            type = "nightlife faction",
            business = "bars, events, security",
        },
        {
            name = "Crown Motors",
            type = "racing faction",
            business = "legal race events, mechanic teams",
        },
    },
    money_loops = {
        "Finance security contracts",
        "Race event tickets",
        "Brewery distribution",
        "NoDa music nights",
        "University courier route",
    },
    payouts = {
        owner = 32,
        manager = 20,
        driver = 16,
        security = 16,
        creator = 11,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "queen-city-rules",
        "whitelist-apps",
        "finance-jobs",
        "race-events",
        "noda-bookings",
        "business-registry",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Finance Boss",
        "Race Promoter",
        "Venue Owner",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Executive Driver",
        "Race Mechanic",
        "Venue Promoter",
        "Bank Security",
        "Campus Courier",
        "Brewery Runner",
    },
    security_focus = {
        "racing permit system",
        "finance district safe zones",
        "VIP fraud prevention",
        "event moderation",
    },
    pricing = {
        zip = 139,
        discord = 279,
        install = 649,
        custom = 2000,
        support = 299,
    },
}
