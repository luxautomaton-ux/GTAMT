# Sales Page Copy — Queen City RP

## Headline

Launch **Queen City RP** without building your RP city from zero.

## Subheadline

Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.

## What buyers get

- City identity and theme based on Charlotte, North Carolina energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$139**
- Template + Discord Setup: **$279**
- Installed Server Identity: **$649**
- Full Custom Build: **$2000+**
- Monthly Support: **$299/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
