# Queen City RP (Charlotte NC RP)

**Region:** Charlotte, North Carolina  
**Sales angle:** A polished city pack for owners who want business RP, racing events, office politics, creator bars, and strong VIP membership options.  
**Tagline:** Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Uptown Finance
Roads: Tryon Grid, Trade Street, Bank Tower Loop.  
Money loop: bank security, offices, consulting jobs

### South End Rail
Roads: South Boulevard, Rail Trail, Brewery Lane.  
Money loop: bars, breweries, apartment services

### NoDa Creative
Roads: NoDa Strip, Gallery Row, Music Hall Drive.  
Money loop: venues, murals, merch shops

### Speedway Corridor
Roads: Concord Run, Pit Road, Speedway Spur.  
Money loop: legal races, mechanic teams, sponsor events

### University City
Roads: Campus Way, Mallard Creek, Research Drive.  
Money loop: student jobs, tech support, campus events


## Landmarks

- Uptown Skyline
- Queen Stadium
- Speedway Corridor
- South End Rail Trail
- NoDa Arts Block
- University City
- Lux Automaton Crown Office

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `clt_patrol_sedan` — **Queen City Patrol Sedan**: city patrol
- `clt_interceptor` — **Speedway Interceptor**: race event enforcement
- `clt_finance_suv` — **Finance District SUV**: executive security
- `clt_unmarked` — **Investigations Unit**: white collar RP
- `clt_event_van` — **Event Command Van**: stadium/nightlife
- `clt_bike_unit` — **Rail Trail Bike Unit**: district patrol

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Queen City Elite** (business faction): finance offices, VIP services, consulting
- **NoDa Crew** (creator faction): music venues, art, merch
- **South End Syndicate** (nightlife faction): bars, events, security
- **Crown Motors** (racing faction): legal race events, mechanic teams

## Legal money loops

- Finance security contracts
- Race event tickets
- Brewery distribution
- NoDa music nights
- University courier route

## Crew payout split

- **Owner**: 32%
- **Manager**: 20%
- **Driver**: 16%
- **Security**: 16%
- **Creator**: 11%
- **Reserve**: 5%

## Starter jobs

- Executive Driver
- Race Mechanic
- Venue Promoter
- Bank Security
- Campus Courier
- Brewery Runner

## Security focus

- racing permit system
- finance district safe zones
- VIP fraud prevention
- event moderation
