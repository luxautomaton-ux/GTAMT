# Payout Model — Queen City RP

Use this default split for legal money routes.

- **Owner**: 32%
- **Manager**: 20%
- **Driver**: 16%
- **Security**: 16%
- **Creator**: 11%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Owner: $3,200
- Manager: $2,000
- Driver: $1,600
- Security: $1,600
- Creator: $1,100
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
