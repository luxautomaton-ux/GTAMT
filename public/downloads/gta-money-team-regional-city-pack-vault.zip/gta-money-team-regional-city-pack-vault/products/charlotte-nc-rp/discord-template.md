# Discord Template — Queen City RP

## Channels

- #announcements
- #queen-city-rules
- #whitelist-apps
- #finance-jobs
- #race-events
- #noda-bookings
- #business-registry
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Finance Boss
- Race Promoter
- Venue Owner
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Queen City RP** — Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
