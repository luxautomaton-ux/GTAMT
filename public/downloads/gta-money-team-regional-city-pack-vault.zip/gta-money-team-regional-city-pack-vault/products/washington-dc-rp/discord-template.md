# Discord Template — Capital District RP

## Channels

- #announcements
- #capital-rules
- #whitelist-apps
- #city-council
- #security-contracts
- #media-requests
- #wharf-business
- #support-tickets

## Roles

- Founder
- City Administrator
- Police Chief
- Council Member
- Security Director
- Media Lead
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Capital District RP** — Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
