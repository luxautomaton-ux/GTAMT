# Capital District RP (Washington DC RP)

**Region:** Washington, DC  
**Sales angle:** A premium serious-RP pack for communities that want politics, lawful security, media, courts, city contracts, and high-control whitelist systems.  
**Tagline:** Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### National Mall District
Roads: Mall Loop, Constitution Ave, Independence Cut.  
Money loop: tourism, event security, media permits

### The Wharf
Roads: Wharf Drive, Maine Ave, Waterfront Road.  
Money loop: restaurants, boat tours, nightlife security

### Georgetown Row
Roads: M Street, Wisconsin Climb, Canal Road.  
Money loop: boutiques, luxury real estate, valet

### Navy Yard
Roads: Yard Way, Stadium Road, Riverfront Cut.  
Money loop: stadium events, port security, rentals

### H Street / U Street
Roads: H Street Run, U Street Line, Shaw Market.  
Money loop: clubs, restaurants, music venues


## Landmarks

- Capital Plaza
- Monument Row
- Union Station
- The Wharf
- Georgetown Canal
- Navy Yard Stadium
- Lux Automaton Civic Command

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `dc_metro_patrol` — **Capital Metro Patrol**: city patrol
- `dc_motorcade_suv` — **Motorcade SUV**: VIP escort RP
- `dc_unmarked` — **Investigations Unit**: casework
- `dc_event_van` — **Civic Event Command**: crowd/event response
- `dc_bike_unit` — **Mall Bike Unit**: monument patrol
- `dc_marine` — **River Patrol**: wharf events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Capital Circle** (political/social faction): campaign events, lobbying RP, media appearances
- **Wharf Kings** (waterfront faction): restaurants, boat tours, nightlife
- **Georgetown Brokers** (luxury faction): real estate, boutiques, VIP transport
- **District Media House** (creator faction): news, interviews, podcasts, event coverage

## Legal money loops

- Security contract ladder
- Wharf restaurant chain
- Media coverage packages
- Motorcade escort jobs
- Tour guide permits

## Crew payout split

- **Director**: 32%
- **Operations**: 20%
- **Security**: 18%
- **Driver**: 14%
- **Media**: 11%
- **Reserve**: 5%

## Starter jobs

- Civic Security
- Media Reporter
- VIP Driver
- Wharf Vendor
- Tour Guide
- Court Clerk

## Security focus

- high-control whitelist
- no real federal agency logos
- motorcade griefing ban
- political harassment moderation
