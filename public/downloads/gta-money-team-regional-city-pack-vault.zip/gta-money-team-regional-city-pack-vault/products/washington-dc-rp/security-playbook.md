# Security Playbook — Capital District RP

## City-specific focus

- high-control whitelist
- no real federal agency logos
- motorcade griefing ban
- political harassment moderation

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- National Mall District — tourism, event security, media permits
- The Wharf — restaurants, boat tours, nightlife security
- Georgetown Row — boutiques, luxury real estate, valet
- Navy Yard — stadium events, port security, rentals
- H Street / U Street — clubs, restaurants, music venues
