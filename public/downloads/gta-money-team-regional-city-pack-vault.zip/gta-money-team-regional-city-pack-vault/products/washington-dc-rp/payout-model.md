# Payout Model — Capital District RP

Use this default split for legal money routes.

- **Director**: 32%
- **Operations**: 20%
- **Security**: 18%
- **Driver**: 14%
- **Media**: 11%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Director: $3,200
- Operations: $2,000
- Security: $1,800
- Driver: $1,400
- Media: $1,100
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
