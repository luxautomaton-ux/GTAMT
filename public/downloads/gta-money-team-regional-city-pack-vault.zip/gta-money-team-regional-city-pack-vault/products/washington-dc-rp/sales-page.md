# Sales Page Copy — Capital District RP

## Headline

Launch **Capital District RP** without building your RP city from zero.

## Subheadline

Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.

## What buyers get

- City identity and theme based on Washington, DC energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$159**
- Template + Discord Setup: **$349**
- Installed Server Identity: **$799**
- Full Custom Build: **$2500+**
- Monthly Support: **$399/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
