-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "washington-dc-rp",
    title = "Washington DC RP",
    premium_name = "Capital District RP",
    tagline = "Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.",
    region = "Washington, DC",
    vibe = "capital city, monuments, politics, wharf nightlife, media, embassies, security, metro corridors",
    seller_angle = "A premium serious-RP pack for communities that want politics, lawful security, media, courts, city contracts, and high-control whitelist systems.",
    spawn = {
        x = -2183.8,
        y = -400.5,
        z = 13.3,
        h = 130.0,
        label = "Capital District Union Station",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 22,
            note = "daytime civic RP",
        },
        {
            type = "CLOUDS",
            weight = 20,
            note = "metro mood",
        },
        {
            type = "OVERCAST",
            weight = 16,
            note = "political drama",
        },
        {
            type = "RAIN",
            weight = 14,
            note = "security events",
        },
        {
            type = "FOGGY",
            weight = 10,
            note = "river mornings",
        },
        {
            type = "XMAS",
            weight = 10,
            note = "winter national events",
        },
        {
            type = "SNOWLIGHT",
            weight = 8,
            note = "special winter sessions",
        },
    },
    districts = {
        {
            name = "National Mall District",
            roads = {
                "Mall Loop",
                "Constitution Ave",
                "Independence Cut",
            },
            money = "tourism, event security, media permits",
        },
        {
            name = "The Wharf",
            roads = {
                "Wharf Drive",
                "Maine Ave",
                "Waterfront Road",
            },
            money = "restaurants, boat tours, nightlife security",
        },
        {
            name = "Georgetown Row",
            roads = {
                "M Street",
                "Wisconsin Climb",
                "Canal Road",
            },
            money = "boutiques, luxury real estate, valet",
        },
        {
            name = "Navy Yard",
            roads = {
                "Yard Way",
                "Stadium Road",
                "Riverfront Cut",
            },
            money = "stadium events, port security, rentals",
        },
        {
            name = "H Street / U Street",
            roads = {
                "H Street Run",
                "U Street Line",
                "Shaw Market",
            },
            money = "clubs, restaurants, music venues",
        },
    },
    landmarks = {
        "Capital Plaza",
        "Monument Row",
        "Union Station",
        "The Wharf",
        "Georgetown Canal",
        "Navy Yard Stadium",
        "Lux Automaton Civic Command",
    },
    police_fleet = {
        {
            slot = "dc_metro_patrol",
            label = "Capital Metro Patrol",
            use = "city patrol",
        },
        {
            slot = "dc_motorcade_suv",
            label = "Motorcade SUV",
            use = "VIP escort RP",
        },
        {
            slot = "dc_unmarked",
            label = "Investigations Unit",
            use = "casework",
        },
        {
            slot = "dc_event_van",
            label = "Civic Event Command",
            use = "crowd/event response",
        },
        {
            slot = "dc_bike_unit",
            label = "Mall Bike Unit",
            use = "monument patrol",
        },
        {
            slot = "dc_marine",
            label = "River Patrol",
            use = "wharf events",
        },
    },
    factions = {
        {
            name = "Capital Circle",
            type = "political/social faction",
            business = "campaign events, lobbying RP, media appearances",
        },
        {
            name = "Wharf Kings",
            type = "waterfront faction",
            business = "restaurants, boat tours, nightlife",
        },
        {
            name = "Georgetown Brokers",
            type = "luxury faction",
            business = "real estate, boutiques, VIP transport",
        },
        {
            name = "District Media House",
            type = "creator faction",
            business = "news, interviews, podcasts, event coverage",
        },
    },
    money_loops = {
        "Security contract ladder",
        "Wharf restaurant chain",
        "Media coverage packages",
        "Motorcade escort jobs",
        "Tour guide permits",
    },
    payouts = {
        director = 32,
        operations = 20,
        security = 18,
        driver = 14,
        media = 11,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "capital-rules",
        "whitelist-apps",
        "city-council",
        "security-contracts",
        "media-requests",
        "wharf-business",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Administrator",
        "Police Chief",
        "Council Member",
        "Security Director",
        "Media Lead",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Civic Security",
        "Media Reporter",
        "VIP Driver",
        "Wharf Vendor",
        "Tour Guide",
        "Court Clerk",
    },
    security_focus = {
        "high-control whitelist",
        "no real federal agency logos",
        "motorcade griefing ban",
        "political harassment moderation",
    },
    pricing = {
        zip = 159,
        discord = 349,
        install = 799,
        custom = 2500,
        support = 399,
    },
}
