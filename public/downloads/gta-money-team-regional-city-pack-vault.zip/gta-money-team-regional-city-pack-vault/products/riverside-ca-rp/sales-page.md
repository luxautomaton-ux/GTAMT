# Sales Page Copy — Citrus Valley RP

## Headline

Launch **Citrus Valley RP** without building your RP city from zero.

## Subheadline

Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.

## What buyers get

- City identity and theme based on Riverside, California energy.
- Districts, streets, landmarks, and money loops.
- Police fleet placeholders ready for licensed add-on vehicles.
- Fictional crew/faction concepts.
- Crew payout model.
- Discord channel/role setup.
- Security hardening checklist.
- FiveM Lua config and `server.cfg` snippet.

## Perfect for

- New RP founders.
- Streamers launching a community city.
- Server owners who need a fresh themed wipe.
- Discord communities that need structure.
- Buyers who want legal RP money systems.

## Price ladder

- Template ZIP: **$119**
- Template + Discord Setup: **$249**
- Installed Server Identity: **$549**
- Full Custom Build: **$1600+**
- Monthly Support: **$249/mo**

## CTA

Request this city pack from GTA Money Team and launch with a clean city identity, safer setup, and money systems built for retention.
