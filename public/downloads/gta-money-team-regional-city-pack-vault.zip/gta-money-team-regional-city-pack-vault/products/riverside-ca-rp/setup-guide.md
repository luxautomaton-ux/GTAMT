# Setup Guide — Citrus Valley RP

## Step 1 — Install shared resource

Copy:

`resources/[gmt]/gmt_city_engine`

to your FiveM resources folder.

## Step 2 — Activate this city

Copy:

`products/riverside-ca-rp/city_config.lua`

to:

`resources/[gmt]/gmt_city_engine/config/active_city.lua`

## Step 3 — Update server.cfg

Add the contents of `server-snippet.cfg`, then restart.

## Step 4 — Test in game

Run:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/moneyloops`
- `/securitycheck`

## Step 5 — Add licensed assets

Replace placeholder vehicles with legal/liscensed assets:

- `riv_patrol_sedan` — Valley Patrol Sedan
- `riv_highway_interceptor` — Freeway Interceptor
- `riv_suv` — Foothill SUV
- `riv_unmarked` — Investigation Sedan
- `riv_traffic_unit` — Traffic Motor Unit
- `riv_rescue` — Riverbed Rescue

## Step 6 — Add framework integration

This pack is framework-neutral. Add QBCore, ESX, ox_lib, inventory, dispatch, voice, and jobs after testing the base commands.
