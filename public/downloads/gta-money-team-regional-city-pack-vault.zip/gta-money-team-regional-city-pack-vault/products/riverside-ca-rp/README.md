# Citrus Valley RP (Riverside CA RP)

**Region:** Riverside, California  
**Sales angle:** A lower-drama, high-economy Southern California city for owners who want logistics, legal racing, college RP, and warehouse businesses.  
**Tagline:** Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Mission District
Roads: Mission Inn Row, Market Cut, Main Street.  
Money loop: hotel jobs, valet, tourism events

### Magnolia Auto Row
Roads: Magnolia Mile, Auto Center Spur, La Sierra Drive.  
Money loop: car lots, mechanics, legal street meets

### University Heights
Roads: University Ave, Canyon Crest, Campus Loop.  
Money loop: student jobs, coffee shops, tutoring RP

### Warehouse Valley
Roads: Box Springs Freight, Commerce Lane, Industrial Way.  
Money loop: forklift RP, trucking, storage leases

### Rubidoux Hills
Roads: Rubidoux Climb, River Road, Foothill Bend.  
Money loop: hiking tours, photo shoots, ranger events


## Landmarks

- Mission Hotel Plaza
- Mount Rubidoux Lookout
- Citrus Market
- University District
- Warehouse Valley
- Santa Ana Riverbed
- Lux Automaton Inland Office

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `riv_patrol_sedan` — **Valley Patrol Sedan**: city patrol
- `riv_highway_interceptor` — **Freeway Interceptor**: I-route pursuit
- `riv_suv` — **Foothill SUV**: hillside patrol
- `riv_unmarked` — **Investigation Sedan**: casework
- `riv_traffic_unit` — **Traffic Motor Unit**: freeway enforcement
- `riv_rescue` — **Riverbed Rescue**: event/medical support

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Citrus Circle** (business faction): groves, produce hauling, farmers market
- **Magnolia Kings** (auto faction): repair shops, car lots, legal events
- **Riverbed Riders** (outdoor crew): tour guides, photo ops, ranger contracts
- **Mission Brokers** (hospitality group): hotels, valet, event bookings

## Legal money loops

- Citrus delivery chain
- Warehouse contract ladder
- Hotel valet service
- Mechanic subscriptions
- Campus event permits

## Crew payout split

- **Operator**: 30%
- **Dispatcher**: 20%
- **Driver**: 20%
- **Mechanic**: 15%
- **Security**: 10%
- **Reserve**: 5%

## Starter jobs

- Warehouse Worker
- Citrus Trucker
- Valet
- Mechanic
- Campus Courier
- Park Ranger

## Security focus

- warehouse access keys
- race-event permits only
- riverbed no-grief zones
- vehicle duplication checks
