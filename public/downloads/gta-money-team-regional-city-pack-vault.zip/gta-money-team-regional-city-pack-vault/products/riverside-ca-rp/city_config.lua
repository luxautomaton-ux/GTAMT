-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "riverside-ca-rp",
    title = "Riverside CA RP",
    premium_name = "Citrus Valley RP",
    tagline = "Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.",
    region = "Riverside, California",
    vibe = "sun, warehouses, universities, historic hotels, freeways, foothills, orange groves",
    seller_angle = "A lower-drama, high-economy Southern California city for owners who want logistics, legal racing, college RP, and warehouse businesses.",
    spawn = {
        x = -705.7,
        y = -913.5,
        z = 19.2,
        h = 90.0,
        label = "Citrus Valley Depot",
    },
    weather = {
        {
            type = "EXTRASUNNY",
            weight = 34,
            note = "Inland heat",
        },
        {
            type = "CLEAR",
            weight = 26,
            note = "daily routes",
        },
        {
            type = "SMOG",
            weight = 15,
            note = "freeway haze",
        },
        {
            type = "CLOUDS",
            weight = 12,
            note = "soft sunsets",
        },
        {
            type = "OVERCAST",
            weight = 8,
            note = "cooler events",
        },
        {
            type = "THUNDER",
            weight = 5,
            note = "rare storm event",
        },
    },
    districts = {
        {
            name = "Mission District",
            roads = {
                "Mission Inn Row",
                "Market Cut",
                "Main Street",
            },
            money = "hotel jobs, valet, tourism events",
        },
        {
            name = "Magnolia Auto Row",
            roads = {
                "Magnolia Mile",
                "Auto Center Spur",
                "La Sierra Drive",
            },
            money = "car lots, mechanics, legal street meets",
        },
        {
            name = "University Heights",
            roads = {
                "University Ave",
                "Canyon Crest",
                "Campus Loop",
            },
            money = "student jobs, coffee shops, tutoring RP",
        },
        {
            name = "Warehouse Valley",
            roads = {
                "Box Springs Freight",
                "Commerce Lane",
                "Industrial Way",
            },
            money = "forklift RP, trucking, storage leases",
        },
        {
            name = "Rubidoux Hills",
            roads = {
                "Rubidoux Climb",
                "River Road",
                "Foothill Bend",
            },
            money = "hiking tours, photo shoots, ranger events",
        },
    },
    landmarks = {
        "Mission Hotel Plaza",
        "Mount Rubidoux Lookout",
        "Citrus Market",
        "University District",
        "Warehouse Valley",
        "Santa Ana Riverbed",
        "Lux Automaton Inland Office",
    },
    police_fleet = {
        {
            slot = "riv_patrol_sedan",
            label = "Valley Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "riv_highway_interceptor",
            label = "Freeway Interceptor",
            use = "I-route pursuit",
        },
        {
            slot = "riv_suv",
            label = "Foothill SUV",
            use = "hillside patrol",
        },
        {
            slot = "riv_unmarked",
            label = "Investigation Sedan",
            use = "casework",
        },
        {
            slot = "riv_traffic_unit",
            label = "Traffic Motor Unit",
            use = "freeway enforcement",
        },
        {
            slot = "riv_rescue",
            label = "Riverbed Rescue",
            use = "event/medical support",
        },
    },
    factions = {
        {
            name = "Citrus Circle",
            type = "business faction",
            business = "groves, produce hauling, farmers market",
        },
        {
            name = "Magnolia Kings",
            type = "auto faction",
            business = "repair shops, car lots, legal events",
        },
        {
            name = "Riverbed Riders",
            type = "outdoor crew",
            business = "tour guides, photo ops, ranger contracts",
        },
        {
            name = "Mission Brokers",
            type = "hospitality group",
            business = "hotels, valet, event bookings",
        },
    },
    money_loops = {
        "Citrus delivery chain",
        "Warehouse contract ladder",
        "Hotel valet service",
        "Mechanic subscriptions",
        "Campus event permits",
    },
    payouts = {
        operator = 30,
        dispatcher = 20,
        driver = 20,
        mechanic = 15,
        security = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "citrus-rules",
        "whitelist-apps",
        "warehouse-dispatch",
        "auto-row",
        "campus-events",
        "business-licenses",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "City Manager",
        "Police Chief",
        "Warehouse Boss",
        "Auto Owner",
        "Campus Lead",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "Warehouse Worker",
        "Citrus Trucker",
        "Valet",
        "Mechanic",
        "Campus Courier",
        "Park Ranger",
    },
    security_focus = {
        "warehouse access keys",
        "race-event permits only",
        "riverbed no-grief zones",
        "vehicle duplication checks",
    },
    pricing = {
        zip = 119,
        discord = 249,
        install = 549,
        custom = 1600,
        support = 249,
    },
}
