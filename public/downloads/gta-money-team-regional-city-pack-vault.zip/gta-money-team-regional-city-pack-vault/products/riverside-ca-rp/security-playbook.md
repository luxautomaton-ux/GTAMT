# Security Playbook — Citrus Valley RP

## City-specific focus

- warehouse access keys
- race-event permits only
- riverbed no-grief zones
- vehicle duplication checks

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Mission District — hotel jobs, valet, tourism events
- Magnolia Auto Row — car lots, mechanics, legal street meets
- University Heights — student jobs, coffee shops, tutoring RP
- Warehouse Valley — forklift RP, trucking, storage leases
- Rubidoux Hills — hiking tours, photo shoots, ranger events
