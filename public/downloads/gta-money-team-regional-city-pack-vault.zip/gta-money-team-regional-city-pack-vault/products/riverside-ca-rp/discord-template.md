# Discord Template — Citrus Valley RP

## Channels

- #announcements
- #citrus-rules
- #whitelist-apps
- #warehouse-dispatch
- #auto-row
- #campus-events
- #business-licenses
- #support-tickets

## Roles

- Founder
- City Manager
- Police Chief
- Warehouse Boss
- Auto Owner
- Campus Lead
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Citrus Valley RP** — Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
