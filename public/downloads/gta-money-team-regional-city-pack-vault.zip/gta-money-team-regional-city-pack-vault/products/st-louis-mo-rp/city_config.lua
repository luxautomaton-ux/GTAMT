-- ============================================================
-- GTA Money Team Regional City Pack
-- Copy this file to:
-- resources/[gmt]/gmt_city_engine/config/active_city.lua
-- ============================================================

GMT_CITY = {
    id = "st-louis-mo-rp",
    title = "St. Louis RP",
    premium_name = "Gateway River RP",
    tagline = "Gateway city RP with river freight, sports nights, brick neighborhoods, and logistics money.",
    region = "St. Louis, Missouri",
    vibe = "riverfront, arch skyline, brick streets, sports culture, warehouses, music, Midwest grit",
    seller_angle = "A strong Midwest product for owners who want river logistics, police politics, music venues, sports events, and crew payout systems.",
    spawn = {
        x = 435.9,
        y = -982.2,
        z = 30.7,
        h = 90.0,
        label = "Gateway City Hall",
    },
    weather = {
        {
            type = "CLEAR",
            weight = 20,
            note = "day-to-day city play",
        },
        {
            type = "CLOUDS",
            weight = 20,
            note = "Midwest mood",
        },
        {
            type = "OVERCAST",
            weight = 16,
            note = "riverfront RP",
        },
        {
            type = "RAIN",
            weight = 16,
            note = "stormy logistics",
        },
        {
            type = "FOGGY",
            weight = 14,
            note = "river fog",
        },
        {
            type = "THUNDER",
            weight = 8,
            note = "severe event nights",
        },
        {
            type = "XMAS",
            weight = 6,
            note = "winter city events",
        },
    },
    districts = {
        {
            name = "Gateway Riverfront",
            roads = {
                "Archway Drive",
                "Riverfront Road",
                "Market Street",
            },
            money = "tourism, security, food vendors",
        },
        {
            name = "Soulard Brick Market",
            roads = {
                "Soulard Row",
                "Brewery Lane",
                "Russell Cut",
            },
            money = "bar ownership, brewery deliveries, music nights",
        },
        {
            name = "Delmar Loop",
            roads = {
                "Delmar Mile",
                "Loop West",
                "Trolley Spur",
            },
            money = "venues, merch drops, student jobs",
        },
        {
            name = "Forest Park District",
            roads = {
                "Parkway West",
                "Zoo Road",
                "Museum Loop",
            },
            money = "events, park patrol, family RP",
        },
        {
            name = "North River Yards",
            roads = {
                "Rail Yard Road",
                "Dock Street",
                "I-70 Spur",
            },
            money = "rail freight, tow yard, warehouse contracts",
        },
    },
    landmarks = {
        "Gateway Arch View",
        "Riverfront Docks",
        "Soulard Market",
        "Forest Park Loop",
        "Sports Arena District",
        "Brick Warehouse Row",
        "Lux Automaton Gateway Office",
    },
    police_fleet = {
        {
            slot = "stl_patrol_sedan",
            label = "Gateway Patrol Sedan",
            use = "city patrol",
        },
        {
            slot = "stl_highway_unit",
            label = "Interstate Unit",
            use = "I-route pursuit",
        },
        {
            slot = "stl_river_suv",
            label = "Riverfront SUV",
            use = "dock/security",
        },
        {
            slot = "stl_detective",
            label = "Detective Unit",
            use = "investigations",
        },
        {
            slot = "stl_tactical_van",
            label = "Tactical Van",
            use = "event response",
        },
        {
            slot = "stl_marine",
            label = "River Patrol",
            use = "river events",
        },
    },
    factions = {
        {
            name = "Arch City Crew",
            type = "street crew",
            business = "events, merch, legal routes",
        },
        {
            name = "Riverfront Kings",
            type = "logistics crew",
            business = "dock contracts, freight security",
        },
        {
            name = "Delmar Circle",
            type = "creative faction",
            business = "music venues, record nights, streetwear",
        },
        {
            name = "Brick Yard Union",
            type = "labor faction",
            business = "warehouse, towing, auto repair",
        },
    },
    money_loops = {
        "River freight route",
        "Brewery delivery chain",
        "Sports night security",
        "Venue ticket ladder",
        "Tow yard dispatch",
    },
    payouts = {
        owner = 30,
        dispatcher = 20,
        driver = 20,
        security = 15,
        vendor = 10,
        reserve = 5,
    },
    discord_channels = {
        "announcements",
        "gateway-rules",
        "whitelist-apps",
        "riverfront-jobs",
        "music-venues",
        "sports-events",
        "business-registry",
        "support-tickets",
    },
    discord_roles = {
        "Founder",
        "Mayor",
        "Police Chief",
        "River Boss",
        "Venue Owner",
        "Crew Lead",
        "VIP Resident",
        "New Arrival",
    },
    starter_jobs = {
        "River Trucker",
        "Venue Worker",
        "Brewery Driver",
        "Tow Operator",
        "Event Security",
        "Park Ranger",
    },
    security_focus = {
        "riverfront no-RDM zone",
        "event weapon controls",
        "warehouse access whitelists",
        "rail-yard cooldowns",
    },
    pricing = {
        zip = 129,
        discord = 249,
        install = 599,
        custom = 1800,
        support = 299,
    },
}
