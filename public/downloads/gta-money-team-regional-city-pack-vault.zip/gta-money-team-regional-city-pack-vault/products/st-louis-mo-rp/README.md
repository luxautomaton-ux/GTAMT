# Gateway River RP (St. Louis RP)

**Region:** St. Louis, Missouri  
**Sales angle:** A strong Midwest product for owners who want river logistics, police politics, music venues, sports events, and crew payout systems.  
**Tagline:** Gateway city RP with river freight, sports nights, brick neighborhoods, and logistics money.

## What this pack gives the buyer

- City identity and RP districts.
- Weather rotation tuned to the city vibe.
- Police fleet placeholders ready for legal vehicle add-ons.
- Fictional crews/factions for RP conflict without using real gang branding.
- Landmarks and streets for route planning.
- Crew payout model.
- Discord channel/role template.
- Security rules and anti-griefing notes.
- Starter Lua config for the shared `gmt_city_engine` resource.

## Districts and street grid

### Gateway Riverfront
Roads: Archway Drive, Riverfront Road, Market Street.  
Money loop: tourism, security, food vendors

### Soulard Brick Market
Roads: Soulard Row, Brewery Lane, Russell Cut.  
Money loop: bar ownership, brewery deliveries, music nights

### Delmar Loop
Roads: Delmar Mile, Loop West, Trolley Spur.  
Money loop: venues, merch drops, student jobs

### Forest Park District
Roads: Parkway West, Zoo Road, Museum Loop.  
Money loop: events, park patrol, family RP

### North River Yards
Roads: Rail Yard Road, Dock Street, I-70 Spur.  
Money loop: rail freight, tow yard, warehouse contracts


## Landmarks

- Gateway Arch View
- Riverfront Docks
- Soulard Market
- Forest Park Loop
- Sports Arena District
- Brick Warehouse Row
- Lux Automaton Gateway Office

## Police fleet placeholders

Replace these placeholder spawn names with vehicles you own or have permission to use. Do not sell real police skins/logos unless you have rights.

- `stl_patrol_sedan` — **Gateway Patrol Sedan**: city patrol
- `stl_highway_unit` — **Interstate Unit**: I-route pursuit
- `stl_river_suv` — **Riverfront SUV**: dock/security
- `stl_detective` — **Detective Unit**: investigations
- `stl_tactical_van` — **Tactical Van**: event response
- `stl_marine` — **River Patrol**: river events

## Fictional factions / crews

These are fictional RP groups. They are not real gangs and should not use real gang names, logos, or territories.

- **Arch City Crew** (street crew): events, merch, legal routes
- **Riverfront Kings** (logistics crew): dock contracts, freight security
- **Delmar Circle** (creative faction): music venues, record nights, streetwear
- **Brick Yard Union** (labor faction): warehouse, towing, auto repair

## Legal money loops

- River freight route
- Brewery delivery chain
- Sports night security
- Venue ticket ladder
- Tow yard dispatch

## Crew payout split

- **Owner**: 30%
- **Dispatcher**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Vendor**: 10%
- **Reserve**: 5%

## Starter jobs

- River Trucker
- Venue Worker
- Brewery Driver
- Tow Operator
- Event Security
- Park Ranger

## Security focus

- riverfront no-RDM zone
- event weapon controls
- warehouse access whitelists
- rail-yard cooldowns
