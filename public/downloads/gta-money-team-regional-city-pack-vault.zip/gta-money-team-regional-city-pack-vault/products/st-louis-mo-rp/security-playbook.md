# Security Playbook — Gateway River RP

## City-specific focus

- riverfront no-RDM zone
- event weapon controls
- warehouse access whitelists
- rail-yard cooldowns

## Required policies

- Staff decisions go through tickets.
- High-value money loops require cooldowns.
- Businesses require an application or license.
- Do not allow real gang recruitment or real-world threats.
- Keep police, EMS, and staff roles separate.
- Every paid script must be audited before production.

## Risk zones to moderate

- Gateway Riverfront — tourism, security, food vendors
- Soulard Brick Market — bar ownership, brewery deliveries, music nights
- Delmar Loop — venues, merch drops, student jobs
- Forest Park District — events, park patrol, family RP
- North River Yards — rail freight, tow yard, warehouse contracts
