# Discord Template — Gateway River RP

## Channels

- #announcements
- #gateway-rules
- #whitelist-apps
- #riverfront-jobs
- #music-venues
- #sports-events
- #business-registry
- #support-tickets

## Roles

- Founder
- Mayor
- Police Chief
- River Boss
- Venue Owner
- Crew Lead
- VIP Resident
- New Arrival

## Welcome copy

Welcome to **Gateway River RP** — Gateway city RP with river freight, sports nights, brick neighborhoods, and logistics money.

This is a legal RP economy. No cheats, no leaked scripts, no real gang recruitment, no harassment, no doxxing, and no pay-to-win setups.

## Whitelist questions

1. What kind of character are you creating?
2. What legal job or business do you want first?
3. Explain the no-RDM/no-VDM rule.
4. How do you handle a scene that goes badly?
5. Which district do you want to start in and why?
