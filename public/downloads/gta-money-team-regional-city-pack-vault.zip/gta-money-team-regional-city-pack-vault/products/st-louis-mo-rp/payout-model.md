# Payout Model — Gateway River RP

Use this default split for legal money routes.

- **Owner**: 30%
- **Dispatcher**: 20%
- **Driver**: 20%
- **Security**: 15%
- **Vendor**: 10%
- **Reserve**: 5%

## Example route payout

If a legal route earns **$10,000 RP dollars**:

- Owner: $3,000
- Dispatcher: $2,000
- Driver: $2,000
- Security: $1,500
- Vendor: $1,000
- Reserve: $500

## Balancing rule

If your economy inflates too quickly, reduce route payouts by 15% and increase business permit costs by 10% for one week.
