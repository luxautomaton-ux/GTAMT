# Setup Guide — Gateway River RP

## Step 1 — Install shared resource

Copy:

`resources/[gmt]/gmt_city_engine`

to your FiveM resources folder.

## Step 2 — Activate this city

Copy:

`products/st-louis-mo-rp/city_config.lua`

to:

`resources/[gmt]/gmt_city_engine/config/active_city.lua`

## Step 3 — Update server.cfg

Add the contents of `server-snippet.cfg`, then restart.

## Step 4 — Test in game

Run:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/moneyloops`
- `/securitycheck`

## Step 5 — Add licensed assets

Replace placeholder vehicles with legal/liscensed assets:

- `stl_patrol_sedan` — Gateway Patrol Sedan
- `stl_highway_unit` — Interstate Unit
- `stl_river_suv` — Riverfront SUV
- `stl_detective` — Detective Unit
- `stl_tactical_van` — Tactical Van
- `stl_marine` — River Patrol

## Step 6 — Add framework integration

This pack is framework-neutral. Add QBCore, ESX, ox_lib, inventory, dispatch, voice, and jobs after testing the base commands.
