-- GTA Money Team City Engine
-- Shared lightweight resource for premium city identity packs.

fx_version 'cerulean'
game 'gta5'

author 'Lux Automaton / GTA Money Team'
description 'Regional city pack identity engine: landmarks, districts, payouts, weather plans, security checklist.'
version '1.0.0'

shared_scripts {
    'config/active_city.lua',
    'shared/utils.lua'
}

server_scripts {
    'server/main.lua',
    'server/security.lua'
}

client_scripts {
    'client/main.lua'
}
