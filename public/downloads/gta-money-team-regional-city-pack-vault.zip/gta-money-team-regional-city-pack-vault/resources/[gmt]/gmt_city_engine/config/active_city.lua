-- Active city configuration
-- Replace this file with any product city_config.lua from the products folder.

GMT_CITY = {
    id = "demo-city",
    title = "Demo City",
    premium_name = "Demo City RP",
    tagline = "Replace this file with a premium city config.",
    spawn = { x = -268.7, y = -956.0, z = 31.2, h = 205.0, label = "Default Spawn" },
    weather = {
        { type = "CLEAR", weight = 50, note = "default clear weather" },
        { type = "CLOUDS", weight = 50, note = "default cloudy weather" }
    },
    districts = {},
    landmarks = {},
    police_fleet = {},
    factions = {},
    money_loops = {},
    payouts = { owner = 30, driver = 20, security = 15, support = 10, reserve = 5 },
    security_focus = {}
}
