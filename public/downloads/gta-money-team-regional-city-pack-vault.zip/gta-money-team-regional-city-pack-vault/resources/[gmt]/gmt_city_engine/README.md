# gmt_city_engine

This is a lightweight resource that displays city pack details in game.

## Commands

- `/citypack` — shows active city pack.
- `/landmarks` — lists landmark names.
- `/streets` — lists districts and roads.
- `/factions` — lists fictional RP factions.
- `/policefleet` — lists vehicle placeholder slots.
- `/payouts` — shows crew payout percentages.
- `/weatherplan` — shows the city weather rotation.
- `/moneyloops` — shows legal city money loops.
- `/securitycheck` — shows city-specific security focus.
- `/cityspawninfo` — shows configured spawn data.

## Install

Copy one product's `city_config.lua` into `config/active_city.lua`, then `ensure gmt_city_engine` in server.cfg.
