GMT = GMT or {}

-- Send a chat message to one player. `source` is provided by FiveM server events.
function GMT.Notify(source, title, message)
    TriggerClientEvent('chat:addMessage', source, {
        color = { 0, 240, 255 },
        multiline = true,
        args = { title or 'GTA Money Team', message or '' }
    })
end

-- Join table values safely for chat output.
function GMT.Join(list, separator)
    separator = separator or ', '
    if type(list) ~= 'table' then return tostring(list or '') end
    local out = {}
    for _, value in ipairs(list) do
        if type(value) == 'table' then
            table.insert(out, value.name or value.label or value.type or 'item')
        else
            table.insert(out, tostring(value))
        end
    end
    return table.concat(out, separator)
end

-- Format a payout table like owner: 30%, driver: 20%.
function GMT.FormatPayouts(payouts)
    local out = {}
    for role, pct in pairs(payouts or {}) do
        table.insert(out, role .. ': ' .. tostring(pct) .. '%')
    end
    table.sort(out)
    return table.concat(out, ' | ')
end
