-- Server-side city commands.
-- These commands are intentionally simple so buyers can understand and extend them.

local city = GMT_CITY or {}

local function cityTitle()
    return (city.premium_name or city.title or 'GTA Money Team City Pack')
end

RegisterCommand('citypack', function(source)
    GMT.Notify(source, cityTitle(), (city.tagline or 'City identity loaded.') .. ' | Pack ID: ' .. tostring(city.id))
end, false)

RegisterCommand('landmarks', function(source)
    GMT.Notify(source, cityTitle() .. ' Landmarks', GMT.Join(city.landmarks or {}, ' | '))
end, false)

RegisterCommand('streets', function(source)
    local lines = {}
    for _, district in ipairs(city.districts or {}) do
        table.insert(lines, district.name .. ': ' .. GMT.Join(district.roads or {}, ', '))
    end
    GMT.Notify(source, cityTitle() .. ' Streets', table.concat(lines, ' || '))
end, false)

RegisterCommand('factions', function(source)
    local lines = {}
    for _, faction in ipairs(city.factions or {}) do
        table.insert(lines, faction.name .. ' (' .. faction.type .. ')')
    end
    GMT.Notify(source, cityTitle() .. ' Fictional Factions', table.concat(lines, ' | '))
end, false)

RegisterCommand('policefleet', function(source)
    local lines = {}
    for _, unit in ipairs(city.police_fleet or {}) do
        table.insert(lines, unit.slot .. ' = ' .. unit.label)
    end
    GMT.Notify(source, cityTitle() .. ' Fleet Placeholders', table.concat(lines, ' | '))
end, false)

RegisterCommand('payouts', function(source)
    GMT.Notify(source, cityTitle() .. ' Crew Payouts', GMT.FormatPayouts(city.payouts or {}))
end, false)

RegisterCommand('weatherplan', function(source)
    local lines = {}
    for _, weather in ipairs(city.weather or {}) do
        table.insert(lines, weather.type .. ' (' .. tostring(weather.weight) .. '%): ' .. weather.note)
    end
    GMT.Notify(source, cityTitle() .. ' Weather Rotation', table.concat(lines, ' | '))
end, false)

RegisterCommand('moneyloops', function(source)
    GMT.Notify(source, cityTitle() .. ' Legal Money Loops', GMT.Join(city.money_loops or {}, ' | '))
end, false)
