-- Security checklist command.
-- This does not replace anti-cheat. It gives staff a visible operations checklist.

RegisterCommand('securitycheck', function(source)
    local city = GMT_CITY or {}
    local focus = GMT.Join(city.security_focus or {}, ' | ')
    local message = 'Core checks: staff permissions, whitelist rules, resource audit, payout caps, event cooldowns, Discord ticket logs.'
    if focus and focus ~= '' then
        message = message .. ' City focus: ' .. focus
    end
    GMT.Notify(source, 'GTA Money Team Security', message)
end, false)
