-- Client-side helpers for city pack testing.
-- This file is intentionally lightweight. Add map blips, spawn routing,
-- weather sync, or framework integrations here.

CreateThread(function()
    Wait(3000)
    if GMT_CITY and GMT_CITY.premium_name then
        TriggerEvent('chat:addMessage', {
            color = { 255, 54, 171 },
            multiline = true,
            args = { 'GTA Money Team', 'Loaded city pack: ' .. GMT_CITY.premium_name .. '. Try /citypack, /landmarks, /payouts.' }
        })
    end
end)

RegisterCommand('cityspawninfo', function()
    local spawn = GMT_CITY and GMT_CITY.spawn or {}
    TriggerEvent('chat:addMessage', {
        color = { 255, 212, 0 },
        args = { 'City Spawn', (spawn.label or 'Spawn') .. ' @ x=' .. tostring(spawn.x) .. ', y=' .. tostring(spawn.y) .. ', z=' .. tostring(spawn.z) }
    })
end, false)
