# Discord Master Template

Use this as a base for each city.

## Categories and channels

### START HERE
- #welcome
- #rules
- #announcements
- #how-to-connect
- #city-pack-info

### WHITELIST
- #whitelist-info
- #apply-here
- #application-status
- #interview-schedule

### CITY LIFE
- #business-licenses
- #job-board
- #housing-board
- #vehicle-market
- #events-calendar

### PUBLIC SAFETY
- #police-recruitment
- #ems-recruitment
- #court-dockets
- #incident-reports

### CREWS + BUSINESSES
- #crew-applications
- #business-pitches
- #payout-questions
- #event-bookings

### SUPPORT
- #open-ticket
- #bug-reports
- #donation-support
- #staff-contact

## Roles

- Founder
- Co-Owner
- City Manager
- Developer
- Admin
- Moderator
- Support
- Police Chief
- EMS Director
- Business Owner
- Crew Lead
- VIP Resident
- Whitelisted
- New Arrival

## Monetization roles

Keep monetization fair. Sell priority support, cosmetic recognition, queue priority where compliant, Discord perks, template access, and support services. Avoid selling direct combat power or unfair job payouts.
