# Security Hardening Checklist

Use this checklist in every premium install.

## Server permissions

- Do not give every staff member `group.admin`.
- Create roles: owner, admin, moderator, support, developer.
- Store license identifiers in a private file.
- Never put Discord bot tokens or database passwords in a public GitHub repo.

## Resource safety

- Audit every third-party resource before install.
- Search for suspicious functions like `PerformHttpRequest`, `LoadResourceFile`, `SaveResourceFile`, hidden webhooks, and obfuscated code.
- Do not install random leaked scripts.
- Keep paid assets in the buyer's own account/license where possible.

## Economy safety

- Cap job payouts during beta.
- Log high-value payouts.
- Add cooldowns to freight, robbery, racing, and VIP jobs.
- Do not create pay-to-win perks.

## Community safety

- Require whitelist applications for serious RP.
- Add ticket logs for staff decisions.
- Enforce anti-harassment rules.
- Ban doxxing, threats, real gang recruitment, and real criminal coordination.

## Event safety

- High-value events need staff observers.
- Motorcades, port jobs, and bank/security events need cooldowns.
- Public landmarks should have no-RDM/no-VDM protection rules.
