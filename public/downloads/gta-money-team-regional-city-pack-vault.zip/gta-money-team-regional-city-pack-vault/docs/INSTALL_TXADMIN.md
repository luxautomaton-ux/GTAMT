# txAdmin Install Guide for Buyers

Use this as the customer setup guide.

## 1. Prepare hosting

Use a VPS/game host that supports FiveM/FXServer. Open TCP and UDP port `30120`.

## 2. Start FXServer / txAdmin

Run FXServer. On modern FXServer builds, txAdmin opens during first setup when you start FXServer without a custom `+exec server.cfg` argument.

## 3. Link Cfx.re account and generate key

Follow txAdmin prompts, link the buyer's Cfx.re account, and generate/enter their server registration key. Do not use your own key for customer deployments.

## 4. Install this city pack

1. Copy `resources/[gmt]/gmt_city_engine` to the server resources folder.
2. Pick one product folder in `products/`.
3. Copy its `city_config.lua` into `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
4. Add `ensure gmt_city_engine` to `server.cfg`.
5. Restart the server.

## 5. Test commands

In game or console, verify:

- `/citypack`
- `/landmarks`
- `/streets`
- `/factions`
- `/policefleet`
- `/payouts`
- `/weatherplan`
- `/securitycheck`

## 6. Production steps

- Add QBCore/ESX only after the base resource works.
- Add database persistence.
- Add licensed vehicles, maps, MLOs, EUP, and scripts.
- Create Discord whitelist flow.
- Run a beta weekend before taking real payments.
