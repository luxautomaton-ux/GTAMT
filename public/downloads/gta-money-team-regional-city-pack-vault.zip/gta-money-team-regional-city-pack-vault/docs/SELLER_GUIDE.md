# Seller Guide — How to Turn These Packs Into Money

## Product ladder

### Entry product
Single city pack ZIP: $119–$159.

Includes the city concept, config, server snippet, Discord outline, payout model, and setup guide.

### Mid-ticket product
City Pack + Discord Setup: $249–$349.

You configure their Discord channels, roles, applications, and rules.

### High-ticket product
Installed Server Identity: $549–$799.

You install the selected city pack, configure `server.cfg`, add staff permissions, and test commands.

### Custom build
Full custom city build: $1,800–$2,500+.

You add licensed vehicles, maps, framework, economy, jobs, dispatch, inventory, voice, and branded UI.

### Monthly retainer
Security + economy tuning: $249–$399/mo.

Includes script audits, payout balancing, staff process, anti-cheat coordination, and update support.

## Best launch bundle

Sell the top 3 first:

1. Bayline Oakland RP
2. Capital District RP
3. Rose City Rain RP

Then bundle all 11 as the Regional Vault.

## Sales copy template

“Launch a serious RP city without starting from zero. This pack gives you the city identity, landmarks, streets, police fleet placeholders, fictional crews, payout system, Discord setup, and core FiveM config structure. Add your licensed scripts and assets, then open beta faster.”

## Upsells

- Discord setup
- Tebex product setup
- Whitelist application system
- Script audit
- Economy balancing
- Custom police liveries using licensed templates
- Job creation
- Server trailer / promo video
- Monthly staff ops support
