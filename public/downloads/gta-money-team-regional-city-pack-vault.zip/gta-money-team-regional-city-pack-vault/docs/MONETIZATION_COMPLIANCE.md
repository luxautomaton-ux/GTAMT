# Monetization Compliance Notes

This vault is designed for legal server services and digital templates.

## Safer products to sell

- City setup templates
- Discord server setup
- Staff process docs
- Legal economy balancing
- Cosmetic branding
- Setup videos
- Premium support
- Server audits
- Custom configuration work

## Avoid

- Leaked scripts
- Ripped cars/maps
- Real police logos without permission
- Pay-to-win combat perks
- Admin power sales
- Hidden backdoors
- Fake investment or crypto claims

## Tebex ideas

- VIP Discord role
- Queue priority if allowed by your server policy
- Cosmetic recognition
- Support package
- Business application package
- City founder pack with non-P2W perks
- Merch/community support package
