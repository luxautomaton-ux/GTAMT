# Crew Payout Models

These models help server owners keep legal RP businesses profitable without creating broken economies.

## Model A — Small crew route

- Owner / Business: 30%
- Route Lead: 20%
- Driver: 20%
- Security: 15%
- Support: 10%
- Reserve Fund: 5%

Use for towing, food trucks, courier loops, and small event teams.

## Model B — Event/nightlife team

- Venue Owner: 28%
- Promoter: 20%
- Security: 20%
- Performers / Creators: 17%
- Staff Pool: 10%
- Reserve Fund: 5%

Use for music venues, car meets, sports nights, and streamer events.

## Model C — Logistics company

- Company Owner: 25%
- Dispatcher: 20%
- Lead Driver: 20%
- Supporting Drivers: 20%
- Security / Recovery: 10%
- Reserve Fund: 5%

Use for port, warehouse, turnpike, rail, and airport jobs.

## Model D — VIP/security contract

- Director: 32%
- Operations: 20%
- Security: 18%
- Driver: 14%
- Media/Support: 11%
- Reserve Fund: 5%

Use for Washington DC, Charlotte finance, stadium events, and high-end escort RP.

## Rule of thumb

If one role gets over 40%, your community will usually fight over payouts. Keep the top role between 25% and 35% and put 5% into a company reserve fund.
