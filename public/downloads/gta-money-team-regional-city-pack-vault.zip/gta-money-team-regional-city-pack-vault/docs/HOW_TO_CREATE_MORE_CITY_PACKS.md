# How to Create More City Packs

1. Pick a city theme.
2. Choose 5 districts.
3. Create 3 street names per district.
4. Add 6 to 8 landmarks.
5. Create 4 fictional factions.
6. Define 5 legal money loops.
7. Build 6 police fleet placeholders.
8. Choose 5 to 7 weather types with weights.
9. Add Discord channels and roles.
10. Write a sales angle and pricing.
11. Create `city_config.lua` using the template.
12. Test commands in `gmt_city_engine`.

Do not use real gang names, real police seals, or copied top-server branding.
