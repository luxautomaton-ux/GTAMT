# GTA Money Team — Regional Premium FiveM City Pack Vault

**Product:** 11 original regional city packs for FiveM / GTA V RP sellers.  
**Brand:** GTA Money Team — Learn How To Make Money The Legit Way.  
**Built by:** Lux Automaton.

This vault expands the GTA Money Team city-product line with the specific regions requested:

- **Rose City Rain RP** — Portland, Oregon: Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.
- **Bayline Oakland RP** — Oakland, California: Port power, lake culture, music crews, and Bay Area logistics built for serious community RP.
- **Citrus Valley RP** — Riverside, California: Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.
- **Wasatch State RP** — Utah / Wasatch corridor: Mountain-state RP with snow patrol, ski towns, salt flats, desert routes, and clean economy ladders.
- **Gateway River RP** — St. Louis, Missouri: Gateway city RP with river freight, sports nights, brick neighborhoods, and logistics money.
- **KC Crossroads RP** — Kansas City, Missouri / Kansas metro: BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.
- **Bluff City RP** — Memphis, Tennessee: Music, river freight, street fashion, logistics, and creator economy in a Southern nightlife city.
- **Queen City RP** — Charlotte, North Carolina: Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.
- **Liberty Row RP** — Philadelphia, Pennsylvania: Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.
- **Garden State RP** — New Jersey statewide / metro shore: Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.
- **Capital District RP** — Washington, DC: Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.

## Important legal note

These are **original city identity templates**. They do not include ripped vehicles, copyrighted MLOs, official police logos, private top-server scripts, or real gang branding. Every pack uses placeholders so you can add licensed assets later.

Sell them as:

> FiveM RP starter city identity packs with setup docs, city configs, payout models, security rules, and community templates.

Do **not** sell them as copies of any famous server.

## Fast install

1. Set up FXServer/txAdmin.
2. Copy `resources/[gmt]/gmt_city_engine` into your server resources folder.
3. Pick a city from `products/<city-id>/city_config.lua`.
4. Copy that file to `resources/[gmt]/gmt_city_engine/config/active_city.lua`.
5. Add `ensure gmt_city_engine` to your `server.cfg`.
6. Start the server.
7. In game, test these commands:
   - `/citypack`
   - `/landmarks`
   - `/streets`
   - `/factions`
   - `/policefleet`
   - `/payouts`
   - `/weatherplan`
   - `/securitycheck`

## Suggested pricing

- Single City Pack ZIP: **$119–$159**
- City Pack + Discord Setup: **$249–$349**
- Installed Server Identity: **$549–$799**
- Full Custom City Build: **$1,800–$2,500+**
- Monthly Support / Security / Economy Tuning: **$249–$399/mo**

## Best bundle offer

**GTA Money Team Regional City Vault**  
All 11 city packs + shared engine + seller guide + Discord templates + payout/security docs.

Suggested vault price: **$499–$999** depending on support.
