# Regional City Pack Catalog

## Rose City Rain RP

- Region: Portland, Oregon
- Tagline: Rainy bridge-city roleplay with ports, coffee money, street crews, and eco-business loops.
- ZIP price: $129
- Install price: $599
- Landmarks: Rose City Waterfront, St. Johns Bridge Lookout, Pioneer Plaza, Pearl Warehouse Row
- Starter jobs: Coffee Shop Owner, Tow Operator, Bike Courier, Port Trucker

## Bayline Oakland RP

- Region: Oakland, California
- Tagline: Port power, lake culture, music crews, and Bay Area logistics built for serious community RP.
- ZIP price: $149
- Install price: $699
- Landmarks: Lake Merritt Circle, Jack London Port, Bay Bridge View, Telegraph Arts Block
- Starter jobs: Port Trucker, Venue Promoter, Food Truck Owner, Mechanic

## Citrus Valley RP

- Region: Riverside, California
- Tagline: Inland empire money routes with citrus businesses, freeway heat, warehouse work, and college RP.
- ZIP price: $119
- Install price: $549
- Landmarks: Mission Hotel Plaza, Mount Rubidoux Lookout, Citrus Market, University District
- Starter jobs: Warehouse Worker, Citrus Trucker, Valet, Mechanic

## Wasatch State RP

- Region: Utah / Wasatch corridor
- Tagline: Mountain-state RP with snow patrol, ski towns, salt flats, desert routes, and clean economy ladders.
- ZIP price: $139
- Install price: $649
- Landmarks: Wasatch Overlook, Salt Flats Speedway, Red Rock Rim, Downtown Temple Grid
- Starter jobs: State Trooper, Ski Patrol, Off-road Tour Guide, Tech Courier

## Gateway River RP

- Region: St. Louis, Missouri
- Tagline: Gateway city RP with river freight, sports nights, brick neighborhoods, and logistics money.
- ZIP price: $129
- Install price: $599
- Landmarks: Gateway Arch View, Riverfront Docks, Soulard Market, Forest Park Loop
- Starter jobs: River Trucker, Venue Worker, Brewery Driver, Tow Operator

## KC Crossroads RP

- Region: Kansas City, Missouri / Kansas metro
- Tagline: BBQ, jazz, rail freight, sports districts, and clean Midwest crew economics.
- ZIP price: $129
- Install price: $599
- Landmarks: Jazz District, BBQ Row, River Market, Crossroads Gallery
- Starter jobs: BBQ Vendor, Rail Trucker, Jazz Promoter, Event Security

## Bluff City RP

- Region: Memphis, Tennessee
- Tagline: Music, river freight, street fashion, logistics, and creator economy in a Southern nightlife city.
- ZIP price: $139
- Install price: $649
- Landmarks: Beale Street Stage, Mississippi Riverfront, South Main Arts Block, Airport Cargo Yard
- Starter jobs: Artist Manager, Venue Security, River Trucker, Airport Courier

## Queen City RP

- Region: Charlotte, North Carolina
- Tagline: Banking, NASCAR energy, nightlife districts, college suburbs, and clean business progression.
- ZIP price: $139
- Install price: $649
- Landmarks: Uptown Skyline, Queen Stadium, Speedway Corridor, South End Rail Trail
- Starter jobs: Executive Driver, Race Mechanic, Venue Promoter, Bank Security

## Liberty Row RP

- Region: Philadelphia, Pennsylvania
- Tagline: Historic city grit, sports nights, river wards, delivery routes, and neighborhood business RP.
- ZIP price: $149
- Install price: $699
- Landmarks: Liberty Bell Square, City Hall Loop, Art Museum Steps, Sports Complex
- Starter jobs: Food Vendor, Courier, Event Security, Taxi Driver

## Garden State RP

- Region: New Jersey statewide / metro shore
- Tagline: Turnpike highways, shore money, port logistics, suburbs, boardwalks, and state-police RP.
- ZIP price: $149
- Install price: $699
- Landmarks: Garden State Parkway Plaza, Port Newark Yard, Shore Boardwalk, Meadowlands Stadium
- Starter jobs: State Trooper, Tow Operator, Port Trucker, Boardwalk Vendor

## Capital District RP

- Region: Washington, DC
- Tagline: Government-adjacent RP, security contracts, motorcades, media crews, and city politics without real agency branding.
- ZIP price: $159
- Install price: $799
- Landmarks: Capital Plaza, Monument Row, Union Station, The Wharf
- Starter jobs: Civic Security, Media Reporter, VIP Driver, Wharf Vendor
