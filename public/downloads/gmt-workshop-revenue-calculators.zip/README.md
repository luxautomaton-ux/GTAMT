# Workshop Revenue Calculators

Use these CSVs to model $25/mo subscription revenue, one-time template sales, and upsell ladders.
