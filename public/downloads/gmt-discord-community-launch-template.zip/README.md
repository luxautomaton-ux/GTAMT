# Discord Community Launch Template

## Channels

- #start-here
- #rules
- #announcements
- #applications
- #support-tickets
- #server-status
- #clips
- #events
- #staff-room
- #mod-log

## Roles

Owner, Admin, Moderator, Trial Staff, Whitelisted, VIP, Creator, Member, Muted.

## No-public-interaction setup

Use announcement-only channels and tickets only after purchase. Do not run public debates or public support threads.
