# Ticket SOP

1. Buyer opens ticket after payment only.
2. Staff verifies order ID.
3. Staff sends download/setup answer from saved macros.
4. Close ticket after delivery.
