# Rules Copy

Respect staff, no harassment, no doxxing, no stolen assets, no cheat talk, no fake GTA coins, no malware links, no reselling private files.
