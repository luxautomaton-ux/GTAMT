# Tebex Store Blueprint Pack

Use this for legal-safe FiveM/RedM server monetization planning where platform rules allow.

## Store categories

- Supporter tiers
- Queue priority where allowed
- Cosmetic/status perks where allowed
- Application processing where allowed
- Downloadable assets through proper asset delivery
- Community/event support

## Avoid

Paid in-game cash, chance mechanics, pay-to-win abuse, NFTs/tokens, unauthorized Rockstar virtual items, copied IP, real gang/police branding.
