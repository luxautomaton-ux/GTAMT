# Fulfillment Checklist

- Verify purchase.
- Confirm package rules.
- Deliver entitlement.
- Log buyer email/order ID.
- Keep rollback notes.
