# Package Copy Templates

## Supporter Tier

Support the city and unlock supporter recognition, Discord role access, and community perks that do not break balance.

## Application Pass

Get access to the application packet, setup guide, and onboarding checklist.
