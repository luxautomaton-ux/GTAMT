# GTA Money Team Page Cleanup Plan

## Goal

Make the app sell one simple offer:

**GTA Money Team Workshop — $25/month**  
**Let us help you make money on GTA 6.**

## New navigation

1. **Start Here** — sales landing page with clear $25/mo CTA.
2. **Workshop Vault** — gated member dashboard.
3. **Downloads** — all ZIP packs, scripts, calculators, and docs.
4. **Calculators** — MRR, template sales, upsell, and server cost calculators.
5. **Server Packs** — FiveM templates, city packs, security SOPs, Discord/Tebex guides.
6. **Creator Academy** — Argil/faceless YouTube/TikTok/Shorts scripts.
7. **Scam Firewall** — free page for trust-building and legal safety.
8. **Lana Coach** — downloadable prompts and strategy scripts.

## Remove or hide

- Public request forms
- Public GitHub/tool links
- Public affiliate stack page
- Public ops/admin dashboards
- Any “contact us for everything” page
- Any page that does not push subscription, downloads, safety, or trust

## Reposition

- Services → downloadable packs and upsell sales copy.
- Affiliate Stack → internal Lux Ops research only.
- Investor Radar → optional education footer; do not let it distract from the subscription.
- Media Vault → marketing art/brand visuals, not a primary money page.
- GitHub Radar → hidden internal research desk.

## Best homepage headline

**Let us help you make money on GTA 6.**

Subheadline:

Download legal money strategies, server templates, city packs, creator scripts, calculators, and security playbooks built for players, creators, and RP server owners.

CTA:

**Join the Workshop — $25/month**
