# Download-Only Delivery Policy

GTA Money Team Workshop is designed to avoid public interaction and reduce manual support.

## What customers get

- Gated member dashboard
- Downloadable ZIP packs
- Downloadable Markdown/PDF/CSV files
- Update drops when you upload new files
- Clear setup instructions inside each download

## What customers do not get by default

- Public support forum
- Public comments
- Public GitHub links
- Public Discord access
- Manual custom work
- One-on-one coaching

## Optional upsell, not public interaction

If you later sell DFY installs, keep them separate from the $25/mo workshop. Use a private intake form after payment only.

## File naming rules

Use clear versions:

```text
gmt-city-pack-v1.0.zip
gmt-security-sop-v1.1.zip
gmt-creator-scripts-v1.2.zip
```

## Monthly content drop rule

Release at least one new download every month:

- New city pack
- New script pack
- New calculator
- New Discord template
- New security SOP
- New sales page template

This gives members a reason to stay subscribed.
