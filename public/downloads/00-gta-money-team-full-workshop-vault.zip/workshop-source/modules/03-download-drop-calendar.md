# Monthly Download Drop Calendar

Week 1: New city pack or faction kit.  
Week 2: New faceless scripts and hooks.  
Week 3: New calculator or sales template.  
Week 4: Security/compliance update and member recap.

Retention comes from new drops. Treat the workshop like a content product, not a dead ZIP folder.
