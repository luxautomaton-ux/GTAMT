# Lana Prompt Pack

Use these prompts inside your app or AI tool.

## Server economy prompt

Lana, build a legal RP economy plan for a new FiveM city. Include starter jobs, business categories, payout balance, inflation controls, and staff audit rules.

## City pack prompt

Lana, create an original RP city identity inspired by a real region without copying official logos, gangs, police branding, or private server assets.

## Faceless channel prompt

Lana, write a 30-second faceless vertical video script promoting a legal GTA Money Team template download. Make it energetic, gamer-focused, and safe.
