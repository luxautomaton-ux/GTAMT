# Template Seller Offer Ladder

## Entry offer

$25/month workshop access.

## One-time template offers

- Starter server template: $49–$99
- City pack: $119–$159
- Discord template: $29–$79
- Security SOP: $79–$149

## High ticket upgrades

- Installed server identity: $549–$799
- Custom city build: $1,800+
- Monthly ops retainer: $249–$499/mo

Keep high-ticket services private after payment. Do not turn the public app into a support forum.
