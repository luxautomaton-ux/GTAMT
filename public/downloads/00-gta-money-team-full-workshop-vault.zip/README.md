# GTA Money Team Full Workshop Vault

This all-in-one vault contains the downloadable packs for the $25/month workshop.
